/*!
 * jQuery JavaScript Library v1.10.2
 * http://jquery.com/
 *
 * Includes Sizzle.js
 * http://sizzlejs.com/
 *
 * Copyright 2005, 2013 jQuery Foundation, Inc. and other contributors
 * Released under the MIT license
 * http://jquery.org/license
 *
 * Date: 2013-07-03T13:48Z
 */
(function( window, undefined ) {

// Can't do this because several apps including ASP.NET trace
// the stack via arguments.caller.callee and Firefox dies if
// you try to trace through "use strict" call chains. (#13335)
// Support: Firefox 18+
//"use strict";
var
	// The deferred used on DOM ready
	readyList,

	// A central reference to the root jQuery(document)
	rootjQuery,

	// Support: IE<10
	// For `typeof xmlNode.method` instead of `xmlNode.method !== undefined`
	core_strundefined = typeof undefined,

	// Use the correct document accordingly with window argument (sandbox)
	location = window.location,
	document = window.document,
	docElem = document.documentElement,

	// Map over jQuery in case of overwrite
	_jQuery = window.jQuery,

	// Map over the $ in case of overwrite
	_$ = window.$,

	// [[Class]] -> type pairs
	class2type = {},

	// List of deleted data cache ids, so we can reuse them
	core_deletedIds = [],

	core_version = "1.10.2",

	// Save a reference to some core methods
	core_concat = core_deletedIds.concat,
	core_push = core_deletedIds.push,
	core_slice = core_deletedIds.slice,
	core_indexOf = core_deletedIds.indexOf,
	core_toString = class2type.toString,
	core_hasOwn = class2type.hasOwnProperty,
	core_trim = core_version.trim,

	// Define a local copy of jQuery
	jQuery = function( selector, context ) {
		// The jQuery object is actually just the init constructor 'enhanced'
		return new jQuery.fn.init( selector, context, rootjQuery );
	},

	// Used for matching numbers
	core_pnum = /[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source,

	// Used for splitting on whitespace
	core_rnotwhite = /\S+/g,

	// Make sure we trim BOM and NBSP (here's looking at you, Safari 5.0 and IE)
	rtrim = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g,

	// A simple way to check for HTML strings
	// Prioritize #id over <tag> to avoid XSS via location.hash (#9521)
	// Strict HTML recognition (#11290: must start with <)
	rquickExpr = /^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]*))$/,

	// Match a standalone tag
	rsingleTag = /^<(\w+)\s*\/?>(?:<\/\1>|)$/,

	// JSON RegExp
	rvalidchars = /^[\],:{}\s]*$/,
	rvalidbraces = /(?:^|:|,)(?:\s*\[)+/g,
	rvalidescape = /\\(?:["\\\/bfnrt]|u[\da-fA-F]{4})/g,
	rvalidtokens = /"[^"\\\r\n]*"|true|false|null|-?(?:\d+\.|)\d+(?:[eE][+-]?\d+|)/g,

	// Matches dashed string for camelizing
	rmsPrefix = /^-ms-/,
	rdashAlpha = /-([\da-z])/gi,

	// Used by jQuery.camelCase as callback to replace()
	fcamelCase = function( all, letter ) {
		return letter.toUpperCase();
	},

	// The ready event handler
	completed = function( event ) {

		// readyState === "complete" is good enough for us to call the dom ready in oldIE
		if ( document.addEventListener || event.type === "load" || document.readyState === "complete" ) {
			detach();
			jQuery.ready();
		}
	},
	// Clean-up method for dom ready events
	detach = function() {
		if ( document.addEventListener ) {
			document.removeEventListener( "DOMContentLoaded", completed, false );
			window.removeEventListener( "load", completed, false );

		} else {
			document.detachEvent( "onreadystatechange", completed );
			window.detachEvent( "onload", completed );
		}
	};

jQuery.fn = jQuery.prototype = {
	// The current version of jQuery being used
	jquery: core_version,

	constructor: jQuery,
	init: function( selector, context, rootjQuery ) {
		var match, elem;

		// HANDLE: $(""), $(null), $(undefined), $(false)
		if ( !selector ) {
			return this;
		}

		// Handle HTML strings
		if ( typeof selector === "string" ) {
			if ( selector.charAt(0) === "<" && selector.charAt( selector.length - 1 ) === ">" && selector.length >= 3 ) {
				// Assume that strings that start and end with <> are HTML and skip the regex check
				match = [ null, selector, null ];

			} else {
				match = rquickExpr.exec( selector );
			}

			// Match html or make sure no context is specified for #id
			if ( match && (match[1] || !context) ) {

				// HANDLE: $(html) -> $(array)
				if ( match[1] ) {
					context = context instanceof jQuery ? context[0] : context;

					// scripts is true for back-compat
					jQuery.merge( this, jQuery.parseHTML(
						match[1],
						context && context.nodeType ? context.ownerDocument || context : document,
						true
					) );

					// HANDLE: $(html, props)
					if ( rsingleTag.test( match[1] ) && jQuery.isPlainObject( context ) ) {
						for ( match in context ) {
							// Properties of context are called as methods if possible
							if ( jQuery.isFunction( this[ match ] ) ) {
								this[ match ]( context[ match ] );

							// ...and otherwise set as attributes
							} else {
								this.attr( match, context[ match ] );
							}
						}
					}

					return this;

				// HANDLE: $(#id)
				} else {
					elem = document.getElementById( match[2] );

					// Check parentNode to catch when Blackberry 4.6 returns
					// nodes that are no longer in the document #6963
					if ( elem && elem.parentNode ) {
						// Handle the case where IE and Opera return items
						// by name instead of ID
						if ( elem.id !== match[2] ) {
							return rootjQuery.find( selector );
						}

						// Otherwise, we inject the element directly into the jQuery object
						this.length = 1;
						this[0] = elem;
					}

					this.context = document;
					this.selector = selector;
					return this;
				}

			// HANDLE: $(expr, $(...))
			} else if ( !context || context.jquery ) {
				return ( context || rootjQuery ).find( selector );

			// HANDLE: $(expr, context)
			// (which is just equivalent to: $(context).find(expr)
			} else {
				return this.constructor( context ).find( selector );
			}

		// HANDLE: $(DOMElement)
		} else if ( selector.nodeType ) {
			this.context = this[0] = selector;
			this.length = 1;
			return this;

		// HANDLE: $(function)
		// Shortcut for document ready
		} else if ( jQuery.isFunction( selector ) ) {
			return rootjQuery.ready( selector );
		}

		if ( selector.selector !== undefined ) {
			this.selector = selector.selector;
			this.context = selector.context;
		}

		return jQuery.makeArray( selector, this );
	},

	// Start with an empty selector
	selector: "",

	// The default length of a jQuery object is 0
	length: 0,

	toArray: function() {
		return core_slice.call( this );
	},

	// Get the Nth element in the matched element set OR
	// Get the whole matched element set as a clean array
	get: function( num ) {
		return num == null ?

			// Return a 'clean' array
			this.toArray() :

			// Return just the object
			( num < 0 ? this[ this.length + num ] : this[ num ] );
	},

	// Take an array of elements and push it onto the stack
	// (returning the new matched element set)
	pushStack: function( elems ) {

		// Build a new jQuery matched element set
		var ret = jQuery.merge( this.constructor(), elems );

		// Add the old object onto the stack (as a reference)
		ret.prevObject = this;
		ret.context = this.context;

		// Return the newly-formed element set
		return ret;
	},

	// Execute a callback for every element in the matched set.
	// (You can seed the arguments with an array of args, but this is
	// only used internally.)
	each: function( callback, args ) {
		return jQuery.each( this, callback, args );
	},

	ready: function( fn ) {
		// Add the callback
		jQuery.ready.promise().done( fn );

		return this;
	},

	slice: function() {
		return this.pushStack( core_slice.apply( this, arguments ) );
	},

	first: function() {
		return this.eq( 0 );
	},

	last: function() {
		return this.eq( -1 );
	},

	eq: function( i ) {
		var len = this.length,
			j = +i + ( i < 0 ? len : 0 );
		return this.pushStack( j >= 0 && j < len ? [ this[j] ] : [] );
	},

	map: function( callback ) {
		return this.pushStack( jQuery.map(this, function( elem, i ) {
			return callback.call( elem, i, elem );
		}));
	},

	end: function() {
		return this.prevObject || this.constructor(null);
	},

	// For internal use only.
	// Behaves like an Array's method, not like a jQuery method.
	push: core_push,
	sort: [].sort,
	splice: [].splice
};

// Give the init function the jQuery prototype for later instantiation
jQuery.fn.init.prototype = jQuery.fn;

jQuery.extend = jQuery.fn.extend = function() {
	var src, copyIsArray, copy, name, options, clone,
		target = arguments[0] || {},
		i = 1,
		length = arguments.length,
		deep = false;

	// Handle a deep copy situation
	if ( typeof target === "boolean" ) {
		deep = target;
		target = arguments[1] || {};
		// skip the boolean and the target
		i = 2;
	}

	// Handle case when target is a string or something (possible in deep copy)
	if ( typeof target !== "object" && !jQuery.isFunction(target) ) {
		target = {};
	}

	// extend jQuery itself if only one argument is passed
	if ( length === i ) {
		target = this;
		--i;
	}

	for ( ; i < length; i++ ) {
		// Only deal with non-null/undefined values
		if ( (options = arguments[ i ]) != null ) {
			// Extend the base object
			for ( name in options ) {
				src = target[ name ];
				copy = options[ name ];

				// Prevent never-ending loop
				if ( target === copy ) {
					continue;
				}

				// Recurse if we're merging plain objects or arrays
				if ( deep && copy && ( jQuery.isPlainObject(copy) || (copyIsArray = jQuery.isArray(copy)) ) ) {
					if ( copyIsArray ) {
						copyIsArray = false;
						clone = src && jQuery.isArray(src) ? src : [];

					} else {
						clone = src && jQuery.isPlainObject(src) ? src : {};
					}

					// Never move original objects, clone them
					target[ name ] = jQuery.extend( deep, clone, copy );

				// Don't bring in undefined values
				} else if ( copy !== undefined ) {
					target[ name ] = copy;
				}
			}
		}
	}

	// Return the modified object
	return target;
};

jQuery.extend({
	// Unique for each copy of jQuery on the page
	// Non-digits removed to match rinlinejQuery
	expando: "jQuery" + ( core_version + Math.random() ).replace( /\D/g, "" ),

	noConflict: function( deep ) {
		if ( window.$ === jQuery ) {
			window.$ = _$;
		}

		if ( deep && window.jQuery === jQuery ) {
			window.jQuery = _jQuery;
		}

		return jQuery;
	},

	// Is the DOM ready to be used? Set to true once it occurs.
	isReady: false,

	// A counter to track how many items to wait for before
	// the ready event fires. See #6781
	readyWait: 1,

	// Hold (or release) the ready event
	holdReady: function( hold ) {
		if ( hold ) {
			jQuery.readyWait++;
		} else {
			jQuery.ready( true );
		}
	},

	// Handle when the DOM is ready
	ready: function( wait ) {

		// Abort if there are pending holds or we're already ready
		if ( wait === true ? --jQuery.readyWait : jQuery.isReady ) {
			return;
		}

		// Make sure body exists, at least, in case IE gets a little overzealous (ticket #5443).
		if ( !document.body ) {
			return setTimeout( jQuery.ready );
		}

		// Remember that the DOM is ready
		jQuery.isReady = true;

		// If a normal DOM Ready event fired, decrement, and wait if need be
		if ( wait !== true && --jQuery.readyWait > 0 ) {
			return;
		}

		// If there are functions bound, to execute
		readyList.resolveWith( document, [ jQuery ] );

		// Trigger any bound ready events
		if ( jQuery.fn.trigger ) {
			jQuery( document ).trigger("ready").off("ready");
		}
	},

	// See test/unit/core.js for details concerning isFunction.
	// Since version 1.3, DOM methods and functions like alert
	// aren't supported. They return false on IE (#2968).
	isFunction: function( obj ) {
		return jQuery.type(obj) === "function";
	},

	isArray: Array.isArray || function( obj ) {
		return jQuery.type(obj) === "array";
	},

	isWindow: function( obj ) {
		/* jshint eqeqeq: false */
		return obj != null && obj == obj.window;
	},

	isNumeric: function( obj ) {
		return !isNaN( parseFloat(obj) ) && isFinite( obj );
	},

	type: function( obj ) {
		if ( obj == null ) {
			return String( obj );
		}
		return typeof obj === "object" || typeof obj === "function" ?
			class2type[ core_toString.call(obj) ] || "object" :
			typeof obj;
	},

	isPlainObject: function( obj ) {
		var key;

		// Must be an Object.
		// Because of IE, we also have to check the presence of the constructor property.
		// Make sure that DOM nodes and window objects don't pass through, as well
		if ( !obj || jQuery.type(obj) !== "object" || obj.nodeType || jQuery.isWindow( obj ) ) {
			return false;
		}

		try {
			// Not own constructor property must be Object
			if ( obj.constructor &&
				!core_hasOwn.call(obj, "constructor") &&
				!core_hasOwn.call(obj.constructor.prototype, "isPrototypeOf") ) {
				return false;
			}
		} catch ( e ) {
			// IE8,9 Will throw exceptions on certain host objects #9897
			return false;
		}

		// Support: IE<9
		// Handle iteration over inherited properties before own properties.
		if ( jQuery.support.ownLast ) {
			for ( key in obj ) {
				return core_hasOwn.call( obj, key );
			}
		}

		// Own properties are enumerated firstly, so to speed up,
		// if last one is own, then all properties are own.
		for ( key in obj ) {}

		return key === undefined || core_hasOwn.call( obj, key );
	},

	isEmptyObject: function( obj ) {
		var name;
		for ( name in obj ) {
			return false;
		}
		return true;
	},

	error: function( msg ) {
		throw new Error( msg );
	},

	// data: string of html
	// context (optional): If specified, the fragment will be created in this context, defaults to document
	// keepScripts (optional): If true, will include scripts passed in the html string
	parseHTML: function( data, context, keepScripts ) {
		if ( !data || typeof data !== "string" ) {
			return null;
		}
		if ( typeof context === "boolean" ) {
			keepScripts = context;
			context = false;
		}
		context = context || document;

		var parsed = rsingleTag.exec( data ),
			scripts = !keepScripts && [];

		// Single tag
		if ( parsed ) {
			return [ context.createElement( parsed[1] ) ];
		}

		parsed = jQuery.buildFragment( [ data ], context, scripts );
		if ( scripts ) {
			jQuery( scripts ).remove();
		}
		return jQuery.merge( [], parsed.childNodes );
	},

	parseJSON: function( data ) {
		// Attempt to parse using the native JSON parser first
		if ( window.JSON && window.JSON.parse ) {
			return window.JSON.parse( data );
		}

		if ( data === null ) {
			return data;
		}

		if ( typeof data === "string" ) {

			// Make sure leading/trailing whitespace is removed (IE can't handle it)
			data = jQuery.trim( data );

			if ( data ) {
				// Make sure the incoming data is actual JSON
				// Logic borrowed from http://json.org/json2.js
				if ( rvalidchars.test( data.replace( rvalidescape, "@" )
					.replace( rvalidtokens, "]" )
					.replace( rvalidbraces, "")) ) {

					return ( new Function( "return " + data ) )();
				}
			}
		}

		jQuery.error( "Invalid JSON: " + data );
	},

	// Cross-browser xml parsing
	parseXML: function( data ) {
		var xml, tmp;
		if ( !data || typeof data !== "string" ) {
			return null;
		}
		try {
			if ( window.DOMParser ) { // Standard
				tmp = new DOMParser();
				xml = tmp.parseFromString( data , "text/xml" );
			} else { // IE
				xml = new ActiveXObject( "Microsoft.XMLDOM" );
				xml.async = "false";
				xml.loadXML( data );
			}
		} catch( e ) {
			xml = undefined;
		}
		if ( !xml || !xml.documentElement || xml.getElementsByTagName( "parsererror" ).length ) {
			jQuery.error( "Invalid XML: " + data );
		}
		return xml;
	},

	noop: function() {},

	// Evaluates a script in a global context
	// Workarounds based on findings by Jim Driscoll
	// http://weblogs.java.net/blog/driscoll/archive/2009/09/08/eval-javascript-global-context
	globalEval: function( data ) {
		if ( data && jQuery.trim( data ) ) {
			// We use execScript on Internet Explorer
			// We use an anonymous function so that context is window
			// rather than jQuery in Firefox
			( window.execScript || function( data ) {
				window[ "eval" ].call( window, data );
			} )( data );
		}
	},

	// Convert dashed to camelCase; used by the css and data modules
	// Microsoft forgot to hump their vendor prefix (#9572)
	camelCase: function( string ) {
		return string.replace( rmsPrefix, "ms-" ).replace( rdashAlpha, fcamelCase );
	},

	nodeName: function( elem, name ) {
		return elem.nodeName && elem.nodeName.toLowerCase() === name.toLowerCase();
	},

	// args is for internal usage only
	each: function( obj, callback, args ) {
		var value,
			i = 0,
			length = obj.length,
			isArray = isArraylike( obj );

		if ( args ) {
			if ( isArray ) {
				for ( ; i < length; i++ ) {
					value = callback.apply( obj[ i ], args );

					if ( value === false ) {
						break;
					}
				}
			} else {
				for ( i in obj ) {
					value = callback.apply( obj[ i ], args );

					if ( value === false ) {
						break;
					}
				}
			}

		// A special, fast, case for the most common use of each
		} else {
			if ( isArray ) {
				for ( ; i < length; i++ ) {
					value = callback.call( obj[ i ], i, obj[ i ] );

					if ( value === false ) {
						break;
					}
				}
			} else {
				for ( i in obj ) {
					value = callback.call( obj[ i ], i, obj[ i ] );

					if ( value === false ) {
						break;
					}
				}
			}
		}

		return obj;
	},

	// Use native String.trim function wherever possible
	trim: core_trim && !core_trim.call("\uFEFF\xA0") ?
		function( text ) {
			return text == null ?
				"" :
				core_trim.call( text );
		} :

		// Otherwise use our own trimming functionality
		function( text ) {
			return text == null ?
				"" :
				( text + "" ).replace( rtrim, "" );
		},

	// results is for internal usage only
	makeArray: function( arr, results ) {
		var ret = results || [];

		if ( arr != null ) {
			if ( isArraylike( Object(arr) ) ) {
				jQuery.merge( ret,
					typeof arr === "string" ?
					[ arr ] : arr
				);
			} else {
				core_push.call( ret, arr );
			}
		}

		return ret;
	},

	inArray: function( elem, arr, i ) {
		var len;

		if ( arr ) {
			if ( core_indexOf ) {
				return core_indexOf.call( arr, elem, i );
			}

			len = arr.length;
			i = i ? i < 0 ? Math.max( 0, len + i ) : i : 0;

			for ( ; i < len; i++ ) {
				// Skip accessing in sparse arrays
				if ( i in arr && arr[ i ] === elem ) {
					return i;
				}
			}
		}

		return -1;
	},

	merge: function( first, second ) {
		var l = second.length,
			i = first.length,
			j = 0;

		if ( typeof l === "number" ) {
			for ( ; j < l; j++ ) {
				first[ i++ ] = second[ j ];
			}
		} else {
			while ( second[j] !== undefined ) {
				first[ i++ ] = second[ j++ ];
			}
		}

		first.length = i;

		return first;
	},

	grep: function( elems, callback, inv ) {
		var retVal,
			ret = [],
			i = 0,
			length = elems.length;
		inv = !!inv;

		// Go through the array, only saving the items
		// that pass the validator function
		for ( ; i < length; i++ ) {
			retVal = !!callback( elems[ i ], i );
			if ( inv !== retVal ) {
				ret.push( elems[ i ] );
			}
		}

		return ret;
	},

	// arg is for internal usage only
	map: function( elems, callback, arg ) {
		var value,
			i = 0,
			length = elems.length,
			isArray = isArraylike( elems ),
			ret = [];

		// Go through the array, translating each of the items to their
		if ( isArray ) {
			for ( ; i < length; i++ ) {
				value = callback( elems[ i ], i, arg );

				if ( value != null ) {
					ret[ ret.length ] = value;
				}
			}

		// Go through every key on the object,
		} else {
			for ( i in elems ) {
				value = callback( elems[ i ], i, arg );

				if ( value != null ) {
					ret[ ret.length ] = value;
				}
			}
		}

		// Flatten any nested arrays
		return core_concat.apply( [], ret );
	},

	// A global GUID counter for objects
	guid: 1,

	// Bind a function to a context, optionally partially applying any
	// arguments.
	proxy: function( fn, context ) {
		var args, proxy, tmp;

		if ( typeof context === "string" ) {
			tmp = fn[ context ];
			context = fn;
			fn = tmp;
		}

		// Quick check to determine if target is callable, in the spec
		// this throws a TypeError, but we will just return undefined.
		if ( !jQuery.isFunction( fn ) ) {
			return undefined;
		}

		// Simulated bind
		args = core_slice.call( arguments, 2 );
		proxy = function() {
			return fn.apply( context || this, args.concat( core_slice.call( arguments ) ) );
		};

		// Set the guid of unique handler to the same of original handler, so it can be removed
		proxy.guid = fn.guid = fn.guid || jQuery.guid++;

		return proxy;
	},

	// Multifunctional method to get and set values of a collection
	// The value/s can optionally be executed if it's a function
	access: function( elems, fn, key, value, chainable, emptyGet, raw ) {
		var i = 0,
			length = elems.length,
			bulk = key == null;

		// Sets many values
		if ( jQuery.type( key ) === "object" ) {
			chainable = true;
			for ( i in key ) {
				jQuery.access( elems, fn, i, key[i], true, emptyGet, raw );
			}

		// Sets one value
		} else if ( value !== undefined ) {
			chainable = true;

			if ( !jQuery.isFunction( value ) ) {
				raw = true;
			}

			if ( bulk ) {
				// Bulk operations run against the entire set
				if ( raw ) {
					fn.call( elems, value );
					fn = null;

				// ...except when executing function values
				} else {
					bulk = fn;
					fn = function( elem, key, value ) {
						return bulk.call( jQuery( elem ), value );
					};
				}
			}

			if ( fn ) {
				for ( ; i < length; i++ ) {
					fn( elems[i], key, raw ? value : value.call( elems[i], i, fn( elems[i], key ) ) );
				}
			}
		}

		return chainable ?
			elems :

			// Gets
			bulk ?
				fn.call( elems ) :
				length ? fn( elems[0], key ) : emptyGet;
	},

	now: function() {
		return ( new Date() ).getTime();
	},

	// A method for quickly swapping in/out CSS properties to get correct calculations.
	// Note: this method belongs to the css module but it's needed here for the support module.
	// If support gets modularized, this method should be moved back to the css module.
	swap: function( elem, options, callback, args ) {
		var ret, name,
			old = {};

		// Remember the old values, and insert the new ones
		for ( name in options ) {
			old[ name ] = elem.style[ name ];
			elem.style[ name ] = options[ name ];
		}

		ret = callback.apply( elem, args || [] );

		// Revert the old values
		for ( name in options ) {
			elem.style[ name ] = old[ name ];
		}

		return ret;
	}
});

jQuery.ready.promise = function( obj ) {
	if ( !readyList ) {

		readyList = jQuery.Deferred();

		// Catch cases where $(document).ready() is called after the browser event has already occurred.
		// we once tried to use readyState "interactive" here, but it caused issues like the one
		// discovered by ChrisS here: http://bugs.jquery.com/ticket/12282#comment:15
		if ( document.readyState === "complete" ) {
			// Handle it asynchronously to allow scripts the opportunity to delay ready
			setTimeout( jQuery.ready );

		// Standards-based browsers support DOMContentLoaded
		} else if ( document.addEventListener ) {
			// Use the handy event callback
			document.addEventListener( "DOMContentLoaded", completed, false );

			// A fallback to window.onload, that will always work
			window.addEventListener( "load", completed, false );

		// If IE event model is used
		} else {
			// Ensure firing before onload, maybe late but safe also for iframes
			document.attachEvent( "onreadystatechange", completed );

			// A fallback to window.onload, that will always work
			window.attachEvent( "onload", completed );

			// If IE and not a frame
			// continually check to see if the document is ready
			var top = false;

			try {
				top = window.frameElement == null && document.documentElement;
			} catch(e) {}

			if ( top && top.doScroll ) {
				(function doScrollCheck() {
					if ( !jQuery.isReady ) {

						try {
							// Use the trick by Diego Perini
							// http://javascript.nwbox.com/IEContentLoaded/
							top.doScroll("left");
						} catch(e) {
							return setTimeout( doScrollCheck, 50 );
						}

						// detach all dom ready events
						detach();

						// and execute any waiting functions
						jQuery.ready();
					}
				})();
			}
		}
	}
	return readyList.promise( obj );
};

// Populate the class2type map
jQuery.each("Boolean Number String Function Array Date RegExp Object Error".split(" "), function(i, name) {
	class2type[ "[object " + name + "]" ] = name.toLowerCase();
});

function isArraylike( obj ) {
	var length = obj.length,
		type = jQuery.type( obj );

	if ( jQuery.isWindow( obj ) ) {
		return false;
	}

	if ( obj.nodeType === 1 && length ) {
		return true;
	}

	return type === "array" || type !== "function" &&
		( length === 0 ||
		typeof length === "number" && length > 0 && ( length - 1 ) in obj );
}

// All jQuery objects should point back to these
rootjQuery = jQuery(document);
/*!
 * Sizzle CSS Selector Engine v1.10.2
 * http://sizzlejs.com/
 *
 * Copyright 2013 jQuery Foundation, Inc. and other contributors
 * Released under the MIT license
 * http://jquery.org/license
 *
 * Date: 2013-07-03
 */
(function( window, undefined ) {

var i,
	support,
	cachedruns,
	Expr,
	getText,
	isXML,
	compile,
	outermostContext,
	sortInput,

	// Local document vars
	setDocument,
	document,
	docElem,
	documentIsHTML,
	rbuggyQSA,
	rbuggyMatches,
	matches,
	contains,

	// Instance-specific data
	expando = "sizzle" + -(new Date()),
	preferredDoc = window.document,
	dirruns = 0,
	done = 0,
	classCache = createCache(),
	tokenCache = createCache(),
	compilerCache = createCache(),
	hasDuplicate = false,
	sortOrder = function( a, b ) {
		if ( a === b ) {
			hasDuplicate = true;
			return 0;
		}
		return 0;
	},

	// General-purpose constants
	strundefined = typeof undefined,
	MAX_NEGATIVE = 1 << 31,

	// Instance methods
	hasOwn = ({}).hasOwnProperty,
	arr = [],
	pop = arr.pop,
	push_native = arr.push,
	push = arr.push,
	slice = arr.slice,
	// Use a stripped-down indexOf if we can't use a native one
	indexOf = arr.indexOf || function( elem ) {
		var i = 0,
			len = this.length;
		for ( ; i < len; i++ ) {
			if ( this[i] === elem ) {
				return i;
			}
		}
		return -1;
	},

	booleans = "checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped",

	// Regular expressions

	// Whitespace characters http://www.w3.org/TR/css3-selectors/#whitespace
	whitespace = "[\\x20\\t\\r\\n\\f]",
	// http://www.w3.org/TR/css3-syntax/#characters
	characterEncoding = "(?:\\\\.|[\\w-]|[^\\x00-\\xa0])+",

	// Loosely modeled on CSS identifier characters
	// An unquoted value should be a CSS identifier http://www.w3.org/TR/css3-selectors/#attribute-selectors
	// Proper syntax: http://www.w3.org/TR/CSS21/syndata.html#value-def-identifier
	identifier = characterEncoding.replace( "w", "w#" ),

	// Acceptable operators http://www.w3.org/TR/selectors/#attribute-selectors
	attributes = "\\[" + whitespace + "*(" + characterEncoding + ")" + whitespace +
		"*(?:([*^$|!~]?=)" + whitespace + "*(?:(['\"])((?:\\\\.|[^\\\\])*?)\\3|(" + identifier + ")|)|)" + whitespace + "*\\]",

	// Prefer arguments quoted,
	//   then not containing pseudos/brackets,
	//   then attribute selectors/non-parenthetical expressions,
	//   then anything else
	// These preferences are here to reduce the number of selectors
	//   needing tokenize in the PSEUDO preFilter
	pseudos = ":(" + characterEncoding + ")(?:\\(((['\"])((?:\\\\.|[^\\\\])*?)\\3|((?:\\\\.|[^\\\\()[\\]]|" + attributes.replace( 3, 8 ) + ")*)|.*)\\)|)",

	// Leading and non-escaped trailing whitespace, capturing some non-whitespace characters preceding the latter
	rtrim = new RegExp( "^" + whitespace + "+|((?:^|[^\\\\])(?:\\\\.)*)" + whitespace + "+$", "g" ),

	rcomma = new RegExp( "^" + whitespace + "*," + whitespace + "*" ),
	rcombinators = new RegExp( "^" + whitespace + "*([>+~]|" + whitespace + ")" + whitespace + "*" ),

	rsibling = new RegExp( whitespace + "*[+~]" ),
	rattributeQuotes = new RegExp( "=" + whitespace + "*([^\\]'\"]*)" + whitespace + "*\\]", "g" ),

	rpseudo = new RegExp( pseudos ),
	ridentifier = new RegExp( "^" + identifier + "$" ),

	matchExpr = {
		"ID": new RegExp( "^#(" + characterEncoding + ")" ),
		"CLASS": new RegExp( "^\\.(" + characterEncoding + ")" ),
		"TAG": new RegExp( "^(" + characterEncoding.replace( "w", "w*" ) + ")" ),
		"ATTR": new RegExp( "^" + attributes ),
		"PSEUDO": new RegExp( "^" + pseudos ),
		"CHILD": new RegExp( "^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\(" + whitespace +
			"*(even|odd|(([+-]|)(\\d*)n|)" + whitespace + "*(?:([+-]|)" + whitespace +
			"*(\\d+)|))" + whitespace + "*\\)|)", "i" ),
		"bool": new RegExp( "^(?:" + booleans + ")$", "i" ),
		// For use in libraries implementing .is()
		// We use this for POS matching in `select`
		"needsContext": new RegExp( "^" + whitespace + "*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\(" +
			whitespace + "*((?:-\\d)?\\d*)" + whitespace + "*\\)|)(?=[^-]|$)", "i" )
	},

	rnative = /^[^{]+\{\s*\[native \w/,

	// Easily-parseable/retrievable ID or TAG or CLASS selectors
	rquickExpr = /^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/,

	rinputs = /^(?:input|select|textarea|button)$/i,
	rheader = /^h\d$/i,

	rescape = /'|\\/g,

	// CSS escapes http://www.w3.org/TR/CSS21/syndata.html#escaped-characters
	runescape = new RegExp( "\\\\([\\da-f]{1,6}" + whitespace + "?|(" + whitespace + ")|.)", "ig" ),
	funescape = function( _, escaped, escapedWhitespace ) {
		var high = "0x" + escaped - 0x10000;
		// NaN means non-codepoint
		// Support: Firefox
		// Workaround erroneous numeric interpretation of +"0x"
		return high !== high || escapedWhitespace ?
			escaped :
			// BMP codepoint
			high < 0 ?
				String.fromCharCode( high + 0x10000 ) :
				// Supplemental Plane codepoint (surrogate pair)
				String.fromCharCode( high >> 10 | 0xD800, high & 0x3FF | 0xDC00 );
	};

// Optimize for push.apply( _, NodeList )
try {
	push.apply(
		(arr = slice.call( preferredDoc.childNodes )),
		preferredDoc.childNodes
	);
	// Support: Android<4.0
	// Detect silently failing push.apply
	arr[ preferredDoc.childNodes.length ].nodeType;
} catch ( e ) {
	push = { apply: arr.length ?

		// Leverage slice if possible
		function( target, els ) {
			push_native.apply( target, slice.call(els) );
		} :

		// Support: IE<9
		// Otherwise append directly
		function( target, els ) {
			var j = target.length,
				i = 0;
			// Can't trust NodeList.length
			while ( (target[j++] = els[i++]) ) {}
			target.length = j - 1;
		}
	};
}

function Sizzle( selector, context, results, seed ) {
	var match, elem, m, nodeType,
		// QSA vars
		i, groups, old, nid, newContext, newSelector;

	if ( ( context ? context.ownerDocument || context : preferredDoc ) !== document ) {
		setDocument( context );
	}

	context = context || document;
	results = results || [];

	if ( !selector || typeof selector !== "string" ) {
		return results;
	}

	if ( (nodeType = context.nodeType) !== 1 && nodeType !== 9 ) {
		return [];
	}

	if ( documentIsHTML && !seed ) {

		// Shortcuts
		if ( (match = rquickExpr.exec( selector )) ) {
			// Speed-up: Sizzle("#ID")
			if ( (m = match[1]) ) {
				if ( nodeType === 9 ) {
					elem = context.getElementById( m );
					// Check parentNode to catch when Blackberry 4.6 returns
					// nodes that are no longer in the document #6963
					if ( elem && elem.parentNode ) {
						// Handle the case where IE, Opera, and Webkit return items
						// by name instead of ID
						if ( elem.id === m ) {
							results.push( elem );
							return results;
						}
					} else {
						return results;
					}
				} else {
					// Context is not a document
					if ( context.ownerDocument && (elem = context.ownerDocument.getElementById( m )) &&
						contains( context, elem ) && elem.id === m ) {
						results.push( elem );
						return results;
					}
				}

			// Speed-up: Sizzle("TAG")
			} else if ( match[2] ) {
				push.apply( results, context.getElementsByTagName( selector ) );
				return results;

			// Speed-up: Sizzle(".CLASS")
			} else if ( (m = match[3]) && support.getElementsByClassName && context.getElementsByClassName ) {
				push.apply( results, context.getElementsByClassName( m ) );
				return results;
			}
		}

		// QSA path
		if ( support.qsa && (!rbuggyQSA || !rbuggyQSA.test( selector )) ) {
			nid = old = expando;
			newContext = context;
			newSelector = nodeType === 9 && selector;

			// qSA works strangely on Element-rooted queries
			// We can work around this by specifying an extra ID on the root
			// and working up from there (Thanks to Andrew Dupont for the technique)
			// IE 8 doesn't work on object elements
			if ( nodeType === 1 && context.nodeName.toLowerCase() !== "object" ) {
				groups = tokenize( selector );

				if ( (old = context.getAttribute("id")) ) {
					nid = old.replace( rescape, "\\$&" );
				} else {
					context.setAttribute( "id", nid );
				}
				nid = "[id='" + nid + "'] ";

				i = groups.length;
				while ( i-- ) {
					groups[i] = nid + toSelector( groups[i] );
				}
				newContext = rsibling.test( selector ) && context.parentNode || context;
				newSelector = groups.join(",");
			}

			if ( newSelector ) {
				try {
					push.apply( results,
						newContext.querySelectorAll( newSelector )
					);
					return results;
				} catch(qsaError) {
				} finally {
					if ( !old ) {
						context.removeAttribute("id");
					}
				}
			}
		}
	}

	// All others
	return select( selector.replace( rtrim, "$1" ), context, results, seed );
}

/**
 * Create key-value caches of limited size
 * @returns {Function(string, Object)} Returns the Object data after storing it on itself with
 *	property name the (space-suffixed) string and (if the cache is larger than Expr.cacheLength)
 *	deleting the oldest entry
 */
function createCache() {
	var keys = [];

	function cache( key, value ) {
		// Use (key + " ") to avoid collision with native prototype properties (see Issue #157)
		if ( keys.push( key += " " ) > Expr.cacheLength ) {
			// Only keep the most recent entries
			delete cache[ keys.shift() ];
		}
		return (cache[ key ] = value);
	}
	return cache;
}

/**
 * Mark a function for special use by Sizzle
 * @param {Function} fn The function to mark
 */
function markFunction( fn ) {
	fn[ expando ] = true;
	return fn;
}

/**
 * Support testing using an element
 * @param {Function} fn Passed the created div and expects a boolean result
 */
function assert( fn ) {
	var div = document.createElement("div");

	try {
		return !!fn( div );
	} catch (e) {
		return false;
	} finally {
		// Remove from its parent by default
		if ( div.parentNode ) {
			div.parentNode.removeChild( div );
		}
		// release memory in IE
		div = null;
	}
}

/**
 * Adds the same handler for all of the specified attrs
 * @param {String} attrs Pipe-separated list of attributes
 * @param {Function} handler The method that will be applied
 */
function addHandle( attrs, handler ) {
	var arr = attrs.split("|"),
		i = attrs.length;

	while ( i-- ) {
		Expr.attrHandle[ arr[i] ] = handler;
	}
}

/**
 * Checks document order of two siblings
 * @param {Element} a
 * @param {Element} b
 * @returns {Number} Returns less than 0 if a precedes b, greater than 0 if a follows b
 */
function siblingCheck( a, b ) {
	var cur = b && a,
		diff = cur && a.nodeType === 1 && b.nodeType === 1 &&
			( ~b.sourceIndex || MAX_NEGATIVE ) -
			( ~a.sourceIndex || MAX_NEGATIVE );

	// Use IE sourceIndex if available on both nodes
	if ( diff ) {
		return diff;
	}

	// Check if b follows a
	if ( cur ) {
		while ( (cur = cur.nextSibling) ) {
			if ( cur === b ) {
				return -1;
			}
		}
	}

	return a ? 1 : -1;
}

/**
 * Returns a function to use in pseudos for input types
 * @param {String} type
 */
function createInputPseudo( type ) {
	return function( elem ) {
		var name = elem.nodeName.toLowerCase();
		return name === "input" && elem.type === type;
	};
}

/**
 * Returns a function to use in pseudos for buttons
 * @param {String} type
 */
function createButtonPseudo( type ) {
	return function( elem ) {
		var name = elem.nodeName.toLowerCase();
		return (name === "input" || name === "button") && elem.type === type;
	};
}

/**
 * Returns a function to use in pseudos for positionals
 * @param {Function} fn
 */
function createPositionalPseudo( fn ) {
	return markFunction(function( argument ) {
		argument = +argument;
		return markFunction(function( seed, matches ) {
			var j,
				matchIndexes = fn( [], seed.length, argument ),
				i = matchIndexes.length;

			// Match elements found at the specified indexes
			while ( i-- ) {
				if ( seed[ (j = matchIndexes[i]) ] ) {
					seed[j] = !(matches[j] = seed[j]);
				}
			}
		});
	});
}

/**
 * Detect xml
 * @param {Element|Object} elem An element or a document
 */
isXML = Sizzle.isXML = function( elem ) {
	// documentElement is verified for cases where it doesn't yet exist
	// (such as loading iframes in IE - #4833)
	var documentElement = elem && (elem.ownerDocument || elem).documentElement;
	return documentElement ? documentElement.nodeName !== "HTML" : false;
};

// Expose support vars for convenience
support = Sizzle.support = {};

/**
 * Sets document-related variables once based on the current document
 * @param {Element|Object} [doc] An element or document object to use to set the document
 * @returns {Object} Returns the current document
 */
setDocument = Sizzle.setDocument = function( node ) {
	var doc = node ? node.ownerDocument || node : preferredDoc,
		parent = doc.defaultView;

	// If no document and documentElement is available, return
	if ( doc === document || doc.nodeType !== 9 || !doc.documentElement ) {
		return document;
	}

	// Set our document
	document = doc;
	docElem = doc.documentElement;

	// Support tests
	documentIsHTML = !isXML( doc );

	// Support: IE>8
	// If iframe document is assigned to "document" variable and if iframe has been reloaded,
	// IE will throw "permission denied" error when accessing "document" variable, see jQuery #13936
	// IE6-8 do not support the defaultView property so parent will be undefined
	if ( parent && parent.attachEvent && parent !== parent.top ) {
		parent.attachEvent( "onbeforeunload", function() {
			setDocument();
		});
	}

	/* Attributes
	---------------------------------------------------------------------- */

	// Support: IE<8
	// Verify that getAttribute really returns attributes and not properties (excepting IE8 booleans)
	support.attributes = assert(function( div ) {
		div.className = "i";
		return !div.getAttribute("className");
	});

	/* getElement(s)By*
	---------------------------------------------------------------------- */

	// Check if getElementsByTagName("*") returns only elements
	support.getElementsByTagName = assert(function( div ) {
		div.appendChild( doc.createComment("") );
		return !div.getElementsByTagName("*").length;
	});

	// Check if getElementsByClassName can be trusted
	support.getElementsByClassName = assert(function( div ) {
		div.innerHTML = "<div class='a'></div><div class='a i'></div>";

		// Support: Safari<4
		// Catch class over-caching
		div.firstChild.className = "i";
		// Support: Opera<10
		// Catch gEBCN failure to find non-leading classes
		return div.getElementsByClassName("i").length === 2;
	});

	// Support: IE<10
	// Check if getElementById returns elements by name
	// The broken getElementById methods don't pick up programatically-set names,
	// so use a roundabout getElementsByName test
	support.getById = assert(function( div ) {
		docElem.appendChild( div ).id = expando;
		return !doc.getElementsByName || !doc.getElementsByName( expando ).length;
	});

	// ID find and filter
	if ( support.getById ) {
		Expr.find["ID"] = function( id, context ) {
			if ( typeof context.getElementById !== strundefined && documentIsHTML ) {
				var m = context.getElementById( id );
				// Check parentNode to catch when Blackberry 4.6 returns
				// nodes that are no longer in the document #6963
				return m && m.parentNode ? [m] : [];
			}
		};
		Expr.filter["ID"] = function( id ) {
			var attrId = id.replace( runescape, funescape );
			return function( elem ) {
				return elem.getAttribute("id") === attrId;
			};
		};
	} else {
		// Support: IE6/7
		// getElementById is not reliable as a find shortcut
		delete Expr.find["ID"];

		Expr.filter["ID"] =  function( id ) {
			var attrId = id.replace( runescape, funescape );
			return function( elem ) {
				var node = typeof elem.getAttributeNode !== strundefined && elem.getAttributeNode("id");
				return node && node.value === attrId;
			};
		};
	}

	// Tag
	Expr.find["TAG"] = support.getElementsByTagName ?
		function( tag, context ) {
			if ( typeof context.getElementsByTagName !== strundefined ) {
				return context.getElementsByTagName( tag );
			}
		} :
		function( tag, context ) {
			var elem,
				tmp = [],
				i = 0,
				results = context.getElementsByTagName( tag );

			// Filter out possible comments
			if ( tag === "*" ) {
				while ( (elem = results[i++]) ) {
					if ( elem.nodeType === 1 ) {
						tmp.push( elem );
					}
				}

				return tmp;
			}
			return results;
		};

	// Class
	Expr.find["CLASS"] = support.getElementsByClassName && function( className, context ) {
		if ( typeof context.getElementsByClassName !== strundefined && documentIsHTML ) {
			return context.getElementsByClassName( className );
		}
	};

	/* QSA/matchesSelector
	---------------------------------------------------------------------- */

	// QSA and matchesSelector support

	// matchesSelector(:active) reports false when true (IE9/Opera 11.5)
	rbuggyMatches = [];

	// qSa(:focus) reports false when true (Chrome 21)
	// We allow this because of a bug in IE8/9 that throws an error
	// whenever `document.activeElement` is accessed on an iframe
	// So, we allow :focus to pass through QSA all the time to avoid the IE error
	// See http://bugs.jquery.com/ticket/13378
	rbuggyQSA = [];

	if ( (support.qsa = rnative.test( doc.querySelectorAll )) ) {
		// Build QSA regex
		// Regex strategy adopted from Diego Perini
		assert(function( div ) {
			// Select is set to empty string on purpose
			// This is to test IE's treatment of not explicitly
			// setting a boolean content attribute,
			// since its presence should be enough
			// http://bugs.jquery.com/ticket/12359
			div.innerHTML = "<select><option selected=''></option></select>";

			// Support: IE8
			// Boolean attributes and "value" are not treated correctly
			if ( !div.querySelectorAll("[selected]").length ) {
				rbuggyQSA.push( "\\[" + whitespace + "*(?:value|" + booleans + ")" );
			}

			// Webkit/Opera - :checked should return selected option elements
			// http://www.w3.org/TR/2011/REC-css3-selectors-20110929/#checked
			// IE8 throws error here and will not see later tests
			if ( !div.querySelectorAll(":checked").length ) {
				rbuggyQSA.push(":checked");
			}
		});

		assert(function( div ) {

			// Support: Opera 10-12/IE8
			// ^= $= *= and empty values
			// Should not select anything
			// Support: Windows 8 Native Apps
			// The type attribute is restricted during .innerHTML assignment
			var input = doc.createElement("input");
			input.setAttribute( "type", "hidden" );
			div.appendChild( input ).setAttribute( "t", "" );

			if ( div.querySelectorAll("[t^='']").length ) {
				rbuggyQSA.push( "[*^$]=" + whitespace + "*(?:''|\"\")" );
			}

			// FF 3.5 - :enabled/:disabled and hidden elements (hidden elements are still enabled)
			// IE8 throws error here and will not see later tests
			if ( !div.querySelectorAll(":enabled").length ) {
				rbuggyQSA.push( ":enabled", ":disabled" );
			}

			// Opera 10-11 does not throw on post-comma invalid pseudos
			div.querySelectorAll("*,:x");
			rbuggyQSA.push(",.*:");
		});
	}

	if ( (support.matchesSelector = rnative.test( (matches = docElem.webkitMatchesSelector ||
		docElem.mozMatchesSelector ||
		docElem.oMatchesSelector ||
		docElem.msMatchesSelector) )) ) {

		assert(function( div ) {
			// Check to see if it's possible to do matchesSelector
			// on a disconnected node (IE 9)
			support.disconnectedMatch = matches.call( div, "div" );

			// This should fail with an exception
			// Gecko does not error, returns false instead
			matches.call( div, "[s!='']:x" );
			rbuggyMatches.push( "!=", pseudos );
		});
	}

	rbuggyQSA = rbuggyQSA.length && new RegExp( rbuggyQSA.join("|") );
	rbuggyMatches = rbuggyMatches.length && new RegExp( rbuggyMatches.join("|") );

	/* Contains
	---------------------------------------------------------------------- */

	// Element contains another
	// Purposefully does not implement inclusive descendent
	// As in, an element does not contain itself
	contains = rnative.test( docElem.contains ) || docElem.compareDocumentPosition ?
		function( a, b ) {
			var adown = a.nodeType === 9 ? a.documentElement : a,
				bup = b && b.parentNode;
			return a === bup || !!( bup && bup.nodeType === 1 && (
				adown.contains ?
					adown.contains( bup ) :
					a.compareDocumentPosition && a.compareDocumentPosition( bup ) & 16
			));
		} :
		function( a, b ) {
			if ( b ) {
				while ( (b = b.parentNode) ) {
					if ( b === a ) {
						return true;
					}
				}
			}
			return false;
		};

	/* Sorting
	---------------------------------------------------------------------- */

	// Document order sorting
	sortOrder = docElem.compareDocumentPosition ?
	function( a, b ) {

		// Flag for duplicate removal
		if ( a === b ) {
			hasDuplicate = true;
			return 0;
		}

		var compare = b.compareDocumentPosition && a.compareDocumentPosition && a.compareDocumentPosition( b );

		if ( compare ) {
			// Disconnected nodes
			if ( compare & 1 ||
				(!support.sortDetached && b.compareDocumentPosition( a ) === compare) ) {

				// Choose the first element that is related to our preferred document
				if ( a === doc || contains(preferredDoc, a) ) {
					return -1;
				}
				if ( b === doc || contains(preferredDoc, b) ) {
					return 1;
				}

				// Maintain original order
				return sortInput ?
					( indexOf.call( sortInput, a ) - indexOf.call( sortInput, b ) ) :
					0;
			}

			return compare & 4 ? -1 : 1;
		}

		// Not directly comparable, sort on existence of method
		return a.compareDocumentPosition ? -1 : 1;
	} :
	function( a, b ) {
		var cur,
			i = 0,
			aup = a.parentNode,
			bup = b.parentNode,
			ap = [ a ],
			bp = [ b ];

		// Exit early if the nodes are identical
		if ( a === b ) {
			hasDuplicate = true;
			return 0;

		// Parentless nodes are either documents or disconnected
		} else if ( !aup || !bup ) {
			return a === doc ? -1 :
				b === doc ? 1 :
				aup ? -1 :
				bup ? 1 :
				sortInput ?
				( indexOf.call( sortInput, a ) - indexOf.call( sortInput, b ) ) :
				0;

		// If the nodes are siblings, we can do a quick check
		} else if ( aup === bup ) {
			return siblingCheck( a, b );
		}

		// Otherwise we need full lists of their ancestors for comparison
		cur = a;
		while ( (cur = cur.parentNode) ) {
			ap.unshift( cur );
		}
		cur = b;
		while ( (cur = cur.parentNode) ) {
			bp.unshift( cur );
		}

		// Walk down the tree looking for a discrepancy
		while ( ap[i] === bp[i] ) {
			i++;
		}

		return i ?
			// Do a sibling check if the nodes have a common ancestor
			siblingCheck( ap[i], bp[i] ) :

			// Otherwise nodes in our document sort first
			ap[i] === preferredDoc ? -1 :
			bp[i] === preferredDoc ? 1 :
			0;
	};

	return doc;
};

Sizzle.matches = function( expr, elements ) {
	return Sizzle( expr, null, null, elements );
};

Sizzle.matchesSelector = function( elem, expr ) {
	// Set document vars if needed
	if ( ( elem.ownerDocument || elem ) !== document ) {
		setDocument( elem );
	}

	// Make sure that attribute selectors are quoted
	expr = expr.replace( rattributeQuotes, "='$1']" );

	if ( support.matchesSelector && documentIsHTML &&
		( !rbuggyMatches || !rbuggyMatches.test( expr ) ) &&
		( !rbuggyQSA     || !rbuggyQSA.test( expr ) ) ) {

		try {
			var ret = matches.call( elem, expr );

			// IE 9's matchesSelector returns false on disconnected nodes
			if ( ret || support.disconnectedMatch ||
					// As well, disconnected nodes are said to be in a document
					// fragment in IE 9
					elem.document && elem.document.nodeType !== 11 ) {
				return ret;
			}
		} catch(e) {}
	}

	return Sizzle( expr, document, null, [elem] ).length > 0;
};

Sizzle.contains = function( context, elem ) {
	// Set document vars if needed
	if ( ( context.ownerDocument || context ) !== document ) {
		setDocument( context );
	}
	return contains( context, elem );
};

Sizzle.attr = function( elem, name ) {
	// Set document vars if needed
	if ( ( elem.ownerDocument || elem ) !== document ) {
		setDocument( elem );
	}

	var fn = Expr.attrHandle[ name.toLowerCase() ],
		// Don't get fooled by Object.prototype properties (jQuery #13807)
		val = fn && hasOwn.call( Expr.attrHandle, name.toLowerCase() ) ?
			fn( elem, name, !documentIsHTML ) :
			undefined;

	return val === undefined ?
		support.attributes || !documentIsHTML ?
			elem.getAttribute( name ) :
			(val = elem.getAttributeNode(name)) && val.specified ?
				val.value :
				null :
		val;
};

Sizzle.error = function( msg ) {
	throw new Error( "Syntax error, unrecognized expression: " + msg );
};

/**
 * Document sorting and removing duplicates
 * @param {ArrayLike} results
 */
Sizzle.uniqueSort = function( results ) {
	var elem,
		duplicates = [],
		j = 0,
		i = 0;

	// Unless we *know* we can detect duplicates, assume their presence
	hasDuplicate = !support.detectDuplicates;
	sortInput = !support.sortStable && results.slice( 0 );
	results.sort( sortOrder );

	if ( hasDuplicate ) {
		while ( (elem = results[i++]) ) {
			if ( elem === results[ i ] ) {
				j = duplicates.push( i );
			}
		}
		while ( j-- ) {
			results.splice( duplicates[ j ], 1 );
		}
	}

	return results;
};

/**
 * Utility function for retrieving the text value of an array of DOM nodes
 * @param {Array|Element} elem
 */
getText = Sizzle.getText = function( elem ) {
	var node,
		ret = "",
		i = 0,
		nodeType = elem.nodeType;

	if ( !nodeType ) {
		// If no nodeType, this is expected to be an array
		for ( ; (node = elem[i]); i++ ) {
			// Do not traverse comment nodes
			ret += getText( node );
		}
	} else if ( nodeType === 1 || nodeType === 9 || nodeType === 11 ) {
		// Use textContent for elements
		// innerText usage removed for consistency of new lines (see #11153)
		if ( typeof elem.textContent === "string" ) {
			return elem.textContent;
		} else {
			// Traverse its children
			for ( elem = elem.firstChild; elem; elem = elem.nextSibling ) {
				ret += getText( elem );
			}
		}
	} else if ( nodeType === 3 || nodeType === 4 ) {
		return elem.nodeValue;
	}
	// Do not include comment or processing instruction nodes

	return ret;
};

Expr = Sizzle.selectors = {

	// Can be adjusted by the user
	cacheLength: 50,

	createPseudo: markFunction,

	match: matchExpr,

	attrHandle: {},

	find: {},

	relative: {
		">": { dir: "parentNode", first: true },
		" ": { dir: "parentNode" },
		"+": { dir: "previousSibling", first: true },
		"~": { dir: "previousSibling" }
	},

	preFilter: {
		"ATTR": function( match ) {
			match[1] = match[1].replace( runescape, funescape );

			// Move the given value to match[3] whether quoted or unquoted
			match[3] = ( match[4] || match[5] || "" ).replace( runescape, funescape );

			if ( match[2] === "~=" ) {
				match[3] = " " + match[3] + " ";
			}

			return match.slice( 0, 4 );
		},

		"CHILD": function( match ) {
			/* matches from matchExpr["CHILD"]
				1 type (only|nth|...)
				2 what (child|of-type)
				3 argument (even|odd|\d*|\d*n([+-]\d+)?|...)
				4 xn-component of xn+y argument ([+-]?\d*n|)
				5 sign of xn-component
				6 x of xn-component
				7 sign of y-component
				8 y of y-component
			*/
			match[1] = match[1].toLowerCase();

			if ( match[1].slice( 0, 3 ) === "nth" ) {
				// nth-* requires argument
				if ( !match[3] ) {
					Sizzle.error( match[0] );
				}

				// numeric x and y parameters for Expr.filter.CHILD
				// remember that false/true cast respectively to 0/1
				match[4] = +( match[4] ? match[5] + (match[6] || 1) : 2 * ( match[3] === "even" || match[3] === "odd" ) );
				match[5] = +( ( match[7] + match[8] ) || match[3] === "odd" );

			// other types prohibit arguments
			} else if ( match[3] ) {
				Sizzle.error( match[0] );
			}

			return match;
		},

		"PSEUDO": function( match ) {
			var excess,
				unquoted = !match[5] && match[2];

			if ( matchExpr["CHILD"].test( match[0] ) ) {
				return null;
			}

			// Accept quoted arguments as-is
			if ( match[3] && match[4] !== undefined ) {
				match[2] = match[4];

			// Strip excess characters from unquoted arguments
			} else if ( unquoted && rpseudo.test( unquoted ) &&
				// Get excess from tokenize (recursively)
				(excess = tokenize( unquoted, true )) &&
				// advance to the next closing parenthesis
				(excess = unquoted.indexOf( ")", unquoted.length - excess ) - unquoted.length) ) {

				// excess is a negative index
				match[0] = match[0].slice( 0, excess );
				match[2] = unquoted.slice( 0, excess );
			}

			// Return only captures needed by the pseudo filter method (type and argument)
			return match.slice( 0, 3 );
		}
	},

	filter: {

		"TAG": function( nodeNameSelector ) {
			var nodeName = nodeNameSelector.replace( runescape, funescape ).toLowerCase();
			return nodeNameSelector === "*" ?
				function() { return true; } :
				function( elem ) {
					return elem.nodeName && elem.nodeName.toLowerCase() === nodeName;
				};
		},

		"CLASS": function( className ) {
			var pattern = classCache[ className + " " ];

			return pattern ||
				(pattern = new RegExp( "(^|" + whitespace + ")" + className + "(" + whitespace + "|$)" )) &&
				classCache( className, function( elem ) {
					return pattern.test( typeof elem.className === "string" && elem.className || typeof elem.getAttribute !== strundefined && elem.getAttribute("class") || "" );
				});
		},

		"ATTR": function( name, operator, check ) {
			return function( elem ) {
				var result = Sizzle.attr( elem, name );

				if ( result == null ) {
					return operator === "!=";
				}
				if ( !operator ) {
					return true;
				}

				result += "";

				return operator === "=" ? result === check :
					operator === "!=" ? result !== check :
					operator === "^=" ? check && result.indexOf( check ) === 0 :
					operator === "*=" ? check && result.indexOf( check ) > -1 :
					operator === "$=" ? check && result.slice( -check.length ) === check :
					operator === "~=" ? ( " " + result + " " ).indexOf( check ) > -1 :
					operator === "|=" ? result === check || result.slice( 0, check.length + 1 ) === check + "-" :
					false;
			};
		},

		"CHILD": function( type, what, argument, first, last ) {
			var simple = type.slice( 0, 3 ) !== "nth",
				forward = type.slice( -4 ) !== "last",
				ofType = what === "of-type";

			return first === 1 && last === 0 ?

				// Shortcut for :nth-*(n)
				function( elem ) {
					return !!elem.parentNode;
				} :

				function( elem, context, xml ) {
					var cache, outerCache, node, diff, nodeIndex, start,
						dir = simple !== forward ? "nextSibling" : "previousSibling",
						parent = elem.parentNode,
						name = ofType && elem.nodeName.toLowerCase(),
						useCache = !xml && !ofType;

					if ( parent ) {

						// :(first|last|only)-(child|of-type)
						if ( simple ) {
							while ( dir ) {
								node = elem;
								while ( (node = node[ dir ]) ) {
									if ( ofType ? node.nodeName.toLowerCase() === name : node.nodeType === 1 ) {
										return false;
									}
								}
								// Reverse direction for :only-* (if we haven't yet done so)
								start = dir = type === "only" && !start && "nextSibling";
							}
							return true;
						}

						start = [ forward ? parent.firstChild : parent.lastChild ];

						// non-xml :nth-child(...) stores cache data on `parent`
						if ( forward && useCache ) {
							// Seek `elem` from a previously-cached index
							outerCache = parent[ expando ] || (parent[ expando ] = {});
							cache = outerCache[ type ] || [];
							nodeIndex = cache[0] === dirruns && cache[1];
							diff = cache[0] === dirruns && cache[2];
							node = nodeIndex && parent.childNodes[ nodeIndex ];

							while ( (node = ++nodeIndex && node && node[ dir ] ||

								// Fallback to seeking `elem` from the start
								(diff = nodeIndex = 0) || start.pop()) ) {

								// When found, cache indexes on `parent` and break
								if ( node.nodeType === 1 && ++diff && node === elem ) {
									outerCache[ type ] = [ dirruns, nodeIndex, diff ];
									break;
								}
							}

						// Use previously-cached element index if available
						} else if ( useCache && (cache = (elem[ expando ] || (elem[ expando ] = {}))[ type ]) && cache[0] === dirruns ) {
							diff = cache[1];

						// xml :nth-child(...) or :nth-last-child(...) or :nth(-last)?-of-type(...)
						} else {
							// Use the same loop as above to seek `elem` from the start
							while ( (node = ++nodeIndex && node && node[ dir ] ||
								(diff = nodeIndex = 0) || start.pop()) ) {

								if ( ( ofType ? node.nodeName.toLowerCase() === name : node.nodeType === 1 ) && ++diff ) {
									// Cache the index of each encountered element
									if ( useCache ) {
										(node[ expando ] || (node[ expando ] = {}))[ type ] = [ dirruns, diff ];
									}

									if ( node === elem ) {
										break;
									}
								}
							}
						}

						// Incorporate the offset, then check against cycle size
						diff -= last;
						return diff === first || ( diff % first === 0 && diff / first >= 0 );
					}
				};
		},

		"PSEUDO": function( pseudo, argument ) {
			// pseudo-class names are case-insensitive
			// http://www.w3.org/TR/selectors/#pseudo-classes
			// Prioritize by case sensitivity in case custom pseudos are added with uppercase letters
			// Remember that setFilters inherits from pseudos
			var args,
				fn = Expr.pseudos[ pseudo ] || Expr.setFilters[ pseudo.toLowerCase() ] ||
					Sizzle.error( "unsupported pseudo: " + pseudo );

			// The user may use createPseudo to indicate that
			// arguments are needed to create the filter function
			// just as Sizzle does
			if ( fn[ expando ] ) {
				return fn( argument );
			}

			// But maintain support for old signatures
			if ( fn.length > 1 ) {
				args = [ pseudo, pseudo, "", argument ];
				return Expr.setFilters.hasOwnProperty( pseudo.toLowerCase() ) ?
					markFunction(function( seed, matches ) {
						var idx,
							matched = fn( seed, argument ),
							i = matched.length;
						while ( i-- ) {
							idx = indexOf.call( seed, matched[i] );
							seed[ idx ] = !( matches[ idx ] = matched[i] );
						}
					}) :
					function( elem ) {
						return fn( elem, 0, args );
					};
			}

			return fn;
		}
	},

	pseudos: {
		// Potentially complex pseudos
		"not": markFunction(function( selector ) {
			// Trim the selector passed to compile
			// to avoid treating leading and trailing
			// spaces as combinators
			var input = [],
				results = [],
				matcher = compile( selector.replace( rtrim, "$1" ) );

			return matcher[ expando ] ?
				markFunction(function( seed, matches, context, xml ) {
					var elem,
						unmatched = matcher( seed, null, xml, [] ),
						i = seed.length;

					// Match elements unmatched by `matcher`
					while ( i-- ) {
						if ( (elem = unmatched[i]) ) {
							seed[i] = !(matches[i] = elem);
						}
					}
				}) :
				function( elem, context, xml ) {
					input[0] = elem;
					matcher( input, null, xml, results );
					return !results.pop();
				};
		}),

		"has": markFunction(function( selector ) {
			return function( elem ) {
				return Sizzle( selector, elem ).length > 0;
			};
		}),

		"contains": markFunction(function( text ) {
			return function( elem ) {
				return ( elem.textContent || elem.innerText || getText( elem ) ).indexOf( text ) > -1;
			};
		}),

		// "Whether an element is represented by a :lang() selector
		// is based solely on the element's language value
		// being equal to the identifier C,
		// or beginning with the identifier C immediately followed by "-".
		// The matching of C against the element's language value is performed case-insensitively.
		// The identifier C does not have to be a valid language name."
		// http://www.w3.org/TR/selectors/#lang-pseudo
		"lang": markFunction( function( lang ) {
			// lang value must be a valid identifier
			if ( !ridentifier.test(lang || "") ) {
				Sizzle.error( "unsupported lang: " + lang );
			}
			lang = lang.replace( runescape, funescape ).toLowerCase();
			return function( elem ) {
				var elemLang;
				do {
					if ( (elemLang = documentIsHTML ?
						elem.lang :
						elem.getAttribute("xml:lang") || elem.getAttribute("lang")) ) {

						elemLang = elemLang.toLowerCase();
						return elemLang === lang || elemLang.indexOf( lang + "-" ) === 0;
					}
				} while ( (elem = elem.parentNode) && elem.nodeType === 1 );
				return false;
			};
		}),

		// Miscellaneous
		"target": function( elem ) {
			var hash = window.location && window.location.hash;
			return hash && hash.slice( 1 ) === elem.id;
		},

		"root": function( elem ) {
			return elem === docElem;
		},

		"focus": function( elem ) {
			return elem === document.activeElement && (!document.hasFocus || document.hasFocus()) && !!(elem.type || elem.href || ~elem.tabIndex);
		},

		// Boolean properties
		"enabled": function( elem ) {
			return elem.disabled === false;
		},

		"disabled": function( elem ) {
			return elem.disabled === true;
		},

		"checked": function( elem ) {
			// In CSS3, :checked should return both checked and selected elements
			// http://www.w3.org/TR/2011/REC-css3-selectors-20110929/#checked
			var nodeName = elem.nodeName.toLowerCase();
			return (nodeName === "input" && !!elem.checked) || (nodeName === "option" && !!elem.selected);
		},

		"selected": function( elem ) {
			// Accessing this property makes selected-by-default
			// options in Safari work properly
			if ( elem.parentNode ) {
				elem.parentNode.selectedIndex;
			}

			return elem.selected === true;
		},

		// Contents
		"empty": function( elem ) {
			// http://www.w3.org/TR/selectors/#empty-pseudo
			// :empty is only affected by element nodes and content nodes(including text(3), cdata(4)),
			//   not comment, processing instructions, or others
			// Thanks to Diego Perini for the nodeName shortcut
			//   Greater than "@" means alpha characters (specifically not starting with "#" or "?")
			for ( elem = elem.firstChild; elem; elem = elem.nextSibling ) {
				if ( elem.nodeName > "@" || elem.nodeType === 3 || elem.nodeType === 4 ) {
					return false;
				}
			}
			return true;
		},

		"parent": function( elem ) {
			return !Expr.pseudos["empty"]( elem );
		},

		// Element/input types
		"header": function( elem ) {
			return rheader.test( elem.nodeName );
		},

		"input": function( elem ) {
			return rinputs.test( elem.nodeName );
		},

		"button": function( elem ) {
			var name = elem.nodeName.toLowerCase();
			return name === "input" && elem.type === "button" || name === "button";
		},

		"text": function( elem ) {
			var attr;
			// IE6 and 7 will map elem.type to 'text' for new HTML5 types (search, etc)
			// use getAttribute instead to test this case
			return elem.nodeName.toLowerCase() === "input" &&
				elem.type === "text" &&
				( (attr = elem.getAttribute("type")) == null || attr.toLowerCase() === elem.type );
		},

		// Position-in-collection
		"first": createPositionalPseudo(function() {
			return [ 0 ];
		}),

		"last": createPositionalPseudo(function( matchIndexes, length ) {
			return [ length - 1 ];
		}),

		"eq": createPositionalPseudo(function( matchIndexes, length, argument ) {
			return [ argument < 0 ? argument + length : argument ];
		}),

		"even": createPositionalPseudo(function( matchIndexes, length ) {
			var i = 0;
			for ( ; i < length; i += 2 ) {
				matchIndexes.push( i );
			}
			return matchIndexes;
		}),

		"odd": createPositionalPseudo(function( matchIndexes, length ) {
			var i = 1;
			for ( ; i < length; i += 2 ) {
				matchIndexes.push( i );
			}
			return matchIndexes;
		}),

		"lt": createPositionalPseudo(function( matchIndexes, length, argument ) {
			var i = argument < 0 ? argument + length : argument;
			for ( ; --i >= 0; ) {
				matchIndexes.push( i );
			}
			return matchIndexes;
		}),

		"gt": createPositionalPseudo(function( matchIndexes, length, argument ) {
			var i = argument < 0 ? argument + length : argument;
			for ( ; ++i < length; ) {
				matchIndexes.push( i );
			}
			return matchIndexes;
		})
	}
};

Expr.pseudos["nth"] = Expr.pseudos["eq"];

// Add button/input type pseudos
for ( i in { radio: true, checkbox: true, file: true, password: true, image: true } ) {
	Expr.pseudos[ i ] = createInputPseudo( i );
}
for ( i in { submit: true, reset: true } ) {
	Expr.pseudos[ i ] = createButtonPseudo( i );
}

// Easy API for creating new setFilters
function setFilters() {}
setFilters.prototype = Expr.filters = Expr.pseudos;
Expr.setFilters = new setFilters();

function tokenize( selector, parseOnly ) {
	var matched, match, tokens, type,
		soFar, groups, preFilters,
		cached = tokenCache[ selector + " " ];

	if ( cached ) {
		return parseOnly ? 0 : cached.slice( 0 );
	}

	soFar = selector;
	groups = [];
	preFilters = Expr.preFilter;

	while ( soFar ) {

		// Comma and first run
		if ( !matched || (match = rcomma.exec( soFar )) ) {
			if ( match ) {
				// Don't consume trailing commas as valid
				soFar = soFar.slice( match[0].length ) || soFar;
			}
			groups.push( tokens = [] );
		}

		matched = false;

		// Combinators
		if ( (match = rcombinators.exec( soFar )) ) {
			matched = match.shift();
			tokens.push({
				value: matched,
				// Cast descendant combinators to space
				type: match[0].replace( rtrim, " " )
			});
			soFar = soFar.slice( matched.length );
		}

		// Filters
		for ( type in Expr.filter ) {
			if ( (match = matchExpr[ type ].exec( soFar )) && (!preFilters[ type ] ||
				(match = preFilters[ type ]( match ))) ) {
				matched = match.shift();
				tokens.push({
					value: matched,
					type: type,
					matches: match
				});
				soFar = soFar.slice( matched.length );
			}
		}

		if ( !matched ) {
			break;
		}
	}

	// Return the length of the invalid excess
	// if we're just parsing
	// Otherwise, throw an error or return tokens
	return parseOnly ?
		soFar.length :
		soFar ?
			Sizzle.error( selector ) :
			// Cache the tokens
			tokenCache( selector, groups ).slice( 0 );
}

function toSelector( tokens ) {
	var i = 0,
		len = tokens.length,
		selector = "";
	for ( ; i < len; i++ ) {
		selector += tokens[i].value;
	}
	return selector;
}

function addCombinator( matcher, combinator, base ) {
	var dir = combinator.dir,
		checkNonElements = base && dir === "parentNode",
		doneName = done++;

	return combinator.first ?
		// Check against closest ancestor/preceding element
		function( elem, context, xml ) {
			while ( (elem = elem[ dir ]) ) {
				if ( elem.nodeType === 1 || checkNonElements ) {
					return matcher( elem, context, xml );
				}
			}
		} :

		// Check against all ancestor/preceding elements
		function( elem, context, xml ) {
			var data, cache, outerCache,
				dirkey = dirruns + " " + doneName;

			// We can't set arbitrary data on XML nodes, so they don't benefit from dir caching
			if ( xml ) {
				while ( (elem = elem[ dir ]) ) {
					if ( elem.nodeType === 1 || checkNonElements ) {
						if ( matcher( elem, context, xml ) ) {
							return true;
						}
					}
				}
			} else {
				while ( (elem = elem[ dir ]) ) {
					if ( elem.nodeType === 1 || checkNonElements ) {
						outerCache = elem[ expando ] || (elem[ expando ] = {});
						if ( (cache = outerCache[ dir ]) && cache[0] === dirkey ) {
							if ( (data = cache[1]) === true || data === cachedruns ) {
								return data === true;
							}
						} else {
							cache = outerCache[ dir ] = [ dirkey ];
							cache[1] = matcher( elem, context, xml ) || cachedruns;
							if ( cache[1] === true ) {
								return true;
							}
						}
					}
				}
			}
		};
}

function elementMatcher( matchers ) {
	return matchers.length > 1 ?
		function( elem, context, xml ) {
			var i = matchers.length;
			while ( i-- ) {
				if ( !matchers[i]( elem, context, xml ) ) {
					return false;
				}
			}
			return true;
		} :
		matchers[0];
}

function condense( unmatched, map, filter, context, xml ) {
	var elem,
		newUnmatched = [],
		i = 0,
		len = unmatched.length,
		mapped = map != null;

	for ( ; i < len; i++ ) {
		if ( (elem = unmatched[i]) ) {
			if ( !filter || filter( elem, context, xml ) ) {
				newUnmatched.push( elem );
				if ( mapped ) {
					map.push( i );
				}
			}
		}
	}

	return newUnmatched;
}

function setMatcher( preFilter, selector, matcher, postFilter, postFinder, postSelector ) {
	if ( postFilter && !postFilter[ expando ] ) {
		postFilter = setMatcher( postFilter );
	}
	if ( postFinder && !postFinder[ expando ] ) {
		postFinder = setMatcher( postFinder, postSelector );
	}
	return markFunction(function( seed, results, context, xml ) {
		var temp, i, elem,
			preMap = [],
			postMap = [],
			preexisting = results.length,

			// Get initial elements from seed or context
			elems = seed || multipleContexts( selector || "*", context.nodeType ? [ context ] : context, [] ),

			// Prefilter to get matcher input, preserving a map for seed-results synchronization
			matcherIn = preFilter && ( seed || !selector ) ?
				condense( elems, preMap, preFilter, context, xml ) :
				elems,

			matcherOut = matcher ?
				// If we have a postFinder, or filtered seed, or non-seed postFilter or preexisting results,
				postFinder || ( seed ? preFilter : preexisting || postFilter ) ?

					// ...intermediate processing is necessary
					[] :

					// ...otherwise use results directly
					results :
				matcherIn;

		// Find primary matches
		if ( matcher ) {
			matcher( matcherIn, matcherOut, context, xml );
		}

		// Apply postFilter
		if ( postFilter ) {
			temp = condense( matcherOut, postMap );
			postFilter( temp, [], context, xml );

			// Un-match failing elements by moving them back to matcherIn
			i = temp.length;
			while ( i-- ) {
				if ( (elem = temp[i]) ) {
					matcherOut[ postMap[i] ] = !(matcherIn[ postMap[i] ] = elem);
				}
			}
		}

		if ( seed ) {
			if ( postFinder || preFilter ) {
				if ( postFinder ) {
					// Get the final matcherOut by condensing this intermediate into postFinder contexts
					temp = [];
					i = matcherOut.length;
					while ( i-- ) {
						if ( (elem = matcherOut[i]) ) {
							// Restore matcherIn since elem is not yet a final match
							temp.push( (matcherIn[i] = elem) );
						}
					}
					postFinder( null, (matcherOut = []), temp, xml );
				}

				// Move matched elements from seed to results to keep them synchronized
				i = matcherOut.length;
				while ( i-- ) {
					if ( (elem = matcherOut[i]) &&
						(temp = postFinder ? indexOf.call( seed, elem ) : preMap[i]) > -1 ) {

						seed[temp] = !(results[temp] = elem);
					}
				}
			}

		// Add elements to results, through postFinder if defined
		} else {
			matcherOut = condense(
				matcherOut === results ?
					matcherOut.splice( preexisting, matcherOut.length ) :
					matcherOut
			);
			if ( postFinder ) {
				postFinder( null, results, matcherOut, xml );
			} else {
				push.apply( results, matcherOut );
			}
		}
	});
}

function matcherFromTokens( tokens ) {
	var checkContext, matcher, j,
		len = tokens.length,
		leadingRelative = Expr.relative[ tokens[0].type ],
		implicitRelative = leadingRelative || Expr.relative[" "],
		i = leadingRelative ? 1 : 0,

		// The foundational matcher ensures that elements are reachable from top-level context(s)
		matchContext = addCombinator( function( elem ) {
			return elem === checkContext;
		}, implicitRelative, true ),
		matchAnyContext = addCombinator( function( elem ) {
			return indexOf.call( checkContext, elem ) > -1;
		}, implicitRelative, true ),
		matchers = [ function( elem, context, xml ) {
			return ( !leadingRelative && ( xml || context !== outermostContext ) ) || (
				(checkContext = context).nodeType ?
					matchContext( elem, context, xml ) :
					matchAnyContext( elem, context, xml ) );
		} ];

	for ( ; i < len; i++ ) {
		if ( (matcher = Expr.relative[ tokens[i].type ]) ) {
			matchers = [ addCombinator(elementMatcher( matchers ), matcher) ];
		} else {
			matcher = Expr.filter[ tokens[i].type ].apply( null, tokens[i].matches );

			// Return special upon seeing a positional matcher
			if ( matcher[ expando ] ) {
				// Find the next relative operator (if any) for proper handling
				j = ++i;
				for ( ; j < len; j++ ) {
					if ( Expr.relative[ tokens[j].type ] ) {
						break;
					}
				}
				return setMatcher(
					i > 1 && elementMatcher( matchers ),
					i > 1 && toSelector(
						// If the preceding token was a descendant combinator, insert an implicit any-element `*`
						tokens.slice( 0, i - 1 ).concat({ value: tokens[ i - 2 ].type === " " ? "*" : "" })
					).replace( rtrim, "$1" ),
					matcher,
					i < j && matcherFromTokens( tokens.slice( i, j ) ),
					j < len && matcherFromTokens( (tokens = tokens.slice( j )) ),
					j < len && toSelector( tokens )
				);
			}
			matchers.push( matcher );
		}
	}

	return elementMatcher( matchers );
}

function matcherFromGroupMatchers( elementMatchers, setMatchers ) {
	// A counter to specify which element is currently being matched
	var matcherCachedRuns = 0,
		bySet = setMatchers.length > 0,
		byElement = elementMatchers.length > 0,
		superMatcher = function( seed, context, xml, results, expandContext ) {
			var elem, j, matcher,
				setMatched = [],
				matchedCount = 0,
				i = "0",
				unmatched = seed && [],
				outermost = expandContext != null,
				contextBackup = outermostContext,
				// We must always have either seed elements or context
				elems = seed || byElement && Expr.find["TAG"]( "*", expandContext && context.parentNode || context ),
				// Use integer dirruns iff this is the outermost matcher
				dirrunsUnique = (dirruns += contextBackup == null ? 1 : Math.random() || 0.1);

			if ( outermost ) {
				outermostContext = context !== document && context;
				cachedruns = matcherCachedRuns;
			}

			// Add elements passing elementMatchers directly to results
			// Keep `i` a string if there are no elements so `matchedCount` will be "00" below
			for ( ; (elem = elems[i]) != null; i++ ) {
				if ( byElement && elem ) {
					j = 0;
					while ( (matcher = elementMatchers[j++]) ) {
						if ( matcher( elem, context, xml ) ) {
							results.push( elem );
							break;
						}
					}
					if ( outermost ) {
						dirruns = dirrunsUnique;
						cachedruns = ++matcherCachedRuns;
					}
				}

				// Track unmatched elements for set filters
				if ( bySet ) {
					// They will have gone through all possible matchers
					if ( (elem = !matcher && elem) ) {
						matchedCount--;
					}

					// Lengthen the array for every element, matched or not
					if ( seed ) {
						unmatched.push( elem );
					}
				}
			}

			// Apply set filters to unmatched elements
			matchedCount += i;
			if ( bySet && i !== matchedCount ) {
				j = 0;
				while ( (matcher = setMatchers[j++]) ) {
					matcher( unmatched, setMatched, context, xml );
				}

				if ( seed ) {
					// Reintegrate element matches to eliminate the need for sorting
					if ( matchedCount > 0 ) {
						while ( i-- ) {
							if ( !(unmatched[i] || setMatched[i]) ) {
								setMatched[i] = pop.call( results );
							}
						}
					}

					// Discard index placeholder values to get only actual matches
					setMatched = condense( setMatched );
				}

				// Add matches to results
				push.apply( results, setMatched );

				// Seedless set matches succeeding multiple successful matchers stipulate sorting
				if ( outermost && !seed && setMatched.length > 0 &&
					( matchedCount + setMatchers.length ) > 1 ) {

					Sizzle.uniqueSort( results );
				}
			}

			// Override manipulation of globals by nested matchers
			if ( outermost ) {
				dirruns = dirrunsUnique;
				outermostContext = contextBackup;
			}

			return unmatched;
		};

	return bySet ?
		markFunction( superMatcher ) :
		superMatcher;
}

compile = Sizzle.compile = function( selector, group /* Internal Use Only */ ) {
	var i,
		setMatchers = [],
		elementMatchers = [],
		cached = compilerCache[ selector + " " ];

	if ( !cached ) {
		// Generate a function of recursive functions that can be used to check each element
		if ( !group ) {
			group = tokenize( selector );
		}
		i = group.length;
		while ( i-- ) {
			cached = matcherFromTokens( group[i] );
			if ( cached[ expando ] ) {
				setMatchers.push( cached );
			} else {
				elementMatchers.push( cached );
			}
		}

		// Cache the compiled function
		cached = compilerCache( selector, matcherFromGroupMatchers( elementMatchers, setMatchers ) );
	}
	return cached;
};

function multipleContexts( selector, contexts, results ) {
	var i = 0,
		len = contexts.length;
	for ( ; i < len; i++ ) {
		Sizzle( selector, contexts[i], results );
	}
	return results;
}

function select( selector, context, results, seed ) {
	var i, tokens, token, type, find,
		match = tokenize( selector );

	if ( !seed ) {
		// Try to minimize operations if there is only one group
		if ( match.length === 1 ) {

			// Take a shortcut and set the context if the root selector is an ID
			tokens = match[0] = match[0].slice( 0 );
			if ( tokens.length > 2 && (token = tokens[0]).type === "ID" &&
					support.getById && context.nodeType === 9 && documentIsHTML &&
					Expr.relative[ tokens[1].type ] ) {

				context = ( Expr.find["ID"]( token.matches[0].replace(runescape, funescape), context ) || [] )[0];
				if ( !context ) {
					return results;
				}
				selector = selector.slice( tokens.shift().value.length );
			}

			// Fetch a seed set for right-to-left matching
			i = matchExpr["needsContext"].test( selector ) ? 0 : tokens.length;
			while ( i-- ) {
				token = tokens[i];

				// Abort if we hit a combinator
				if ( Expr.relative[ (type = token.type) ] ) {
					break;
				}
				if ( (find = Expr.find[ type ]) ) {
					// Search, expanding context for leading sibling combinators
					if ( (seed = find(
						token.matches[0].replace( runescape, funescape ),
						rsibling.test( tokens[0].type ) && context.parentNode || context
					)) ) {

						// If seed is empty or no tokens remain, we can return early
						tokens.splice( i, 1 );
						selector = seed.length && toSelector( tokens );
						if ( !selector ) {
							push.apply( results, seed );
							return results;
						}

						break;
					}
				}
			}
		}
	}

	// Compile and execute a filtering function
	// Provide `match` to avoid retokenization if we modified the selector above
	compile( selector, match )(
		seed,
		context,
		!documentIsHTML,
		results,
		rsibling.test( selector )
	);
	return results;
}

// One-time assignments

// Sort stability
support.sortStable = expando.split("").sort( sortOrder ).join("") === expando;

// Support: Chrome<14
// Always assume duplicates if they aren't passed to the comparison function
support.detectDuplicates = hasDuplicate;

// Initialize against the default document
setDocument();

// Support: Webkit<537.32 - Safari 6.0.3/Chrome 25 (fixed in Chrome 27)
// Detached nodes confoundingly follow *each other*
support.sortDetached = assert(function( div1 ) {
	// Should return 1, but returns 4 (following)
	return div1.compareDocumentPosition( document.createElement("div") ) & 1;
});

// Support: IE<8
// Prevent attribute/property "interpolation"
// http://msdn.microsoft.com/en-us/library/ms536429%28VS.85%29.aspx
if ( !assert(function( div ) {
	div.innerHTML = "<a href='#'></a>";
	return div.firstChild.getAttribute("href") === "#" ;
}) ) {
	addHandle( "type|href|height|width", function( elem, name, isXML ) {
		if ( !isXML ) {
			return elem.getAttribute( name, name.toLowerCase() === "type" ? 1 : 2 );
		}
	});
}

// Support: IE<9
// Use defaultValue in place of getAttribute("value")
if ( !support.attributes || !assert(function( div ) {
	div.innerHTML = "<input/>";
	div.firstChild.setAttribute( "value", "" );
	return div.firstChild.getAttribute( "value" ) === "";
}) ) {
	addHandle( "value", function( elem, name, isXML ) {
		if ( !isXML && elem.nodeName.toLowerCase() === "input" ) {
			return elem.defaultValue;
		}
	});
}

// Support: IE<9
// Use getAttributeNode to fetch booleans when getAttribute lies
if ( !assert(function( div ) {
	return div.getAttribute("disabled") == null;
}) ) {
	addHandle( booleans, function( elem, name, isXML ) {
		var val;
		if ( !isXML ) {
			return (val = elem.getAttributeNode( name )) && val.specified ?
				val.value :
				elem[ name ] === true ? name.toLowerCase() : null;
		}
	});
}

jQuery.find = Sizzle;
jQuery.expr = Sizzle.selectors;
jQuery.expr[":"] = jQuery.expr.pseudos;
jQuery.unique = Sizzle.uniqueSort;
jQuery.text = Sizzle.getText;
jQuery.isXMLDoc = Sizzle.isXML;
jQuery.contains = Sizzle.contains;


})( window );
// String to Object options format cache
var optionsCache = {};

// Convert String-formatted options into Object-formatted ones and store in cache
function createOptions( options ) {
	var object = optionsCache[ options ] = {};
	jQuery.each( options.match( core_rnotwhite ) || [], function( _, flag ) {
		object[ flag ] = true;
	});
	return object;
}

/*
 * Create a callback list using the following parameters:
 *
 *	options: an optional list of space-separated options that will change how
 *			the callback list behaves or a more traditional option object
 *
 * By default a callback list will act like an event callback list and can be
 * "fired" multiple times.
 *
 * Possible options:
 *
 *	once:			will ensure the callback list can only be fired once (like a Deferred)
 *
 *	memory:			will keep track of previous values and will call any callback added
 *					after the list has been fired right away with the latest "memorized"
 *					values (like a Deferred)
 *
 *	unique:			will ensure a callback can only be added once (no duplicate in the list)
 *
 *	stopOnFalse:	interrupt callings when a callback returns false
 *
 */
jQuery.Callbacks = function( options ) {

	// Convert options from String-formatted to Object-formatted if needed
	// (we check in cache first)
	options = typeof options === "string" ?
		( optionsCache[ options ] || createOptions( options ) ) :
		jQuery.extend( {}, options );

	var // Flag to know if list is currently firing
		firing,
		// Last fire value (for non-forgettable lists)
		memory,
		// Flag to know if list was already fired
		fired,
		// End of the loop when firing
		firingLength,
		// Index of currently firing callback (modified by remove if needed)
		firingIndex,
		// First callback to fire (used internally by add and fireWith)
		firingStart,
		// Actual callback list
		list = [],
		// Stack of fire calls for repeatable lists
		stack = !options.once && [],
		// Fire callbacks
		fire = function( data ) {
			memory = options.memory && data;
			fired = true;
			firingIndex = firingStart || 0;
			firingStart = 0;
			firingLength = list.length;
			firing = true;
			for ( ; list && firingIndex < firingLength; firingIndex++ ) {
				if ( list[ firingIndex ].apply( data[ 0 ], data[ 1 ] ) === false && options.stopOnFalse ) {
					memory = false; // To prevent further calls using add
					break;
				}
			}
			firing = false;
			if ( list ) {
				if ( stack ) {
					if ( stack.length ) {
						fire( stack.shift() );
					}
				} else if ( memory ) {
					list = [];
				} else {
					self.disable();
				}
			}
		},
		// Actual Callbacks object
		self = {
			// Add a callback or a collection of callbacks to the list
			add: function() {
				if ( list ) {
					// First, we save the current length
					var start = list.length;
					(function add( args ) {
						jQuery.each( args, function( _, arg ) {
							var type = jQuery.type( arg );
							if ( type === "function" ) {
								if ( !options.unique || !self.has( arg ) ) {
									list.push( arg );
								}
							} else if ( arg && arg.length && type !== "string" ) {
								// Inspect recursively
								add( arg );
							}
						});
					})( arguments );
					// Do we need to add the callbacks to the
					// current firing batch?
					if ( firing ) {
						firingLength = list.length;
					// With memory, if we're not firing then
					// we should call right away
					} else if ( memory ) {
						firingStart = start;
						fire( memory );
					}
				}
				return this;
			},
			// Remove a callback from the list
			remove: function() {
				if ( list ) {
					jQuery.each( arguments, function( _, arg ) {
						var index;
						while( ( index = jQuery.inArray( arg, list, index ) ) > -1 ) {
							list.splice( index, 1 );
							// Handle firing indexes
							if ( firing ) {
								if ( index <= firingLength ) {
									firingLength--;
								}
								if ( index <= firingIndex ) {
									firingIndex--;
								}
							}
						}
					});
				}
				return this;
			},
			// Check if a given callback is in the list.
			// If no argument is given, return whether or not list has callbacks attached.
			has: function( fn ) {
				return fn ? jQuery.inArray( fn, list ) > -1 : !!( list && list.length );
			},
			// Remove all callbacks from the list
			empty: function() {
				list = [];
				firingLength = 0;
				return this;
			},
			// Have the list do nothing anymore
			disable: function() {
				list = stack = memory = undefined;
				return this;
			},
			// Is it disabled?
			disabled: function() {
				return !list;
			},
			// Lock the list in its current state
			lock: function() {
				stack = undefined;
				if ( !memory ) {
					self.disable();
				}
				return this;
			},
			// Is it locked?
			locked: function() {
				return !stack;
			},
			// Call all callbacks with the given context and arguments
			fireWith: function( context, args ) {
				if ( list && ( !fired || stack ) ) {
					args = args || [];
					args = [ context, args.slice ? args.slice() : args ];
					if ( firing ) {
						stack.push( args );
					} else {
						fire( args );
					}
				}
				return this;
			},
			// Call all the callbacks with the given arguments
			fire: function() {
				self.fireWith( this, arguments );
				return this;
			},
			// To know if the callbacks have already been called at least once
			fired: function() {
				return !!fired;
			}
		};

	return self;
};
jQuery.extend({

	Deferred: function( func ) {
		var tuples = [
				// action, add listener, listener list, final state
				[ "resolve", "done", jQuery.Callbacks("once memory"), "resolved" ],
				[ "reject", "fail", jQuery.Callbacks("once memory"), "rejected" ],
				[ "notify", "progress", jQuery.Callbacks("memory") ]
			],
			state = "pending",
			promise = {
				state: function() {
					return state;
				},
				always: function() {
					deferred.done( arguments ).fail( arguments );
					return this;
				},
				then: function( /* fnDone, fnFail, fnProgress */ ) {
					var fns = arguments;
					return jQuery.Deferred(function( newDefer ) {
						jQuery.each( tuples, function( i, tuple ) {
							var action = tuple[ 0 ],
								fn = jQuery.isFunction( fns[ i ] ) && fns[ i ];
							// deferred[ done | fail | progress ] for forwarding actions to newDefer
							deferred[ tuple[1] ](function() {
								var returned = fn && fn.apply( this, arguments );
								if ( returned && jQuery.isFunction( returned.promise ) ) {
									returned.promise()
										.done( newDefer.resolve )
										.fail( newDefer.reject )
										.progress( newDefer.notify );
								} else {
									newDefer[ action + "With" ]( this === promise ? newDefer.promise() : this, fn ? [ returned ] : arguments );
								}
							});
						});
						fns = null;
					}).promise();
				},
				// Get a promise for this deferred
				// If obj is provided, the promise aspect is added to the object
				promise: function( obj ) {
					return obj != null ? jQuery.extend( obj, promise ) : promise;
				}
			},
			deferred = {};

		// Keep pipe for back-compat
		promise.pipe = promise.then;

		// Add list-specific methods
		jQuery.each( tuples, function( i, tuple ) {
			var list = tuple[ 2 ],
				stateString = tuple[ 3 ];

			// promise[ done | fail | progress ] = list.add
			promise[ tuple[1] ] = list.add;

			// Handle state
			if ( stateString ) {
				list.add(function() {
					// state = [ resolved | rejected ]
					state = stateString;

				// [ reject_list | resolve_list ].disable; progress_list.lock
				}, tuples[ i ^ 1 ][ 2 ].disable, tuples[ 2 ][ 2 ].lock );
			}

			// deferred[ resolve | reject | notify ]
			deferred[ tuple[0] ] = function() {
				deferred[ tuple[0] + "With" ]( this === deferred ? promise : this, arguments );
				return this;
			};
			deferred[ tuple[0] + "With" ] = list.fireWith;
		});

		// Make the deferred a promise
		promise.promise( deferred );

		// Call given func if any
		if ( func ) {
			func.call( deferred, deferred );
		}

		// All done!
		return deferred;
	},

	// Deferred helper
	when: function( subordinate /* , ..., subordinateN */ ) {
		var i = 0,
			resolveValues = core_slice.call( arguments ),
			length = resolveValues.length,

			// the count of uncompleted subordinates
			remaining = length !== 1 || ( subordinate && jQuery.isFunction( subordinate.promise ) ) ? length : 0,

			// the master Deferred. If resolveValues consist of only a single Deferred, just use that.
			deferred = remaining === 1 ? subordinate : jQuery.Deferred(),

			// Update function for both resolve and progress values
			updateFunc = function( i, contexts, values ) {
				return function( value ) {
					contexts[ i ] = this;
					values[ i ] = arguments.length > 1 ? core_slice.call( arguments ) : value;
					if( values === progressValues ) {
						deferred.notifyWith( contexts, values );
					} else if ( !( --remaining ) ) {
						deferred.resolveWith( contexts, values );
					}
				};
			},

			progressValues, progressContexts, resolveContexts;

		// add listeners to Deferred subordinates; treat others as resolved
		if ( length > 1 ) {
			progressValues = new Array( length );
			progressContexts = new Array( length );
			resolveContexts = new Array( length );
			for ( ; i < length; i++ ) {
				if ( resolveValues[ i ] && jQuery.isFunction( resolveValues[ i ].promise ) ) {
					resolveValues[ i ].promise()
						.done( updateFunc( i, resolveContexts, resolveValues ) )
						.fail( deferred.reject )
						.progress( updateFunc( i, progressContexts, progressValues ) );
				} else {
					--remaining;
				}
			}
		}

		// if we're not waiting on anything, resolve the master
		if ( !remaining ) {
			deferred.resolveWith( resolveContexts, resolveValues );
		}

		return deferred.promise();
	}
});
jQuery.support = (function( support ) {

	var all, a, input, select, fragment, opt, eventName, isSupported, i,
		div = document.createElement("div");

	// Setup
	div.setAttribute( "className", "t" );
	div.innerHTML = "  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>";

	// Finish early in limited (non-browser) environments
	all = div.getElementsByTagName("*") || [];
	a = div.getElementsByTagName("a")[ 0 ];
	if ( !a || !a.style || !all.length ) {
		return support;
	}

	// First batch of tests
	select = document.createElement("select");
	opt = select.appendChild( document.createElement("option") );
	input = div.getElementsByTagName("input")[ 0 ];

	a.style.cssText = "top:1px;float:left;opacity:.5";

	// Test setAttribute on camelCase class. If it works, we need attrFixes when doing get/setAttribute (ie6/7)
	support.getSetAttribute = div.className !== "t";

	// IE strips leading whitespace when .innerHTML is used
	support.leadingWhitespace = div.firstChild.nodeType === 3;

	// Make sure that tbody elements aren't automatically inserted
	// IE will insert them into empty tables
	support.tbody = !div.getElementsByTagName("tbody").length;

	// Make sure that link elements get serialized correctly by innerHTML
	// This requires a wrapper element in IE
	support.htmlSerialize = !!div.getElementsByTagName("link").length;

	// Get the style information from getAttribute
	// (IE uses .cssText instead)
	support.style = /top/.test( a.getAttribute("style") );

	// Make sure that URLs aren't manipulated
	// (IE normalizes it by default)
	support.hrefNormalized = a.getAttribute("href") === "/a";

	// Make sure that element opacity exists
	// (IE uses filter instead)
	// Use a regex to work around a WebKit issue. See #5145
	support.opacity = /^0.5/.test( a.style.opacity );

	// Verify style float existence
	// (IE uses styleFloat instead of cssFloat)
	support.cssFloat = !!a.style.cssFloat;

	// Check the default checkbox/radio value ("" on WebKit; "on" elsewhere)
	support.checkOn = !!input.value;

	// Make sure that a selected-by-default option has a working selected property.
	// (WebKit defaults to false instead of true, IE too, if it's in an optgroup)
	support.optSelected = opt.selected;

	// Tests for enctype support on a form (#6743)
	support.enctype = !!document.createElement("form").enctype;

	// Makes sure cloning an html5 element does not cause problems
	// Where outerHTML is undefined, this still works
	support.html5Clone = document.createElement("nav").cloneNode( true ).outerHTML !== "<:nav></:nav>";

	// Will be defined later
	support.inlineBlockNeedsLayout = false;
	support.shrinkWrapBlocks = false;
	support.pixelPosition = false;
	support.deleteExpando = true;
	support.noCloneEvent = true;
	support.reliableMarginRight = true;
	support.boxSizingReliable = true;

	// Make sure checked status is properly cloned
	input.checked = true;
	support.noCloneChecked = input.cloneNode( true ).checked;

	// Make sure that the options inside disabled selects aren't marked as disabled
	// (WebKit marks them as disabled)
	select.disabled = true;
	support.optDisabled = !opt.disabled;

	// Support: IE<9
	try {
		delete div.test;
	} catch( e ) {
		support.deleteExpando = false;
	}

	// Check if we can trust getAttribute("value")
	input = document.createElement("input");
	input.setAttribute( "value", "" );
	support.input = input.getAttribute( "value" ) === "";

	// Check if an input maintains its value after becoming a radio
	input.value = "t";
	input.setAttribute( "type", "radio" );
	support.radioValue = input.value === "t";

	// #11217 - WebKit loses check when the name is after the checked attribute
	input.setAttribute( "checked", "t" );
	input.setAttribute( "name", "t" );

	fragment = document.createDocumentFragment();
	fragment.appendChild( input );

	// Check if a disconnected checkbox will retain its checked
	// value of true after appended to the DOM (IE6/7)
	support.appendChecked = input.checked;

	// WebKit doesn't clone checked state correctly in fragments
	support.checkClone = fragment.cloneNode( true ).cloneNode( true ).lastChild.checked;

	// Support: IE<9
	// Opera does not clone events (and typeof div.attachEvent === undefined).
	// IE9-10 clones events bound via attachEvent, but they don't trigger with .click()
	if ( div.attachEvent ) {
		div.attachEvent( "onclick", function() {
			support.noCloneEvent = false;
		});

		div.cloneNode( true ).click();
	}

	// Support: IE<9 (lack submit/change bubble), Firefox 17+ (lack focusin event)
	// Beware of CSP restrictions (https://developer.mozilla.org/en/Security/CSP)
	for ( i in { submit: true, change: true, focusin: true }) {
		div.setAttribute( eventName = "on" + i, "t" );

		support[ i + "Bubbles" ] = eventName in window || div.attributes[ eventName ].expando === false;
	}

	div.style.backgroundClip = "content-box";
	div.cloneNode( true ).style.backgroundClip = "";
	support.clearCloneStyle = div.style.backgroundClip === "content-box";

	// Support: IE<9
	// Iteration over object's inherited properties before its own.
	for ( i in jQuery( support ) ) {
		break;
	}
	support.ownLast = i !== "0";

	// Run tests that need a body at doc ready
	jQuery(function() {
		var container, marginDiv, tds,
			divReset = "padding:0;margin:0;border:0;display:block;box-sizing:content-box;-moz-box-sizing:content-box;-webkit-box-sizing:content-box;",
			body = document.getElementsByTagName("body")[0];

		if ( !body ) {
			// Return for frameset docs that don't have a body
			return;
		}

		container = document.createElement("div");
		container.style.cssText = "border:0;width:0;height:0;position:absolute;top:0;left:-9999px;margin-top:1px";

		body.appendChild( container ).appendChild( div );

		// Support: IE8
		// Check if table cells still have offsetWidth/Height when they are set
		// to display:none and there are still other visible table cells in a
		// table row; if so, offsetWidth/Height are not reliable for use when
		// determining if an element has been hidden directly using
		// display:none (it is still safe to use offsets if a parent element is
		// hidden; don safety goggles and see bug #4512 for more information).
		div.innerHTML = "<table><tr><td></td><td>t</td></tr></table>";
		tds = div.getElementsByTagName("td");
		tds[ 0 ].style.cssText = "padding:0;margin:0;border:0;display:none";
		isSupported = ( tds[ 0 ].offsetHeight === 0 );

		tds[ 0 ].style.display = "";
		tds[ 1 ].style.display = "none";

		// Support: IE8
		// Check if empty table cells still have offsetWidth/Height
		support.reliableHiddenOffsets = isSupported && ( tds[ 0 ].offsetHeight === 0 );

		// Check box-sizing and margin behavior.
		div.innerHTML = "";
		div.style.cssText = "box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;padding:1px;border:1px;display:block;width:4px;margin-top:1%;position:absolute;top:1%;";

		// Workaround failing boxSizing test due to offsetWidth returning wrong value
		// with some non-1 values of body zoom, ticket #13543
		jQuery.swap( body, body.style.zoom != null ? { zoom: 1 } : {}, function() {
			support.boxSizing = div.offsetWidth === 4;
		});

		// Use window.getComputedStyle because jsdom on node.js will break without it.
		if ( window.getComputedStyle ) {
			support.pixelPosition = ( window.getComputedStyle( div, null ) || {} ).top !== "1%";
			support.boxSizingReliable = ( window.getComputedStyle( div, null ) || { width: "4px" } ).width === "4px";

			// Check if div with explicit width and no margin-right incorrectly
			// gets computed margin-right based on width of container. (#3333)
			// Fails in WebKit before Feb 2011 nightlies
			// WebKit Bug 13343 - getComputedStyle returns wrong value for margin-right
			marginDiv = div.appendChild( document.createElement("div") );
			marginDiv.style.cssText = div.style.cssText = divReset;
			marginDiv.style.marginRight = marginDiv.style.width = "0";
			div.style.width = "1px";

			support.reliableMarginRight =
				!parseFloat( ( window.getComputedStyle( marginDiv, null ) || {} ).marginRight );
		}

		if ( typeof div.style.zoom !== core_strundefined ) {
			// Support: IE<8
			// Check if natively block-level elements act like inline-block
			// elements when setting their display to 'inline' and giving
			// them layout
			div.innerHTML = "";
			div.style.cssText = divReset + "width:1px;padding:1px;display:inline;zoom:1";
			support.inlineBlockNeedsLayout = ( div.offsetWidth === 3 );

			// Support: IE6
			// Check if elements with layout shrink-wrap their children
			div.style.display = "block";
			div.innerHTML = "<div></div>";
			div.firstChild.style.width = "5px";
			support.shrinkWrapBlocks = ( div.offsetWidth !== 3 );

			if ( support.inlineBlockNeedsLayout ) {
				// Prevent IE 6 from affecting layout for positioned elements #11048
				// Prevent IE from shrinking the body in IE 7 mode #12869
				// Support: IE<8
				body.style.zoom = 1;
			}
		}

		body.removeChild( container );

		// Null elements to avoid leaks in IE
		container = div = tds = marginDiv = null;
	});

	// Null elements to avoid leaks in IE
	all = select = fragment = opt = a = input = null;

	return support;
})({});

var rbrace = /(?:\{[\s\S]*\}|\[[\s\S]*\])$/,
	rmultiDash = /([A-Z])/g;

function internalData( elem, name, data, pvt /* Internal Use Only */ ){
	if ( !jQuery.acceptData( elem ) ) {
		return;
	}

	var ret, thisCache,
		internalKey = jQuery.expando,

		// We have to handle DOM nodes and JS objects differently because IE6-7
		// can't GC object references properly across the DOM-JS boundary
		isNode = elem.nodeType,

		// Only DOM nodes need the global jQuery cache; JS object data is
		// attached directly to the object so GC can occur automatically
		cache = isNode ? jQuery.cache : elem,

		// Only defining an ID for JS objects if its cache already exists allows
		// the code to shortcut on the same path as a DOM node with no cache
		id = isNode ? elem[ internalKey ] : elem[ internalKey ] && internalKey;

	// Avoid doing any more work than we need to when trying to get data on an
	// object that has no data at all
	if ( (!id || !cache[id] || (!pvt && !cache[id].data)) && data === undefined && typeof name === "string" ) {
		return;
	}

	if ( !id ) {
		// Only DOM nodes need a new unique ID for each element since their data
		// ends up in the global cache
		if ( isNode ) {
			id = elem[ internalKey ] = core_deletedIds.pop() || jQuery.guid++;
		} else {
			id = internalKey;
		}
	}

	if ( !cache[ id ] ) {
		// Avoid exposing jQuery metadata on plain JS objects when the object
		// is serialized using JSON.stringify
		cache[ id ] = isNode ? {} : { toJSON: jQuery.noop };
	}

	// An object can be passed to jQuery.data instead of a key/value pair; this gets
	// shallow copied over onto the existing cache
	if ( typeof name === "object" || typeof name === "function" ) {
		if ( pvt ) {
			cache[ id ] = jQuery.extend( cache[ id ], name );
		} else {
			cache[ id ].data = jQuery.extend( cache[ id ].data, name );
		}
	}

	thisCache = cache[ id ];

	// jQuery data() is stored in a separate object inside the object's internal data
	// cache in order to avoid key collisions between internal data and user-defined
	// data.
	if ( !pvt ) {
		if ( !thisCache.data ) {
			thisCache.data = {};
		}

		thisCache = thisCache.data;
	}

	if ( data !== undefined ) {
		thisCache[ jQuery.camelCase( name ) ] = data;
	}

	// Check for both converted-to-camel and non-converted data property names
	// If a data property was specified
	if ( typeof name === "string" ) {

		// First Try to find as-is property data
		ret = thisCache[ name ];

		// Test for null|undefined property data
		if ( ret == null ) {

			// Try to find the camelCased property
			ret = thisCache[ jQuery.camelCase( name ) ];
		}
	} else {
		ret = thisCache;
	}

	return ret;
}

function internalRemoveData( elem, name, pvt ) {
	if ( !jQuery.acceptData( elem ) ) {
		return;
	}

	var thisCache, i,
		isNode = elem.nodeType,

		// See jQuery.data for more information
		cache = isNode ? jQuery.cache : elem,
		id = isNode ? elem[ jQuery.expando ] : jQuery.expando;

	// If there is already no cache entry for this object, there is no
	// purpose in continuing
	if ( !cache[ id ] ) {
		return;
	}

	if ( name ) {

		thisCache = pvt ? cache[ id ] : cache[ id ].data;

		if ( thisCache ) {

			// Support array or space separated string names for data keys
			if ( !jQuery.isArray( name ) ) {

				// try the string as a key before any manipulation
				if ( name in thisCache ) {
					name = [ name ];
				} else {

					// split the camel cased version by spaces unless a key with the spaces exists
					name = jQuery.camelCase( name );
					if ( name in thisCache ) {
						name = [ name ];
					} else {
						name = name.split(" ");
					}
				}
			} else {
				// If "name" is an array of keys...
				// When data is initially created, via ("key", "val") signature,
				// keys will be converted to camelCase.
				// Since there is no way to tell _how_ a key was added, remove
				// both plain key and camelCase key. #12786
				// This will only penalize the array argument path.
				name = name.concat( jQuery.map( name, jQuery.camelCase ) );
			}

			i = name.length;
			while ( i-- ) {
				delete thisCache[ name[i] ];
			}

			// If there is no data left in the cache, we want to continue
			// and let the cache object itself get destroyed
			if ( pvt ? !isEmptyDataObject(thisCache) : !jQuery.isEmptyObject(thisCache) ) {
				return;
			}
		}
	}

	// See jQuery.data for more information
	if ( !pvt ) {
		delete cache[ id ].data;

		// Don't destroy the parent cache unless the internal data object
		// had been the only thing left in it
		if ( !isEmptyDataObject( cache[ id ] ) ) {
			return;
		}
	}

	// Destroy the cache
	if ( isNode ) {
		jQuery.cleanData( [ elem ], true );

	// Use delete when supported for expandos or `cache` is not a window per isWindow (#10080)
	/* jshint eqeqeq: false */
	} else if ( jQuery.support.deleteExpando || cache != cache.window ) {
		/* jshint eqeqeq: true */
		delete cache[ id ];

	// When all else fails, null
	} else {
		cache[ id ] = null;
	}
}

jQuery.extend({
	cache: {},

	// The following elements throw uncatchable exceptions if you
	// attempt to add expando properties to them.
	noData: {
		"applet": true,
		"embed": true,
		// Ban all objects except for Flash (which handle expandos)
		"object": "clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"
	},

	hasData: function( elem ) {
		elem = elem.nodeType ? jQuery.cache[ elem[jQuery.expando] ] : elem[ jQuery.expando ];
		return !!elem && !isEmptyDataObject( elem );
	},

	data: function( elem, name, data ) {
		return internalData( elem, name, data );
	},

	removeData: function( elem, name ) {
		return internalRemoveData( elem, name );
	},

	// For internal use only.
	_data: function( elem, name, data ) {
		return internalData( elem, name, data, true );
	},

	_removeData: function( elem, name ) {
		return internalRemoveData( elem, name, true );
	},

	// A method for determining if a DOM node can handle the data expando
	acceptData: function( elem ) {
		// Do not set data on non-element because it will not be cleared (#8335).
		if ( elem.nodeType && elem.nodeType !== 1 && elem.nodeType !== 9 ) {
			return false;
		}

		var noData = elem.nodeName && jQuery.noData[ elem.nodeName.toLowerCase() ];

		// nodes accept data unless otherwise specified; rejection can be conditional
		return !noData || noData !== true && elem.getAttribute("classid") === noData;
	}
});

jQuery.fn.extend({
	data: function( key, value ) {
		var attrs, name,
			data = null,
			i = 0,
			elem = this[0];

		// Special expections of .data basically thwart jQuery.access,
		// so implement the relevant behavior ourselves

		// Gets all values
		if ( key === undefined ) {
			if ( this.length ) {
				data = jQuery.data( elem );

				if ( elem.nodeType === 1 && !jQuery._data( elem, "parsedAttrs" ) ) {
					attrs = elem.attributes;
					for ( ; i < attrs.length; i++ ) {
						name = attrs[i].name;

						if ( name.indexOf("data-") === 0 ) {
							name = jQuery.camelCase( name.slice(5) );

							dataAttr( elem, name, data[ name ] );
						}
					}
					jQuery._data( elem, "parsedAttrs", true );
				}
			}

			return data;
		}

		// Sets multiple values
		if ( typeof key === "object" ) {
			return this.each(function() {
				jQuery.data( this, key );
			});
		}

		return arguments.length > 1 ?

			// Sets one value
			this.each(function() {
				jQuery.data( this, key, value );
			}) :

			// Gets one value
			// Try to fetch any internally stored data first
			elem ? dataAttr( elem, key, jQuery.data( elem, key ) ) : null;
	},

	removeData: function( key ) {
		return this.each(function() {
			jQuery.removeData( this, key );
		});
	}
});

function dataAttr( elem, key, data ) {
	// If nothing was found internally, try to fetch any
	// data from the HTML5 data-* attribute
	if ( data === undefined && elem.nodeType === 1 ) {

		var name = "data-" + key.replace( rmultiDash, "-$1" ).toLowerCase();

		data = elem.getAttribute( name );

		if ( typeof data === "string" ) {
			try {
				data = data === "true" ? true :
					data === "false" ? false :
					data === "null" ? null :
					// Only convert to a number if it doesn't change the string
					+data + "" === data ? +data :
					rbrace.test( data ) ? jQuery.parseJSON( data ) :
						data;
			} catch( e ) {}

			// Make sure we set the data so it isn't changed later
			jQuery.data( elem, key, data );

		} else {
			data = undefined;
		}
	}

	return data;
}

// checks a cache object for emptiness
function isEmptyDataObject( obj ) {
	var name;
	for ( name in obj ) {

		// if the public data object is empty, the private is still empty
		if ( name === "data" && jQuery.isEmptyObject( obj[name] ) ) {
			continue;
		}
		if ( name !== "toJSON" ) {
			return false;
		}
	}

	return true;
}
jQuery.extend({
	queue: function( elem, type, data ) {
		var queue;

		if ( elem ) {
			type = ( type || "fx" ) + "queue";
			queue = jQuery._data( elem, type );

			// Speed up dequeue by getting out quickly if this is just a lookup
			if ( data ) {
				if ( !queue || jQuery.isArray(data) ) {
					queue = jQuery._data( elem, type, jQuery.makeArray(data) );
				} else {
					queue.push( data );
				}
			}
			return queue || [];
		}
	},

	dequeue: function( elem, type ) {
		type = type || "fx";

		var queue = jQuery.queue( elem, type ),
			startLength = queue.length,
			fn = queue.shift(),
			hooks = jQuery._queueHooks( elem, type ),
			next = function() {
				jQuery.dequeue( elem, type );
			};

		// If the fx queue is dequeued, always remove the progress sentinel
		if ( fn === "inprogress" ) {
			fn = queue.shift();
			startLength--;
		}

		if ( fn ) {

			// Add a progress sentinel to prevent the fx queue from being
			// automatically dequeued
			if ( type === "fx" ) {
				queue.unshift( "inprogress" );
			}

			// clear up the last queue stop function
			delete hooks.stop;
			fn.call( elem, next, hooks );
		}

		if ( !startLength && hooks ) {
			hooks.empty.fire();
		}
	},

	// not intended for public consumption - generates a queueHooks object, or returns the current one
	_queueHooks: function( elem, type ) {
		var key = type + "queueHooks";
		return jQuery._data( elem, key ) || jQuery._data( elem, key, {
			empty: jQuery.Callbacks("once memory").add(function() {
				jQuery._removeData( elem, type + "queue" );
				jQuery._removeData( elem, key );
			})
		});
	}
});

jQuery.fn.extend({
	queue: function( type, data ) {
		var setter = 2;

		if ( typeof type !== "string" ) {
			data = type;
			type = "fx";
			setter--;
		}

		if ( arguments.length < setter ) {
			return jQuery.queue( this[0], type );
		}

		return data === undefined ?
			this :
			this.each(function() {
				var queue = jQuery.queue( this, type, data );

				// ensure a hooks for this queue
				jQuery._queueHooks( this, type );

				if ( type === "fx" && queue[0] !== "inprogress" ) {
					jQuery.dequeue( this, type );
				}
			});
	},
	dequeue: function( type ) {
		return this.each(function() {
			jQuery.dequeue( this, type );
		});
	},
	// Based off of the plugin by Clint Helfers, with permission.
	// http://blindsignals.com/index.php/2009/07/jquery-delay/
	delay: function( time, type ) {
		time = jQuery.fx ? jQuery.fx.speeds[ time ] || time : time;
		type = type || "fx";

		return this.queue( type, function( next, hooks ) {
			var timeout = setTimeout( next, time );
			hooks.stop = function() {
				clearTimeout( timeout );
			};
		});
	},
	clearQueue: function( type ) {
		return this.queue( type || "fx", [] );
	},
	// Get a promise resolved when queues of a certain type
	// are emptied (fx is the type by default)
	promise: function( type, obj ) {
		var tmp,
			count = 1,
			defer = jQuery.Deferred(),
			elements = this,
			i = this.length,
			resolve = function() {
				if ( !( --count ) ) {
					defer.resolveWith( elements, [ elements ] );
				}
			};

		if ( typeof type !== "string" ) {
			obj = type;
			type = undefined;
		}
		type = type || "fx";

		while( i-- ) {
			tmp = jQuery._data( elements[ i ], type + "queueHooks" );
			if ( tmp && tmp.empty ) {
				count++;
				tmp.empty.add( resolve );
			}
		}
		resolve();
		return defer.promise( obj );
	}
});
var nodeHook, boolHook,
	rclass = /[\t\r\n\f]/g,
	rreturn = /\r/g,
	rfocusable = /^(?:input|select|textarea|button|object)$/i,
	rclickable = /^(?:a|area)$/i,
	ruseDefault = /^(?:checked|selected)$/i,
	getSetAttribute = jQuery.support.getSetAttribute,
	getSetInput = jQuery.support.input;

jQuery.fn.extend({
	attr: function( name, value ) {
		return jQuery.access( this, jQuery.attr, name, value, arguments.length > 1 );
	},

	removeAttr: function( name ) {
		return this.each(function() {
			jQuery.removeAttr( this, name );
		});
	},

	prop: function( name, value ) {
		return jQuery.access( this, jQuery.prop, name, value, arguments.length > 1 );
	},

	removeProp: function( name ) {
		name = jQuery.propFix[ name ] || name;
		return this.each(function() {
			// try/catch handles cases where IE balks (such as removing a property on window)
			try {
				this[ name ] = undefined;
				delete this[ name ];
			} catch( e ) {}
		});
	},

	addClass: function( value ) {
		var classes, elem, cur, clazz, j,
			i = 0,
			len = this.length,
			proceed = typeof value === "string" && value;

		if ( jQuery.isFunction( value ) ) {
			return this.each(function( j ) {
				jQuery( this ).addClass( value.call( this, j, this.className ) );
			});
		}

		if ( proceed ) {
			// The disjunction here is for better compressibility (see removeClass)
			classes = ( value || "" ).match( core_rnotwhite ) || [];

			for ( ; i < len; i++ ) {
				elem = this[ i ];
				cur = elem.nodeType === 1 && ( elem.className ?
					( " " + elem.className + " " ).replace( rclass, " " ) :
					" "
				);

				if ( cur ) {
					j = 0;
					while ( (clazz = classes[j++]) ) {
						if ( cur.indexOf( " " + clazz + " " ) < 0 ) {
							cur += clazz + " ";
						}
					}
					elem.className = jQuery.trim( cur );

				}
			}
		}

		return this;
	},

	removeClass: function( value ) {
		var classes, elem, cur, clazz, j,
			i = 0,
			len = this.length,
			proceed = arguments.length === 0 || typeof value === "string" && value;

		if ( jQuery.isFunction( value ) ) {
			return this.each(function( j ) {
				jQuery( this ).removeClass( value.call( this, j, this.className ) );
			});
		}
		if ( proceed ) {
			classes = ( value || "" ).match( core_rnotwhite ) || [];

			for ( ; i < len; i++ ) {
				elem = this[ i ];
				// This expression is here for better compressibility (see addClass)
				cur = elem.nodeType === 1 && ( elem.className ?
					( " " + elem.className + " " ).replace( rclass, " " ) :
					""
				);

				if ( cur ) {
					j = 0;
					while ( (clazz = classes[j++]) ) {
						// Remove *all* instances
						while ( cur.indexOf( " " + clazz + " " ) >= 0 ) {
							cur = cur.replace( " " + clazz + " ", " " );
						}
					}
					elem.className = value ? jQuery.trim( cur ) : "";
				}
			}
		}

		return this;
	},

	toggleClass: function( value, stateVal ) {
		var type = typeof value;

		if ( typeof stateVal === "boolean" && type === "string" ) {
			return stateVal ? this.addClass( value ) : this.removeClass( value );
		}

		if ( jQuery.isFunction( value ) ) {
			return this.each(function( i ) {
				jQuery( this ).toggleClass( value.call(this, i, this.className, stateVal), stateVal );
			});
		}

		return this.each(function() {
			if ( type === "string" ) {
				// toggle individual class names
				var className,
					i = 0,
					self = jQuery( this ),
					classNames = value.match( core_rnotwhite ) || [];

				while ( (className = classNames[ i++ ]) ) {
					// check each className given, space separated list
					if ( self.hasClass( className ) ) {
						self.removeClass( className );
					} else {
						self.addClass( className );
					}
				}

			// Toggle whole class name
			} else if ( type === core_strundefined || type === "boolean" ) {
				if ( this.className ) {
					// store className if set
					jQuery._data( this, "__className__", this.className );
				}

				// If the element has a class name or if we're passed "false",
				// then remove the whole classname (if there was one, the above saved it).
				// Otherwise bring back whatever was previously saved (if anything),
				// falling back to the empty string if nothing was stored.
				this.className = this.className || value === false ? "" : jQuery._data( this, "__className__" ) || "";
			}
		});
	},

	hasClass: function( selector ) {
		var className = " " + selector + " ",
			i = 0,
			l = this.length;
		for ( ; i < l; i++ ) {
			if ( this[i].nodeType === 1 && (" " + this[i].className + " ").replace(rclass, " ").indexOf( className ) >= 0 ) {
				return true;
			}
		}

		return false;
	},

	val: function( value ) {
		var ret, hooks, isFunction,
			elem = this[0];

		if ( !arguments.length ) {
			if ( elem ) {
				hooks = jQuery.valHooks[ elem.type ] || jQuery.valHooks[ elem.nodeName.toLowerCase() ];

				if ( hooks && "get" in hooks && (ret = hooks.get( elem, "value" )) !== undefined ) {
					return ret;
				}

				ret = elem.value;

				return typeof ret === "string" ?
					// handle most common string cases
					ret.replace(rreturn, "") :
					// handle cases where value is null/undef or number
					ret == null ? "" : ret;
			}

			return;
		}

		isFunction = jQuery.isFunction( value );

		return this.each(function( i ) {
			var val;

			if ( this.nodeType !== 1 ) {
				return;
			}

			if ( isFunction ) {
				val = value.call( this, i, jQuery( this ).val() );
			} else {
				val = value;
			}

			// Treat null/undefined as ""; convert numbers to string
			if ( val == null ) {
				val = "";
			} else if ( typeof val === "number" ) {
				val += "";
			} else if ( jQuery.isArray( val ) ) {
				val = jQuery.map(val, function ( value ) {
					return value == null ? "" : value + "";
				});
			}

			hooks = jQuery.valHooks[ this.type ] || jQuery.valHooks[ this.nodeName.toLowerCase() ];

			// If set returns undefined, fall back to normal setting
			if ( !hooks || !("set" in hooks) || hooks.set( this, val, "value" ) === undefined ) {
				this.value = val;
			}
		});
	}
});

jQuery.extend({
	valHooks: {
		option: {
			get: function( elem ) {
				// Use proper attribute retrieval(#6932, #12072)
				var val = jQuery.find.attr( elem, "value" );
				return val != null ?
					val :
					elem.text;
			}
		},
		select: {
			get: function( elem ) {
				var value, option,
					options = elem.options,
					index = elem.selectedIndex,
					one = elem.type === "select-one" || index < 0,
					values = one ? null : [],
					max = one ? index + 1 : options.length,
					i = index < 0 ?
						max :
						one ? index : 0;

				// Loop through all the selected options
				for ( ; i < max; i++ ) {
					option = options[ i ];

					// oldIE doesn't update selected after form reset (#2551)
					if ( ( option.selected || i === index ) &&
							// Don't return options that are disabled or in a disabled optgroup
							( jQuery.support.optDisabled ? !option.disabled : option.getAttribute("disabled") === null ) &&
							( !option.parentNode.disabled || !jQuery.nodeName( option.parentNode, "optgroup" ) ) ) {

						// Get the specific value for the option
						value = jQuery( option ).val();

						// We don't need an array for one selects
						if ( one ) {
							return value;
						}

						// Multi-Selects return an array
						values.push( value );
					}
				}

				return values;
			},

			set: function( elem, value ) {
				var optionSet, option,
					options = elem.options,
					values = jQuery.makeArray( value ),
					i = options.length;

				while ( i-- ) {
					option = options[ i ];
					if ( (option.selected = jQuery.inArray( jQuery(option).val(), values ) >= 0) ) {
						optionSet = true;
					}
				}

				// force browsers to behave consistently when non-matching value is set
				if ( !optionSet ) {
					elem.selectedIndex = -1;
				}
				return values;
			}
		}
	},

	attr: function( elem, name, value ) {
		var hooks, ret,
			nType = elem.nodeType;

		// don't get/set attributes on text, comment and attribute nodes
		if ( !elem || nType === 3 || nType === 8 || nType === 2 ) {
			return;
		}

		// Fallback to prop when attributes are not supported
		if ( typeof elem.getAttribute === core_strundefined ) {
			return jQuery.prop( elem, name, value );
		}

		// All attributes are lowercase
		// Grab necessary hook if one is defined
		if ( nType !== 1 || !jQuery.isXMLDoc( elem ) ) {
			name = name.toLowerCase();
			hooks = jQuery.attrHooks[ name ] ||
				( jQuery.expr.match.bool.test( name ) ? boolHook : nodeHook );
		}

		if ( value !== undefined ) {

			if ( value === null ) {
				jQuery.removeAttr( elem, name );

			} else if ( hooks && "set" in hooks && (ret = hooks.set( elem, value, name )) !== undefined ) {
				return ret;

			} else {
				elem.setAttribute( name, value + "" );
				return value;
			}

		} else if ( hooks && "get" in hooks && (ret = hooks.get( elem, name )) !== null ) {
			return ret;

		} else {
			ret = jQuery.find.attr( elem, name );

			// Non-existent attributes return null, we normalize to undefined
			return ret == null ?
				undefined :
				ret;
		}
	},

	removeAttr: function( elem, value ) {
		var name, propName,
			i = 0,
			attrNames = value && value.match( core_rnotwhite );

		if ( attrNames && elem.nodeType === 1 ) {
			while ( (name = attrNames[i++]) ) {
				propName = jQuery.propFix[ name ] || name;

				// Boolean attributes get special treatment (#10870)
				if ( jQuery.expr.match.bool.test( name ) ) {
					// Set corresponding property to false
					if ( getSetInput && getSetAttribute || !ruseDefault.test( name ) ) {
						elem[ propName ] = false;
					// Support: IE<9
					// Also clear defaultChecked/defaultSelected (if appropriate)
					} else {
						elem[ jQuery.camelCase( "default-" + name ) ] =
							elem[ propName ] = false;
					}

				// See #9699 for explanation of this approach (setting first, then removal)
				} else {
					jQuery.attr( elem, name, "" );
				}

				elem.removeAttribute( getSetAttribute ? name : propName );
			}
		}
	},

	attrHooks: {
		type: {
			set: function( elem, value ) {
				if ( !jQuery.support.radioValue && value === "radio" && jQuery.nodeName(elem, "input") ) {
					// Setting the type on a radio button after the value resets the value in IE6-9
					// Reset value to default in case type is set after value during creation
					var val = elem.value;
					elem.setAttribute( "type", value );
					if ( val ) {
						elem.value = val;
					}
					return value;
				}
			}
		}
	},

	propFix: {
		"for": "htmlFor",
		"class": "className"
	},

	prop: function( elem, name, value ) {
		var ret, hooks, notxml,
			nType = elem.nodeType;

		// don't get/set properties on text, comment and attribute nodes
		if ( !elem || nType === 3 || nType === 8 || nType === 2 ) {
			return;
		}

		notxml = nType !== 1 || !jQuery.isXMLDoc( elem );

		if ( notxml ) {
			// Fix name and attach hooks
			name = jQuery.propFix[ name ] || name;
			hooks = jQuery.propHooks[ name ];
		}

		if ( value !== undefined ) {
			return hooks && "set" in hooks && (ret = hooks.set( elem, value, name )) !== undefined ?
				ret :
				( elem[ name ] = value );

		} else {
			return hooks && "get" in hooks && (ret = hooks.get( elem, name )) !== null ?
				ret :
				elem[ name ];
		}
	},

	propHooks: {
		tabIndex: {
			get: function( elem ) {
				// elem.tabIndex doesn't always return the correct value when it hasn't been explicitly set
				// http://fluidproject.org/blog/2008/01/09/getting-setting-and-removing-tabindex-values-with-javascript/
				// Use proper attribute retrieval(#12072)
				var tabindex = jQuery.find.attr( elem, "tabindex" );

				return tabindex ?
					parseInt( tabindex, 10 ) :
					rfocusable.test( elem.nodeName ) || rclickable.test( elem.nodeName ) && elem.href ?
						0 :
						-1;
			}
		}
	}
});

// Hooks for boolean attributes
boolHook = {
	set: function( elem, value, name ) {
		if ( value === false ) {
			// Remove boolean attributes when set to false
			jQuery.removeAttr( elem, name );
		} else if ( getSetInput && getSetAttribute || !ruseDefault.test( name ) ) {
			// IE<8 needs the *property* name
			elem.setAttribute( !getSetAttribute && jQuery.propFix[ name ] || name, name );

		// Use defaultChecked and defaultSelected for oldIE
		} else {
			elem[ jQuery.camelCase( "default-" + name ) ] = elem[ name ] = true;
		}

		return name;
	}
};
jQuery.each( jQuery.expr.match.bool.source.match( /\w+/g ), function( i, name ) {
	var getter = jQuery.expr.attrHandle[ name ] || jQuery.find.attr;

	jQuery.expr.attrHandle[ name ] = getSetInput && getSetAttribute || !ruseDefault.test( name ) ?
		function( elem, name, isXML ) {
			var fn = jQuery.expr.attrHandle[ name ],
				ret = isXML ?
					undefined :
					/* jshint eqeqeq: false */
					(jQuery.expr.attrHandle[ name ] = undefined) !=
						getter( elem, name, isXML ) ?

						name.toLowerCase() :
						null;
			jQuery.expr.attrHandle[ name ] = fn;
			return ret;
		} :
		function( elem, name, isXML ) {
			return isXML ?
				undefined :
				elem[ jQuery.camelCase( "default-" + name ) ] ?
					name.toLowerCase() :
					null;
		};
});

// fix oldIE attroperties
if ( !getSetInput || !getSetAttribute ) {
	jQuery.attrHooks.value = {
		set: function( elem, value, name ) {
			if ( jQuery.nodeName( elem, "input" ) ) {
				// Does not return so that setAttribute is also used
				elem.defaultValue = value;
			} else {
				// Use nodeHook if defined (#1954); otherwise setAttribute is fine
				return nodeHook && nodeHook.set( elem, value, name );
			}
		}
	};
}

// IE6/7 do not support getting/setting some attributes with get/setAttribute
if ( !getSetAttribute ) {

	// Use this for any attribute in IE6/7
	// This fixes almost every IE6/7 issue
	nodeHook = {
		set: function( elem, value, name ) {
			// Set the existing or create a new attribute node
			var ret = elem.getAttributeNode( name );
			if ( !ret ) {
				elem.setAttributeNode(
					(ret = elem.ownerDocument.createAttribute( name ))
				);
			}

			ret.value = value += "";

			// Break association with cloned elements by also using setAttribute (#9646)
			return name === "value" || value === elem.getAttribute( name ) ?
				value :
				undefined;
		}
	};
	jQuery.expr.attrHandle.id = jQuery.expr.attrHandle.name = jQuery.expr.attrHandle.coords =
		// Some attributes are constructed with empty-string values when not defined
		function( elem, name, isXML ) {
			var ret;
			return isXML ?
				undefined :
				(ret = elem.getAttributeNode( name )) && ret.value !== "" ?
					ret.value :
					null;
		};
	jQuery.valHooks.button = {
		get: function( elem, name ) {
			var ret = elem.getAttributeNode( name );
			return ret && ret.specified ?
				ret.value :
				undefined;
		},
		set: nodeHook.set
	};

	// Set contenteditable to false on removals(#10429)
	// Setting to empty string throws an error as an invalid value
	jQuery.attrHooks.contenteditable = {
		set: function( elem, value, name ) {
			nodeHook.set( elem, value === "" ? false : value, name );
		}
	};

	// Set width and height to auto instead of 0 on empty string( Bug #8150 )
	// This is for removals
	jQuery.each([ "width", "height" ], function( i, name ) {
		jQuery.attrHooks[ name ] = {
			set: function( elem, value ) {
				if ( value === "" ) {
					elem.setAttribute( name, "auto" );
					return value;
				}
			}
		};
	});
}


// Some attributes require a special call on IE
// http://msdn.microsoft.com/en-us/library/ms536429%28VS.85%29.aspx
if ( !jQuery.support.hrefNormalized ) {
	// href/src property should get the full normalized URL (#10299/#12915)
	jQuery.each([ "href", "src" ], function( i, name ) {
		jQuery.propHooks[ name ] = {
			get: function( elem ) {
				return elem.getAttribute( name, 4 );
			}
		};
	});
}

if ( !jQuery.support.style ) {
	jQuery.attrHooks.style = {
		get: function( elem ) {
			// Return undefined in the case of empty string
			// Note: IE uppercases css property names, but if we were to .toLowerCase()
			// .cssText, that would destroy case senstitivity in URL's, like in "background"
			return elem.style.cssText || undefined;
		},
		set: function( elem, value ) {
			return ( elem.style.cssText = value + "" );
		}
	};
}

// Safari mis-reports the default selected property of an option
// Accessing the parent's selectedIndex property fixes it
if ( !jQuery.support.optSelected ) {
	jQuery.propHooks.selected = {
		get: function( elem ) {
			var parent = elem.parentNode;

			if ( parent ) {
				parent.selectedIndex;

				// Make sure that it also works with optgroups, see #5701
				if ( parent.parentNode ) {
					parent.parentNode.selectedIndex;
				}
			}
			return null;
		}
	};
}

jQuery.each([
	"tabIndex",
	"readOnly",
	"maxLength",
	"cellSpacing",
	"cellPadding",
	"rowSpan",
	"colSpan",
	"useMap",
	"frameBorder",
	"contentEditable"
], function() {
	jQuery.propFix[ this.toLowerCase() ] = this;
});

// IE6/7 call enctype encoding
if ( !jQuery.support.enctype ) {
	jQuery.propFix.enctype = "encoding";
}

// Radios and checkboxes getter/setter
jQuery.each([ "radio", "checkbox" ], function() {
	jQuery.valHooks[ this ] = {
		set: function( elem, value ) {
			if ( jQuery.isArray( value ) ) {
				return ( elem.checked = jQuery.inArray( jQuery(elem).val(), value ) >= 0 );
			}
		}
	};
	if ( !jQuery.support.checkOn ) {
		jQuery.valHooks[ this ].get = function( elem ) {
			// Support: Webkit
			// "" is returned instead of "on" if a value isn't specified
			return elem.getAttribute("value") === null ? "on" : elem.value;
		};
	}
});
var rformElems = /^(?:input|select|textarea)$/i,
	rkeyEvent = /^key/,
	rmouseEvent = /^(?:mouse|contextmenu)|click/,
	rfocusMorph = /^(?:focusinfocus|focusoutblur)$/,
	rtypenamespace = /^([^.]*)(?:\.(.+)|)$/;

function returnTrue() {
	return true;
}

function returnFalse() {
	return false;
}

function safeActiveElement() {
	try {
		return document.activeElement;
	} catch ( err ) { }
}

/*
 * Helper functions for managing events -- not part of the public interface.
 * Props to Dean Edwards' addEvent library for many of the ideas.
 */
jQuery.event = {

	global: {},

	add: function( elem, types, handler, data, selector ) {
		var tmp, events, t, handleObjIn,
			special, eventHandle, handleObj,
			handlers, type, namespaces, origType,
			elemData = jQuery._data( elem );

		// Don't attach events to noData or text/comment nodes (but allow plain objects)
		if ( !elemData ) {
			return;
		}

		// Caller can pass in an object of custom data in lieu of the handler
		if ( handler.handler ) {
			handleObjIn = handler;
			handler = handleObjIn.handler;
			selector = handleObjIn.selector;
		}

		// Make sure that the handler has a unique ID, used to find/remove it later
		if ( !handler.guid ) {
			handler.guid = jQuery.guid++;
		}

		// Init the element's event structure and main handler, if this is the first
		if ( !(events = elemData.events) ) {
			events = elemData.events = {};
		}
		if ( !(eventHandle = elemData.handle) ) {
			eventHandle = elemData.handle = function( e ) {
				// Discard the second event of a jQuery.event.trigger() and
				// when an event is called after a page has unloaded
				return typeof jQuery !== core_strundefined && (!e || jQuery.event.triggered !== e.type) ?
					jQuery.event.dispatch.apply( eventHandle.elem, arguments ) :
					undefined;
			};
			// Add elem as a property of the handle fn to prevent a memory leak with IE non-native events
			eventHandle.elem = elem;
		}

		// Handle multiple events separated by a space
		types = ( types || "" ).match( core_rnotwhite ) || [""];
		t = types.length;
		while ( t-- ) {
			tmp = rtypenamespace.exec( types[t] ) || [];
			type = origType = tmp[1];
			namespaces = ( tmp[2] || "" ).split( "." ).sort();

			// There *must* be a type, no attaching namespace-only handlers
			if ( !type ) {
				continue;
			}

			// If event changes its type, use the special event handlers for the changed type
			special = jQuery.event.special[ type ] || {};

			// If selector defined, determine special event api type, otherwise given type
			type = ( selector ? special.delegateType : special.bindType ) || type;

			// Update special based on newly reset type
			special = jQuery.event.special[ type ] || {};

			// handleObj is passed to all event handlers
			handleObj = jQuery.extend({
				type: type,
				origType: origType,
				data: data,
				handler: handler,
				guid: handler.guid,
				selector: selector,
				needsContext: selector && jQuery.expr.match.needsContext.test( selector ),
				namespace: namespaces.join(".")
			}, handleObjIn );

			// Init the event handler queue if we're the first
			if ( !(handlers = events[ type ]) ) {
				handlers = events[ type ] = [];
				handlers.delegateCount = 0;

				// Only use addEventListener/attachEvent if the special events handler returns false
				if ( !special.setup || special.setup.call( elem, data, namespaces, eventHandle ) === false ) {
					// Bind the global event handler to the element
					if ( elem.addEventListener ) {
						elem.addEventListener( type, eventHandle, false );

					} else if ( elem.attachEvent ) {
						elem.attachEvent( "on" + type, eventHandle );
					}
				}
			}

			if ( special.add ) {
				special.add.call( elem, handleObj );

				if ( !handleObj.handler.guid ) {
					handleObj.handler.guid = handler.guid;
				}
			}

			// Add to the element's handler list, delegates in front
			if ( selector ) {
				handlers.splice( handlers.delegateCount++, 0, handleObj );
			} else {
				handlers.push( handleObj );
			}

			// Keep track of which events have ever been used, for event optimization
			jQuery.event.global[ type ] = true;
		}

		// Nullify elem to prevent memory leaks in IE
		elem = null;
	},

	// Detach an event or set of events from an element
	remove: function( elem, types, handler, selector, mappedTypes ) {
		var j, handleObj, tmp,
			origCount, t, events,
			special, handlers, type,
			namespaces, origType,
			elemData = jQuery.hasData( elem ) && jQuery._data( elem );

		if ( !elemData || !(events = elemData.events) ) {
			return;
		}

		// Once for each type.namespace in types; type may be omitted
		types = ( types || "" ).match( core_rnotwhite ) || [""];
		t = types.length;
		while ( t-- ) {
			tmp = rtypenamespace.exec( types[t] ) || [];
			type = origType = tmp[1];
			namespaces = ( tmp[2] || "" ).split( "." ).sort();

			// Unbind all events (on this namespace, if provided) for the element
			if ( !type ) {
				for ( type in events ) {
					jQuery.event.remove( elem, type + types[ t ], handler, selector, true );
				}
				continue;
			}

			special = jQuery.event.special[ type ] || {};
			type = ( selector ? special.delegateType : special.bindType ) || type;
			handlers = events[ type ] || [];
			tmp = tmp[2] && new RegExp( "(^|\\.)" + namespaces.join("\\.(?:.*\\.|)") + "(\\.|$)" );

			// Remove matching events
			origCount = j = handlers.length;
			while ( j-- ) {
				handleObj = handlers[ j ];

				if ( ( mappedTypes || origType === handleObj.origType ) &&
					( !handler || handler.guid === handleObj.guid ) &&
					( !tmp || tmp.test( handleObj.namespace ) ) &&
					( !selector || selector === handleObj.selector || selector === "**" && handleObj.selector ) ) {
					handlers.splice( j, 1 );

					if ( handleObj.selector ) {
						handlers.delegateCount--;
					}
					if ( special.remove ) {
						special.remove.call( elem, handleObj );
					}
				}
			}

			// Remove generic event handler if we removed something and no more handlers exist
			// (avoids potential for endless recursion during removal of special event handlers)
			if ( origCount && !handlers.length ) {
				if ( !special.teardown || special.teardown.call( elem, namespaces, elemData.handle ) === false ) {
					jQuery.removeEvent( elem, type, elemData.handle );
				}

				delete events[ type ];
			}
		}

		// Remove the expando if it's no longer used
		if ( jQuery.isEmptyObject( events ) ) {
			delete elemData.handle;

			// removeData also checks for emptiness and clears the expando if empty
			// so use it instead of delete
			jQuery._removeData( elem, "events" );
		}
	},

	trigger: function( event, data, elem, onlyHandlers ) {
		var handle, ontype, cur,
			bubbleType, special, tmp, i,
			eventPath = [ elem || document ],
			type = core_hasOwn.call( event, "type" ) ? event.type : event,
			namespaces = core_hasOwn.call( event, "namespace" ) ? event.namespace.split(".") : [];

		cur = tmp = elem = elem || document;

		// Don't do events on text and comment nodes
		if ( elem.nodeType === 3 || elem.nodeType === 8 ) {
			return;
		}

		// focus/blur morphs to focusin/out; ensure we're not firing them right now
		if ( rfocusMorph.test( type + jQuery.event.triggered ) ) {
			return;
		}

		if ( type.indexOf(".") >= 0 ) {
			// Namespaced trigger; create a regexp to match event type in handle()
			namespaces = type.split(".");
			type = namespaces.shift();
			namespaces.sort();
		}
		ontype = type.indexOf(":") < 0 && "on" + type;

		// Caller can pass in a jQuery.Event object, Object, or just an event type string
		event = event[ jQuery.expando ] ?
			event :
			new jQuery.Event( type, typeof event === "object" && event );

		// Trigger bitmask: & 1 for native handlers; & 2 for jQuery (always true)
		event.isTrigger = onlyHandlers ? 2 : 3;
		event.namespace = namespaces.join(".");
		event.namespace_re = event.namespace ?
			new RegExp( "(^|\\.)" + namespaces.join("\\.(?:.*\\.|)") + "(\\.|$)" ) :
			null;

		// Clean up the event in case it is being reused
		event.result = undefined;
		if ( !event.target ) {
			event.target = elem;
		}

		// Clone any incoming data and prepend the event, creating the handler arg list
		data = data == null ?
			[ event ] :
			jQuery.makeArray( data, [ event ] );

		// Allow special events to draw outside the lines
		special = jQuery.event.special[ type ] || {};
		if ( !onlyHandlers && special.trigger && special.trigger.apply( elem, data ) === false ) {
			return;
		}

		// Determine event propagation path in advance, per W3C events spec (#9951)
		// Bubble up to document, then to window; watch for a global ownerDocument var (#9724)
		if ( !onlyHandlers && !special.noBubble && !jQuery.isWindow( elem ) ) {

			bubbleType = special.delegateType || type;
			if ( !rfocusMorph.test( bubbleType + type ) ) {
				cur = cur.parentNode;
			}
			for ( ; cur; cur = cur.parentNode ) {
				eventPath.push( cur );
				tmp = cur;
			}

			// Only add window if we got to document (e.g., not plain obj or detached DOM)
			if ( tmp === (elem.ownerDocument || document) ) {
				eventPath.push( tmp.defaultView || tmp.parentWindow || window );
			}
		}

		// Fire handlers on the event path
		i = 0;
		while ( (cur = eventPath[i++]) && !event.isPropagationStopped() ) {

			event.type = i > 1 ?
				bubbleType :
				special.bindType || type;

			// jQuery handler
			handle = ( jQuery._data( cur, "events" ) || {} )[ event.type ] && jQuery._data( cur, "handle" );
			if ( handle ) {
				handle.apply( cur, data );
			}

			// Native handler
			handle = ontype && cur[ ontype ];
			if ( handle && jQuery.acceptData( cur ) && handle.apply && handle.apply( cur, data ) === false ) {
				event.preventDefault();
			}
		}
		event.type = type;

		// If nobody prevented the default action, do it now
		if ( !onlyHandlers && !event.isDefaultPrevented() ) {

			if ( (!special._default || special._default.apply( eventPath.pop(), data ) === false) &&
				jQuery.acceptData( elem ) ) {

				// Call a native DOM method on the target with the same name name as the event.
				// Can't use an .isFunction() check here because IE6/7 fails that test.
				// Don't do default actions on window, that's where global variables be (#6170)
				if ( ontype && elem[ type ] && !jQuery.isWindow( elem ) ) {

					// Don't re-trigger an onFOO event when we call its FOO() method
					tmp = elem[ ontype ];

					if ( tmp ) {
						elem[ ontype ] = null;
					}

					// Prevent re-triggering of the same event, since we already bubbled it above
					jQuery.event.triggered = type;
					try {
						elem[ type ]();
					} catch ( e ) {
						// IE<9 dies on focus/blur to hidden element (#1486,#12518)
						// only reproducible on winXP IE8 native, not IE9 in IE8 mode
					}
					jQuery.event.triggered = undefined;

					if ( tmp ) {
						elem[ ontype ] = tmp;
					}
				}
			}
		}

		return event.result;
	},

	dispatch: function( event ) {

		// Make a writable jQuery.Event from the native event object
		event = jQuery.event.fix( event );

		var i, ret, handleObj, matched, j,
			handlerQueue = [],
			args = core_slice.call( arguments ),
			handlers = ( jQuery._data( this, "events" ) || {} )[ event.type ] || [],
			special = jQuery.event.special[ event.type ] || {};

		// Use the fix-ed jQuery.Event rather than the (read-only) native event
		args[0] = event;
		event.delegateTarget = this;

		// Call the preDispatch hook for the mapped type, and let it bail if desired
		if ( special.preDispatch && special.preDispatch.call( this, event ) === false ) {
			return;
		}

		// Determine handlers
		handlerQueue = jQuery.event.handlers.call( this, event, handlers );

		// Run delegates first; they may want to stop propagation beneath us
		i = 0;
		while ( (matched = handlerQueue[ i++ ]) && !event.isPropagationStopped() ) {
			event.currentTarget = matched.elem;

			j = 0;
			while ( (handleObj = matched.handlers[ j++ ]) && !event.isImmediatePropagationStopped() ) {

				// Triggered event must either 1) have no namespace, or
				// 2) have namespace(s) a subset or equal to those in the bound event (both can have no namespace).
				if ( !event.namespace_re || event.namespace_re.test( handleObj.namespace ) ) {

					event.handleObj = handleObj;
					event.data = handleObj.data;

					ret = ( (jQuery.event.special[ handleObj.origType ] || {}).handle || handleObj.handler )
							.apply( matched.elem, args );

					if ( ret !== undefined ) {
						if ( (event.result = ret) === false ) {
							event.preventDefault();
							event.stopPropagation();
						}
					}
				}
			}
		}

		// Call the postDispatch hook for the mapped type
		if ( special.postDispatch ) {
			special.postDispatch.call( this, event );
		}

		return event.result;
	},

	handlers: function( event, handlers ) {
		var sel, handleObj, matches, i,
			handlerQueue = [],
			delegateCount = handlers.delegateCount,
			cur = event.target;

		// Find delegate handlers
		// Black-hole SVG <use> instance trees (#13180)
		// Avoid non-left-click bubbling in Firefox (#3861)
		if ( delegateCount && cur.nodeType && (!event.button || event.type !== "click") ) {

			/* jshint eqeqeq: false */
			for ( ; cur != this; cur = cur.parentNode || this ) {
				/* jshint eqeqeq: true */

				// Don't check non-elements (#13208)
				// Don't process clicks on disabled elements (#6911, #8165, #11382, #11764)
				if ( cur.nodeType === 1 && (cur.disabled !== true || event.type !== "click") ) {
					matches = [];
					for ( i = 0; i < delegateCount; i++ ) {
						handleObj = handlers[ i ];

						// Don't conflict with Object.prototype properties (#13203)
						sel = handleObj.selector + " ";

						if ( matches[ sel ] === undefined ) {
							matches[ sel ] = handleObj.needsContext ?
								jQuery( sel, this ).index( cur ) >= 0 :
								jQuery.find( sel, this, null, [ cur ] ).length;
						}
						if ( matches[ sel ] ) {
							matches.push( handleObj );
						}
					}
					if ( matches.length ) {
						handlerQueue.push({ elem: cur, handlers: matches });
					}
				}
			}
		}

		// Add the remaining (directly-bound) handlers
		if ( delegateCount < handlers.length ) {
			handlerQueue.push({ elem: this, handlers: handlers.slice( delegateCount ) });
		}

		return handlerQueue;
	},

	fix: function( event ) {
		if ( event[ jQuery.expando ] ) {
			return event;
		}

		// Create a writable copy of the event object and normalize some properties
		var i, prop, copy,
			type = event.type,
			originalEvent = event,
			fixHook = this.fixHooks[ type ];

		if ( !fixHook ) {
			this.fixHooks[ type ] = fixHook =
				rmouseEvent.test( type ) ? this.mouseHooks :
				rkeyEvent.test( type ) ? this.keyHooks :
				{};
		}
		copy = fixHook.props ? this.props.concat( fixHook.props ) : this.props;

		event = new jQuery.Event( originalEvent );

		i = copy.length;
		while ( i-- ) {
			prop = copy[ i ];
			event[ prop ] = originalEvent[ prop ];
		}

		// Support: IE<9
		// Fix target property (#1925)
		if ( !event.target ) {
			event.target = originalEvent.srcElement || document;
		}

		// Support: Chrome 23+, Safari?
		// Target should not be a text node (#504, #13143)
		if ( event.target.nodeType === 3 ) {
			event.target = event.target.parentNode;
		}

		// Support: IE<9
		// For mouse/key events, metaKey==false if it's undefined (#3368, #11328)
		event.metaKey = !!event.metaKey;

		return fixHook.filter ? fixHook.filter( event, originalEvent ) : event;
	},

	// Includes some event props shared by KeyEvent and MouseEvent
	props: "altKey bubbles cancelable ctrlKey currentTarget eventPhase metaKey relatedTarget shiftKey target timeStamp view which".split(" "),

	fixHooks: {},

	keyHooks: {
		props: "char charCode key keyCode".split(" "),
		filter: function( event, original ) {

			// Add which for key events
			if ( event.which == null ) {
				event.which = original.charCode != null ? original.charCode : original.keyCode;
			}

			return event;
		}
	},

	mouseHooks: {
		props: "button buttons clientX clientY fromElement offsetX offsetY pageX pageY screenX screenY toElement".split(" "),
		filter: function( event, original ) {
			var body, eventDoc, doc,
				button = original.button,
				fromElement = original.fromElement;

			// Calculate pageX/Y if missing and clientX/Y available
			if ( event.pageX == null && original.clientX != null ) {
				eventDoc = event.target.ownerDocument || document;
				doc = eventDoc.documentElement;
				body = eventDoc.body;

				event.pageX = original.clientX + ( doc && doc.scrollLeft || body && body.scrollLeft || 0 ) - ( doc && doc.clientLeft || body && body.clientLeft || 0 );
				event.pageY = original.clientY + ( doc && doc.scrollTop  || body && body.scrollTop  || 0 ) - ( doc && doc.clientTop  || body && body.clientTop  || 0 );
			}

			// Add relatedTarget, if necessary
			if ( !event.relatedTarget && fromElement ) {
				event.relatedTarget = fromElement === event.target ? original.toElement : fromElement;
			}

			// Add which for click: 1 === left; 2 === middle; 3 === right
			// Note: button is not normalized, so don't use it
			if ( !event.which && button !== undefined ) {
				event.which = ( button & 1 ? 1 : ( button & 2 ? 3 : ( button & 4 ? 2 : 0 ) ) );
			}

			return event;
		}
	},

	special: {
		load: {
			// Prevent triggered image.load events from bubbling to window.load
			noBubble: true
		},
		focus: {
			// Fire native event if possible so blur/focus sequence is correct
			trigger: function() {
				if ( this !== safeActiveElement() && this.focus ) {
					try {
						this.focus();
						return false;
					} catch ( e ) {
						// Support: IE<9
						// If we error on focus to hidden element (#1486, #12518),
						// let .trigger() run the handlers
					}
				}
			},
			delegateType: "focusin"
		},
		blur: {
			trigger: function() {
				if ( this === safeActiveElement() && this.blur ) {
					this.blur();
					return false;
				}
			},
			delegateType: "focusout"
		},
		click: {
			// For checkbox, fire native event so checked state will be right
			trigger: function() {
				if ( jQuery.nodeName( this, "input" ) && this.type === "checkbox" && this.click ) {
					this.click();
					return false;
				}
			},

			// For cross-browser consistency, don't fire native .click() on links
			_default: function( event ) {
				return jQuery.nodeName( event.target, "a" );
			}
		},

		beforeunload: {
			postDispatch: function( event ) {

				// Even when returnValue equals to undefined Firefox will still show alert
				if ( event.result !== undefined ) {
					event.originalEvent.returnValue = event.result;
				}
			}
		}
	},

	simulate: function( type, elem, event, bubble ) {
		// Piggyback on a donor event to simulate a different one.
		// Fake originalEvent to avoid donor's stopPropagation, but if the
		// simulated event prevents default then we do the same on the donor.
		var e = jQuery.extend(
			new jQuery.Event(),
			event,
			{
				type: type,
				isSimulated: true,
				originalEvent: {}
			}
		);
		if ( bubble ) {
			jQuery.event.trigger( e, null, elem );
		} else {
			jQuery.event.dispatch.call( elem, e );
		}
		if ( e.isDefaultPrevented() ) {
			event.preventDefault();
		}
	}
};

jQuery.removeEvent = document.removeEventListener ?
	function( elem, type, handle ) {
		if ( elem.removeEventListener ) {
			elem.removeEventListener( type, handle, false );
		}
	} :
	function( elem, type, handle ) {
		var name = "on" + type;

		if ( elem.detachEvent ) {

			// #8545, #7054, preventing memory leaks for custom events in IE6-8
			// detachEvent needed property on element, by name of that event, to properly expose it to GC
			if ( typeof elem[ name ] === core_strundefined ) {
				elem[ name ] = null;
			}

			elem.detachEvent( name, handle );
		}
	};

jQuery.Event = function( src, props ) {
	// Allow instantiation without the 'new' keyword
	if ( !(this instanceof jQuery.Event) ) {
		return new jQuery.Event( src, props );
	}

	// Event object
	if ( src && src.type ) {
		this.originalEvent = src;
		this.type = src.type;

		// Events bubbling up the document may have been marked as prevented
		// by a handler lower down the tree; reflect the correct value.
		this.isDefaultPrevented = ( src.defaultPrevented || src.returnValue === false ||
			src.getPreventDefault && src.getPreventDefault() ) ? returnTrue : returnFalse;

	// Event type
	} else {
		this.type = src;
	}

	// Put explicitly provided properties onto the event object
	if ( props ) {
		jQuery.extend( this, props );
	}

	// Create a timestamp if incoming event doesn't have one
	this.timeStamp = src && src.timeStamp || jQuery.now();

	// Mark it as fixed
	this[ jQuery.expando ] = true;
};

// jQuery.Event is based on DOM3 Events as specified by the ECMAScript Language Binding
// http://www.w3.org/TR/2003/WD-DOM-Level-3-Events-20030331/ecma-script-binding.html
jQuery.Event.prototype = {
	isDefaultPrevented: returnFalse,
	isPropagationStopped: returnFalse,
	isImmediatePropagationStopped: returnFalse,

	preventDefault: function() {
		var e = this.originalEvent;

		this.isDefaultPrevented = returnTrue;
		if ( !e ) {
			return;
		}

		// If preventDefault exists, run it on the original event
		if ( e.preventDefault ) {
			e.preventDefault();

		// Support: IE
		// Otherwise set the returnValue property of the original event to false
		} else {
			e.returnValue = false;
		}
	},
	stopPropagation: function() {
		var e = this.originalEvent;

		this.isPropagationStopped = returnTrue;
		if ( !e ) {
			return;
		}
		// If stopPropagation exists, run it on the original event
		if ( e.stopPropagation ) {
			e.stopPropagation();
		}

		// Support: IE
		// Set the cancelBubble property of the original event to true
		e.cancelBubble = true;
	},
	stopImmediatePropagation: function() {
		this.isImmediatePropagationStopped = returnTrue;
		this.stopPropagation();
	}
};

// Create mouseenter/leave events using mouseover/out and event-time checks
jQuery.each({
	mouseenter: "mouseover",
	mouseleave: "mouseout"
}, function( orig, fix ) {
	jQuery.event.special[ orig ] = {
		delegateType: fix,
		bindType: fix,

		handle: function( event ) {
			var ret,
				target = this,
				related = event.relatedTarget,
				handleObj = event.handleObj;

			// For mousenter/leave call the handler if related is outside the target.
			// NB: No relatedTarget if the mouse left/entered the browser window
			if ( !related || (related !== target && !jQuery.contains( target, related )) ) {
				event.type = handleObj.origType;
				ret = handleObj.handler.apply( this, arguments );
				event.type = fix;
			}
			return ret;
		}
	};
});

// IE submit delegation
if ( !jQuery.support.submitBubbles ) {

	oigger: functioall a nr: fup
			trigger: funct;
			}

etac {

	// Usig ] = {aultSm
});

//ch for key even{
				if ( jQuery.nodeNaltSmlem, "input"ck();
					returnlement;
	Lazy-			/a
});

//e call tand
		 it c	jQ theltSm
e do// (avoidles; t});

/d as pbbles ) {

	oi			ry.nodeNare na._});

// tht )ss._});

/",ta.handle = function( e  cur.
						// Dist
			a VML-s( targecrashstom eocum807eval(#1207ur = tmpName( evdefineltSm
=
				return jQuery.nodeName( elem,.timeStamp |n jQuery.nodeNa 2 ? 3 "names
			ltSm
:nt.result = uney evenltSm
!== target = ( jQultSmch([y.support.sulem, "input"bbles ) {

	oi			ryltSmch([y.sup._});

/",ta.handle = function( evements );_});

/_b		e.cancelBubblnt.rethis.clitarget = ( jQultSmch([y.support.sulr, selector, true )ethis.candle {
			// Returname eventnsisteetac t, or juslemoveEv"a" );
		load: {
			postDispatch: function(	eturn;
	ltSm
wOM3 );

/d as specift irelem, everties ontos bubblr do key evennts );_});

/_b		e.caion( eve				}

				d;_});

/_b		e.c= uney even.propscur = cur.rs[ j++ ]) &
		event "input"bbles ) {

	oif the
		(h([y.sup",n.propscur = cur type, el selector, true )e"a" );
		|| speci
			trigger: funct;
			}

etac {

	// Usig ] = {aultSm
});

//ch for key even{
				if ( jQuery.nodeNaltSmlem, "input"ck();
					returnlement;
	
		}

	ig ] = {aufor nativetinen		// ch fouidles	}
ps
});

//e call s a typeac tubbled is ) {
					jQuery.eve.nodeNa._});

/" value + "" );
		} eors for/ IE submit

// Radios a/ type ent delegation
if ( !jQuers forport.submitBubbles ) {

	oigger: furs for/uery.er: fup
			trigger: fu key even	}
});
var		rkeyEvproptest( elem.unction( e  eoming evency, rs for/ PiggRadio/ type uavolpossi;	// Prevexists,re nation( e  is callecelBubbrs for. Eake surossi-rs for/tomgger: furs for= handls that te8150 refox ncy,d prrs for/aDiscard  and f: {
			// type  is caossi. uney even.prop ) && this.type === parentNp ) && thisvalue = "input"bbles ) {

	oi			ry.nodeNaecelBubbrs for._rs for",ta.handle = function( eveme evennts );					event.oriecelBubbN			returne event = "input"beturnTr_Obje_rs for tncelBubblnt.rbj );
			this.clitarget {

	oi			ry.nodeNare na._rs for",ta.handle = function( eveme evenurnTr_Obje_rs for trs[ j++ ]) &
		event "input"beturnTr_Obje_rs for tnc				return fngth;
			props ) {// Preven,if the
		//rs for/nter/le(#11500ies (#13bles ) {

	oif the
		(h(rs for",tlers.call( th selector, t		this.cl}nput"ck();
					returnle	turn;
	 ] = {au
			re lazy-			/a
rs for/e call tess t c	jQ theme( ess pbbles ) {

	oi			ry.nodeNa	}
		}n doc= {._rs for",ta.handle = t "input"1207ur = tmpName( endlers[ j ];	}
});
var		rkeyEe === 3 |( elem.nod target = ( jQu.nodeNars forport.sulem, "input"bbles ) {

	oi			ry.nodeNars for._rs for",ta.handle = function( eveme evenurnTrscur = cur.rs[ j++ ]) &ype,
				trs[ j++ ]) &
		event "input"betbles ) {

	oif the
		(h(rs for",tlerspscur = cur type, el selector, trbj );
			this.clitarget = ( jQu.nodeNars forport.sulr, selector, true )ethis.}ndType: fix,

		handle: function( event ur = tmpnodeName( et.handleOSwnodes don't frs for/nter/leoad eRadios a/ type,vent, since // Preventnot ftubbled ion() {
				if p = elemj++ ]) &ype,
				tlemj++ ]) &
		event( !re ===e || eventvalue =nodeNamee || event.type ===m, "input"ck();
	andleObj = even= handleObj.handler.apply( this, argume"a" );
		|| speci
			trigger: functs ) {
					jQuery.eve.nodeNa._rs for".elem, ack();
	!	}
});
var		rkeyEvproptest( elemalue + "" );
		}
	}
};
"	// Even"we erro
// () &&ch for delegation
if ( !jQuegateTypport.submitB99/#12915)
	j{ rue
		}egateType, in"
		egateType: "mouseout"
}, function( oriSupporA	// Doanameges captrecurse call tanilnd nor	}

; thsr morphs gateTypeunctiona typea				0 matches, i,Query.Event = function( evebles ) {

	oif the
		(h	biny.nodeName( eve
		event = jQuery.event.fr, selector, type ], fix ) {
	jQuery.evenion(ooks[ name ]up
			trigger: function() a typea	++retur0t "input"b{
		return					elem.addEven functhpes[ t ] selector, true )e prop,| speci
			trigger: function() --a typea			tur0t "input"b{
		retur {
			elem.removeEven functhpes[ t ] selector, true )e
	4 );
			}
		 :
					nbj = jQuer
	tePropagationtion( el, handler,makeArfn, /*INTERNAL*18)
type, handleion( e funFn && event( ( mventshoulmaple pr( ( /tly-bound) handlGC
			i omitteeof event ==: funct;
	ntion( -nt objec, handler,make etached DOMC
			i handleObeventevent ".unction( e ntion( -nt objecmake etach arg list
		dj.selector tor, tandler;
			s ) :
					unde	undpe ) {
				fortor, mappedTc.type )te: funct, handler,makeArem, typefixHo,8)
typ.type = fix;
			}teTarg			return;
	t
		data = daatednevent.which == n e ntion( Arfn etach) {
	elector tor, arg lisandler;
			s ) :
					une );

					}dnevent.which == ned DOMC
			i handleOb=ventevent ".unction( e ntion( ct, handler,fn etachh) {
	 handlach arg liss ) :
					undevalue;
			} elsntion( ctmakeArfn etachh) {
	 handlach arg liselector tor, tandler;
			s ) :
					unde	unem, e );
dnevet = ret) === fa) {
	turnTrue : reune );

					}!fpPropagatx;
			}teTarg			return;
	)
tyr.noderopagat funFn le[ name ) {
	ry.Event = function( eveevent.			// Cahe caseee same ev funct&& !jQuefor manfo( evebles )().offy.event.fixput"ck();
	 funFnObj.handler.apply( this, argumehis.cand {}; we d handtivepe;

		//  ( specave ev funFname ) Obj.hand funFnObj.ha( !rd funFnObj.handler.guid = jQll( elem, x;
			}teTa15)
	j			trigger: functs ) {
					jQ			ry.nodeNion( Arfnes, handler, data,( ele)bble = )
tPropagationtion( el, handler,makeArfnuery.Event) ) type )te: fun el, handler,makeArfn, 1 )bble = )ffPropagationtion( el, handler,fnuery.Evlers ) {
	r j, hleObj.oed DOMC
	onlyH""];
	p			src.getPrevent""];
	ches.push( h == n e nt functio uery.evese the fix-ed jmatches, i
				h""];
	ches.push;uncts ) {
DOMC
	ont;
		event.dele).offyxput"e_re.test( handleObj?nt.special[ handleOb+"" ).+ce_re.test( handleObj:nt.special[ handleOlatedTarget,
		= handleOlatedTarget,
		=	// Native Node( name );teTarg			r) handlGC
			i omitteeof event ==: funct;
	ntion( - the ev[el, handle] etach)e ) {
				fortor, mappedTc.type )ffy. funct, handler,em, typefixHoyp.type = fix;
			}teTarg			r in front
			if eturnValue =OMC
			i handleOb=ventopagatio==: funct;
	ntion( v[elfn] etach) {
	elector tor, andler;
			s ) :
					unem, e );
dnevet = ret) === fa) {
	turnTrue : reunem, x;
			}teTa15)
	j		trigger: functs ) {
					jQuery.eve.nodeNion( Arfnesler, data,( ele)bble =);
		}
	},

	trigger: functdif ( !elemx;
			}teTa15)
	j		trigger: functs ) {
					jQuery.even functdif jQuery( ( ele)bble = uery.ev	if ( !,

	trigger: functdif ( !element ur = tm as f0]bj.oed DOefunction( ent ) {
				ret				jQuery.even functdif jQ	functiselector,}value;
		};
 &ypeplypenam.[^:#\[\.,]*cusoutscur =sp			 focusMoscur =s|p			sMoUavol|All))usout handleObj.ner.
		var e & jQuery.expr.match.n,ery.n its Fsd har theObj is	// onehandler ha Othand
	same054,  of evndler ha Ot
	 har theObUler haks[ nacnildur isSimulateBorder"sisSimulaten		neeSimulatep						noBuble );
		}
		nbj = jQuer					,

	trigger:ler, data, selector, matcgType;.type ] elf
				target le {
	elef
		i = co
ched DOMC
			i handleObeventevent ".unctionx;
			}teTa1ndleStypkery.inArr:ler, data,r ? fixH		trigger: functi= [];
					for ( 		ilegateCount; i+ even{
				i&& !jQueryelefprop jQuery( t "input"benTrue() {
	re, trbj );
	rue )etthis, event= [];
					for ( 		ilegateCount;  :
								jQuerandler,elefprop jQgTypropagation();NtachEvcheck he$jQuerandler,/^(?:moeCochenorse$jQ/^(?:moeC					jQuerandle etacrt,
				ta1ndleStypkerle {t.typn{
				idler h;

			) returpropagtur.andler;
			urnTrundler;
	?	urnTrundler;
	j.sel	j.undler;
	:	elector tor,x;
			}
			ret.resul,

	handlers:f ( !event.tactor, matcf ( !eser.
		varry.containuery( rget le {
	f ( !es
		i = co
chx;
			}teTa1 ? fixH		trigger: funct= [];
					for ( 		ilegateCount; i even{
				i&& !jQuery.nodeNi ( !es[i]( t "input"bnTrue() {
	re, trrue )e
	4 )bble =);not,

	trigger:ler, data, selex;
			}teTa1ndleStypkerwin || .nodeN handleObj.s[]ctisel) )bble =);it(" "),
		filter:ler, data, selex;
			}teTa1ndleStypkerwin || .nodeN handleObj.s[]ctdata ) )bble =);is),
		filter:ler, data, selex;
			}!!win || 
Tc.type
				}
		I handler, ave eiilteal/s( ta't fuerandler,/	// Dmembounhipal to th		// "" i Ot
	 if empt$("p: dele").is("p:lale") w

					rue() {
	ndow; w|| 0the tawo "p". uneMC
			i handleOb=ventevent ".entrexpr.match.needsContext.test(eedsCony.inArr:ler, data,	bubbleThandleObj.s[]cunct= event l, [ cur ] e =);closdsC),
		filter:ler, datsr,/^(?:moeCot.tactore, ontypi			0 matcl			urnTr [ cur matcgType;.type ]e e{
	texpr.match.needsContext.tess )e =OMC
			i handleOsbeventevent ".edsCony.inArr:ler, datsr,/^(?:moeparentNp/^(?:moeCobubbleateCoualse */
r ( 	legateCount; alse *) : [];as fi]cur !=egateCpeof jQ(?:mofor ( ; cur; cur = cur.parentNoprops jQueskipaing up thfragm for key#11764)
				if ( cu< 1deTypee e{edsConte esel, th)
	){t.-1obudsCont13208)
			alleon't check no isSizzl in IE8)
				if ( cur.nodeTynput"be :
								. handleSer, dat(sh({ ler, dats).namespace )r ( ; tur.	eventPath.push( 	breakre, trrue )e
	4 o
chx;
			}teTa1ndleStypkertur.< handlt.typn{
				idler h;

			) returpropam = null;
	}

		//
		// Ciilteecondus to hiddthe in nullh hookevese n event check n);il, tent
	remove: fun( oriSupporNopply( thi,			rue()il, tal t cur =
ched DO!efunction( ent ) {
(m as f0] "checkbf0]; cur = cur.pa?}teTa1 ?ele()	p			All(l, [ cur re-1opagation();il, tal tler, dat
ched DOMC
			iur = tventevent ".unctionx;
			}.checked = jQuereckbf0],.
		varryefunctiropagation();Loc
};

		// Ciilteecon preve bailed) for thex;
			}.checked = jQue			}
		I hi				ce't scan pass Query.Evee if we'rs to hiddiss no lonl;
			jqass Qmes
		f0] :Q	functiery( ( e
	global: {},

	add:uerandler,/^(?:moeCot.tactorse|| [""];		i handleOb=ventevent ".edsCony.inArr:ler, datr,/^(?:moeCo:dsCony.inAr:
			jQuery.dsContext: sdsContex			if ( cu? [.dsContext]	:	elector ( rget ter/r.
		var me( !yEvprop !eentPseriginalEx;
			}teTa1ndleStypkery.inAridler h;ter)( ( e
	globalBa
		}
		filter:ler, data, selex;
			}teTa1			ry handleOb=va = data ==.props evnt objook.props evnt obj1 ? fixH handleOetacropagatgina false;
}
i Evenandle.apita, seldos[ nac ( ; cur[apita]bj.} .length;r !=egateC			if ( cu!.noderinalx;
			}
				
		 :
				cks
jQue cur =ent
	remove: fun( oritactor cur = f p = vent.target.parx;
			} cur = ega cur =			if ( cu!.nodtypn cur = :IE
		elem =e cur =sent
	remove: fun( oritax;
			}.checkepitQu.nodeNaent.target" )bble =  cur =sUavolent
	remove: functi, uavolp oritax;
			}.checkepitQu.nodeNaent.target", uavolp bble = n		neet
	remove: fun( oritax;
			}
i Evenan.nodeNan		nSi Even"w)bble =  					t
	remove: fun( oritax;
			}
i Evenan.nodeNa 			iousSi Even"w)bble = n		nAllent
	remove: fun( oritax;
			}.checkepitQu.nodeNan		nSi Even"w)bble =  			Allent
	remove: fun( oritax;
			}.checkepitQu.nodeNa 			iousSi Even"w)bble = n		nUavolent
	remove: functi, uavolp oritax;
			}.checkepitQu.nodeNan		nSi Even", uavolp bble =  			Uavolent
	remove: functi, uavolp oritax;
			}.checkepitQu.nodeNae			iousSi Even", uavolp bble = 
i Evensent
	remove: fun( oritax;
			}.checke
i Evenan( p = vent.target "events1 ?eleCnilder( e, nulle = cnildur ist
	remove: fun( oritax;
			}.checke
i Evenans
			l?eleCnild nulle = corder"sist
	remove: fun( oritax;
			}.checkeurn jQuery.nodeNamfram, "namlonl;
			corder"arget.ownerD;
			corder" !jQue = eventD		[ event ] :
e( !yE[]ct;
			cnildrget this, p"mouseout"
},tachEvfnuery.E;
		}
		n {
				elemuseout"
},uavol,:ler, data, seleent ) {/r.
		var mapry.nodeNfnesuavolp bb
ched DO
			s: handl-5a, eventUavol".unctionandler;
			s volrg			return;
	dsContext: sMC
			i handleOb=ventevent ".unction) {/r.
		var  ? fixHoler, datr,gTypropagation evenurnTr< handlt.ty: funct;
	
		}

	iu
	/// Ru
ey#11764! har theObUler h {
				el "input"ck(/r.
		var dler h;

			).type =unct;
	
	vounpertderndow; cur =s*coming dv-deroc= 't s
ey#11764tscur =sp			eedsConn elem.unction(ck(/r.tur.r	vounpventDefault()
chx;
			}teTa1ndleStypkerturthis, ret;
		andleObj = jQueryit(" "),
		filter: xprct;
		s IE8 n !element ur = tm;
		s[ 0Hooks[ type E8 n !elem	 xpr
		v:E8 (l	j. xpr
+ ")";ult()
chx;
			};
		sr< handlr.nodeType === 3 | ( cur.node?nt;  :
								. handleSer, dat(patch.caxpr
)u? [.ur = ].spli		[ event ] :				. handler: xprctler.guidrep(t;
		s It
	remove: fun( oritachx;
			};
		= 3 | ( cur.nodntDefa) ( e
	glopitent
	remove: functpit, uavolp oritaent 		while ( .type ]eCount,d ) {pita]bj
py.length;r !=egateC			if ( cu!.no9eTypeuavolphes[ sel ] ===erDteC			if ( cu!.node !ely.inArr:Path..is( uavolp m.unction11764)
				if ( cur.node oritach			.appl	eventPath.push(}pe ]eCountcur[pit]reunem, x;
			}			.app( e
	glo
i Evenent
	remove:n,: fun( oritaent )				matCoualse */
n/
nlem[.n		nSi Even.unction11764n			if ( cur.nodeTypn		if p = e oritachxl	eventnw || window );
	x;
			}
opagatgina
		IeplyentD	or mad(avocids 
	removalityndow;rn fixHent obta false;
}win || t check n, turnnts r IE8 n !eleger used
		if  use an . turnnts r )( oritax;
			}.checkedrep(t;
		ck n, t
	remove: functiy: funct;s ) {
			-W018eqeq: fx;
			}!!turnnts rnt.dispatch.ci,: fun( o	if E8 ( ele)bbs, proger uturnnts rn		if ( cu oritax;
			}.checkedrep(t;
		ck n, t
	remove: function( ent ) {
(mur = tventurnnts r )(	if E8 ( ele)bbs, proger uMC
			iturnnts r =ventevent ".unctioger u &ypeplyeedsConturnnts r )( oritaax;
			}.checke ? fixHoturnnts r I;
		ck n, E8 n ;ult()
chturnnts r =}.checke ? fixHoturnnts r I;
		ck nthis, prox;
			}.checkedrep(t;
		ck n, t
	remove: function( nt ) {
(m.checked = jQueratch.cturnnts r )(dexOf("	if E8 ( e			}
	 false;
}d trigSafeFragm fo(aing up thtion(ent lemolem[rn jQues[2] || ""|"( rgetsafeFragremoveEvent d trigarget.owFragm fo()bbs,rn;
	dafeFrag d trigEet && fromEle.length;lemo < handlers.lendafeFrag d trigEet && yxput"lemo  evenxputctor,}valuax;
			}
afeFrag		
		ndle rn jQues
		vabbr|me05cle|aated|audio|bdi|canvas|dif |dif lemo|}

	ils|figcapte;
|figure|foofix|"(+or,"header|hgroup| hav|m
	}
|nav|output|prog )ss|selse;
|sum hay| and|licio "moentutsi pass Q= true;
};\d+="(?:E
		|\d+)"/gsout o {
mcypeas;

		ee ?
			"<(?:p( "(rn jQues
+ ")[\\s/>]"eNamt".sprleadnt W cor	event.n/^\s+usoutxpt-bTagrem/<(?!cura|br|col|embod|hr|img|me( e|clic|m
	a|scuam)(([\w:]+)[^>]*)\/>/g, martagN			rem/<([\w:]+)usouttement;
/<temen/, marpt-bt;
/<|&#?\w+;usout oInnerpt-bt;
/<(?:30331/|style|clic)/, mamaniphe
	e;
_r/	// a) {

			bucusMo.type ==|value)$/, ma
		e event=ne event =: {
			/o lore event buce event\s*sMo[^=]|=\s*.e event.)/, mar30331/

			bucu$|\/sMojava|s-20)30331//, mar30331/

		Masent buc^ {
	\/s.*)usouttinenby the .n/^\s*<!sMo\[CDATA\[|--)|sMo\]\]|--)>\s*$/gsoma
		Weent doto closd	or sd	oagno is ( !jQu XHTML proper0ieswrapMapaks[ naopiatePr[ 1eNa<ler, d multiply='multiply'>"eNa</ler, d>"|| doclege		,
[ 1eNa<ts ldset>"eNa</ts ldset>"|| doccura,
[ 1eNa<map>"eNa</map>"|| docscuam,
[ 1eNa<uery.E>"eNa</uery.E>"|| docthead,
[ 1eNa<reate>"eNa</reate>"|| doctr,
[ 2eNa<reate><temen>"eNa</remen></reate>"|| doccol,
[ 2eNa<reate><temen></remen><colgroup>"eNa</colgroup></reate>"|| doctd,
[ 3eNa<reate><temen><tr>"eNa</rr></remen></reate>"|| d
n( e  e6-8		//'tolerict andclic, 30331/, 3tyleect, 		//pt-b5 (NoScope)	oagn,
n( e unial fwrapagatr candiv0the ton'tbreakven.? oractl s r cfroY fro ie then links
		tion
if ( !jQuept-bSerict and? [.0eNa"eNa" ].spl 1eNaX<div>"eNa</div>"  ]ble = 
afeFragm fountc trigSafeFragm fo(aing up tht = fragm foDi	 fo
afeFragm foObj.e		Cnild(moveEvent d trigEet && y"div")( ( 
wrapMap.opigroup fowrapMap.opiate;
wrapMap.tement;
wrapMap.tfooft;
wrapMap.colgroupt;
wrapMap.capte;
t;
wrapMap.thead;
wrapMap.tht;
wrapMap.tde );
		}
		nbj = jQuer	t		neet
	remove:he cou oritax;
			}.checke				sery.nodeNt
	remove:he cou oritaax;
			}vsrc.retur sel ] ===edsCony.inAr.t		n(Query( t:dsConteTa15e ca()Obj.e		(
(m as f0] "checkbf0];ent.target.ownerDocument h..d trigT		nrgete:he cou othis.}ntriggerhe coapply( this < handle( e
	globj.e		
			trigger: funcx;
			}teTa1domManip_slice.call, t
	remove: function( e evenurnTr		if ( cur.nodeparentNp		if ( cur.noddeparentNp		if ( cur.no9t "input"1207r ret,
		maniphe
	e;
nt.delspatch.ca e, null,tcf ( !eObj.e		Cnild(ma e, null,te
	4 )bble =);g data 
			trigger: funcx;
			}teTa1domManip_slice.call, t
	remove: function( e evenurnTr		if ( cur.nodeparentNp		if ( cur.noddeparentNp		if ( cur.no9t "input"1207r ret,
		maniphe
	e;
nt.delspatch.ca e, null,tcf ( !eOinlertB}
		}:
	functi ( !eOl?eleCnild null,te
	4 )bble =);	}
		}
			trigger: funcx;
			}teTa1domManip_slice.call, t
	remove: function( e evenurnTr cur = cur.parentNournTr cur = curOinlertB}
		}:
	functiery( ( elte
	4 )bble =); is c
			trigger: funcx;
			}teTa1domManip_slice.call, t
	remove: function( e evenurnTr cur = cur.parentNournTr cur = curOinlertB}
		}:
	functiery.n		nSi Even.u( elte
	4 )bble =); e keep		// 
	// Usiousef thk he the--do E8 nocument uax;	}

: {},

	add:uerandler,keep		//  !element ur =,lonl;
		slisandler;
	?.
		var  ? fixHoler, datr,uery( t:			target neath uCoualse */
(ur = tm;
		s[i])nal.clielegateCoun
ey#11764!keep		// Type === 3 | ( cur.nodeion( evebles ) tinen		//(  !eAdispatch  ? 2 : 0 ) ) )+ type;

	 cur = cur.parentNo+ typkeep		// Typ{
				i&& !jQuerye;

	ent.target.ow,: fun( o "input"bsetGt's wEhe (  !eAdispatchch([0331/"  ? 2 : 0bj );
	e;

	 cur = curQuery.eCnild(ma e, null,te
	4 )
chx;
			}teTabble =);5e caPropagation: function(r =,lonlneath uCoualse */
(ur = tm;as fi])nal.clielegateCounnct;
	
		}

	 to hiddnget toming dvhiddpreventing m ) )+ type;

	 3 | ( cur.nodeion( evebles ) tinen		//(  !eAdispatchype, hand	).type =unct;
	
		}

			//// Add thenget unct.length;s
			l?eleCnild non( eveeer ) {
			Cnild(ma e,Ol?eleCnild null,te

		}
		I handler, avler, d,: nsure by na
// i2] jQuehe caspro2336)
		}
		{
						// Suppor+ type;

	opiates Typ{
				iurn jQuery.nodeNaler, dlem, "input"e;

	opiatesr< handlrem;

		e
	4 )
chx;
			}teTabble =);cl)
tPropagationtdif An				el ctmeep		//An				el , "inpudif An				el {
	 hanAn				el {
.charCodee, han:	 hanAn				el ;

	meep		//An				el ,=tmeep		//An				el ,
.charCode hanAn				el {:tmeep		//An				el inalEx;
			}teTa1mapry false;
}( oritaax;
			}.checkecl)
tspatch.cdif An				el ctmeep		//An				el , ( ele)bbet.resut-beet
	remove:he cou oritax;
			}.checke				sery.nodeNt
	remove:he cou oritaaent ur = tm as f0] "even	type: 			0 matccl			urnTr [ cur;) ) )+ typvsrc.retur sel ] === oritachx;
			};
		= 3 | ( cur.nod{edsCont;
		=innerHTML) {] jandlentutsi pass eNa"  t:dsCon	s ) :
					unde	
		}
		{ee add wi	// t) {

	sh			cmouseovObjed, so nnerHTMLn( e evenuC
			ivsrc.returtevent ".ent!t oInnerpt-beedsConhe cou oTynput"(	tion
if ( !jQuept-bSerict and !elt o {
mcypeaeedsConhe cou ou oTynput"(	tion
if ( !jQueleadnt W cor	event !eltleadnt W cor	eveneedsConhe cou o oTynput"!wrapMap[764ttagN			bj econhe cou oj.s[a"eNa"] )[1].toLa haCanpve	el "innput"12	e.rethe cor {] jandlexpt-bTageNa<$1></$2>".elem, aus ) {
					alse /
r ( 	legateCount; nct;
	
		}

	 to hiddnget toming dvhiddpreventing m ) )ont;
		 tm;as fi]vent.typ) )ont+ type;

	 3 | ( cur.nodeion( eveevebles ) tinen		//(  !eAdispatchype, hand	).typeCont;
		=innerHTMLrethe co.typeConj );
				
 )ont;
		 tm0;( event )I have evinnerHTMLrthterendus x		jQtopPru{};

		/all
		// its FOO() alse;
	(e)	inalEvenppor+ type;

.parentNournTr5e ca()Obj.e		(
he cou ;

		e
	4 ntriggerhe coapply( this < handle( e
	glo {] janWithPropagation: functio
		}
		{napsh	D	or ml a inlse{};1domManip sweep	// Ine ingns( ev themetohen wfragm fo
		}e = [],
		var mapry.nodeNf
	remove: fun( oritachx;
			}[pe;

	 		nSi Even,pe;

	 cur = cur.]ntDefa),lonlneath uCouent ) {
E
		/s foratio{] jamp if/ Do/^(?:moe to hiddthe targe
		ecorder"
NournTrdomManip_slice.call, t
	remove: function( endle j.ner.ve evndlerQ matcc cur = f ve evndlerQ;) ) )+ typ cur = parentNoproDlized, sothen napsh	D	 j.neKey== has 	}

d prop81es be (#6170 j.neTypnh.ne cur = cur.	if  cur = parentNo	 j.ner.iery.n		nSi Even2 : 0bj );
	
		varry.ery( Query.ev).typeC cur =	inlertB}
		}:
	funct j.ne ;

		e
	4props ) {
		ecorder"o isi
	},

I;
		ck ntuery.Even/^(?:moe Ot
	 }ctiselecto
ndleObj;ce  ( spallatedTare
wOM3h ca		ecorder"o(e.g.,tuery.he caslice.call)itax;
			}ia?}teTaook.propuery.ev).ty
	glop

				}
		filter:ler, data, selex;
			}teTa1uery.eveler, datr,uselector
	glopomManip	}
		filter:ve e,vepe;
		/apps ) Iouseselse;
( oriSupporFe
	td
		n

ets			ta jQum ) e = [],
			athis.pObj.hand[]ctched.elem, ndlel?ele,dngetcthpsby thearget sy thear, evewfragm foontypi			0 matcl			urnTr [ cur matcst,
				target iNoCl)
tyr l - 1,
ut"12	e.retve evenrget i  use an [],
		var f  use an . he cou ;
SupporWe		//'tocl)
t cur.fragm for by na&& !jQu{
			/o , inlWebKi=
ched DOi  use an [ !el( l <nodepareC
			ivsrc.reventevent "..timeStamp ( !jQuers		/Cl)
ty !elte event.edsConhe cou o ounctionx;
			}teTa15)
	j		trigger;il, ta "input"1207 elf
		st,.eqr;il, ta ; be (#6170i  use an [parentNo	ve event
	he corstDispatch.cil, tr,elefept-b( ? 2 : 0bj );
	elefedomManip_slice,vepe;
		/apps ) Iouseselse;
( ntDefa)opagation evenhich == nfragm fountmeStampbuildFragm fo(alice,v;as f 0Ho	ent.target.ow,:e, ha, !ps ) Iouseselse;
("checkb( ntDef we'rs=.fragm foOl?eleCnild;) ) )+ typfragm foOcnildrget r< handlr.node: functi=ragm fount delegalEvenppor+ typ we'rs: functisy thea[],
		var mapry !eAdispfragm fooh([0331/"  ,s clicksby the  2 : 0bhpsby thea
		sy thear [ cur;) ) )cand {};roperty of th=ragm foupatch holaley==uncf ( eadecon pre we'rscheck he== 	// e		 up ) )candbemp ife cigatr eflect ly inlsertjQu{situaiates (#8070o namesalse */
r ( 	legateCount; ndowdetes (#8070orWe		//mp ife cigatr eflect ly

	opild nullnppor+ typl)
tspatch.cdisby thp				o
ndleObj;ceemp ifeKne ee; iffeoded	or sd	 if 	sy ther ( iny.
		vsleclegatitype;

	 3 ea
		sy theevebles ) tinen		/]ct;
		, evewfrafragm fosby th  ? 2 : 0bj );
	e;			
 )ont;
		 tm0apps ) Itch.cil, trtyphpsby thij );
	elef
pe;

	 3 ea
		sy theevebles )			doc, evewf[r [ cur;) ) )ca"12	arget.ow,:e, ha,bj;ceemp
	 toencelab [ cur;
s ) tinen		/]disp, evewfra	vslec 2 : 0bhpsb;ceemp
	 eAdiu/ Ci couutcelab [ cur;ror ock heh..d trig
		}:
gatitype;			for ( 		ilegatea
		sy thunt; nct;
	
		}
or+ typ, evewf[ry[ i ];
e;

	 3 
		Masent b elem.un.eCn.typeven""t"!wrapMapppp= ( jQu.nodeNarsby th g (  !eAdiput" ) & !jQuerye;

	entgm fonntNo+  )r ( ; tu8 n !elemeCn = sevebles ) tp
	 Hoypeajaxr, d,Y availa...bles ) tp ( jQu.ntohlUrlelemeCn = set;
		=inn			} elsntion) tp ( jQu.g (  !eAdisp.un.eCn.ntNp/^(n.eCn.ntNCe.g.,tu/^(n.eCnLrthterendven""t"dlexpt-bTagthe .n/^\s*dsCon	set;
		=inn	;
	e;			
 )ont;

	elef
pe;

		// F#11809:	// Avol oractlng m )gm fount delegalEvenp  ] = null;
		;
			}teTabble =);cl)
	Ieplyent// Suppor+ t8
E
		/;
nt.delblinaB99/#requs fora wrapM
}d trigSa	e;
nt.delspatch.ca .ne ;
(e.g.,tueveblcheckeurn jQuery.nodeNamfram, "naB99"t"!wrapMrn jQuery.nodeNam(e.g.,tcur.nod{edsCont;

(e.g.,tu:m(e.g.,tclder( e, nul"trl;
			
nnerHTMh.c"div")(sByT econh("wrapM")n	typell;
erHTMild(ma e, null,teget.ow,:e, ha,et && y"div")( (wrapM")n	s ) :l,te
	}
};
"Rexpt-b/	vslec 'rsch.type

eributname 		Masentuery.Even		fm fose{};	e;
nt.delsp
}d trigSay the  2 : 0bion( endle jl,tegnt.type(			. handler

eramfram, "nt.t"8 ( e			u
	gl+ "/
+ "),tegnt.t;
;
		= 3 | ( se;
}d trigSa	vslec 2 : 0bion( endle jile ( .ty	vou		Masent buc^ {
e cou ol,tegnt.tyet;
			if ( maseveblel,tegnt.type ( ma[1ength;	} elsnti			Cnild(maA
eributn("nt.t"x;
			;
		= 3 | ( se;



	// Ma [ cur;r	echavissin/ Preveve beeAdiu/ Cd
}
i EvenanEhe (  !eAdisp
	remove; "div")(sndle jile lneath uouent )
(ur = tm;
		s[i])nal.clielegateCoun
ey#1176 = ( jQu.nodeNars forpog (  !eAdip,f (  "div")(snmp ( !jQuenodeNar(  "div")(styphp g (  !eAdiput"ouseout;
}
i Evena sd	 Copyry.Event( srndlvent ) {
		if (s cu!.nodtypn curnArr:Path...ea
eAdisp = sev
			}teTa1ue;
			}. e funFn &i, lth uoldDector ( !jQuenodeNar = se
[ 2eurDector ( !jQuenodeNar (s , oldDectoe
[ 2emeep		//oldDectery.evs	dafeFrageinpudif An			e	d;_}eurDective Nod;[ 2eurDect.emeep		//{}e */
(ur = tor, mapeinpudif An		;			for ( 		, l ame( etoyp.type ) ) )cangateCount; ndowdetes			jQ			ry.nodeNio (s , n( type( etoyp.type [ry[ 
	4 )
chx;
		);
	}

	m/s foratisd	 ifpublicelemennt objecble con/^(?:moeh=ragm f
				if ( Dect.lement ur = ( Dect.lemen e = jQuery.exte: 		f ( Dect.lementuseout;
}
i EvenafixC.fragm fIssuctlet( srndlvent )	jQues
		vabb, Q	funct;ent doto cument n// onehcum		t ev th			fkven"div")(s {
		if (s cu!.nodtypn curn
			}teTa1ue;
			}.emalue + =f (s cu!.nconheanpve	el "inn;ent do/'toleropertieinpudibou)cavia	++retury.Evee054,nerHTMr.fragm f. {
		if ( !jQuegateTyppny

	opry.Eveoc &(s his[ jQuery.expandof An				elor ( !jQuenodeNar (s hpsb;ce			for, mapdect.emeep		:
								jQueem.removeEvio (s , Q	funct.e, handle );
	
;

		// Evelemen		vare; iffeoddecon pre we'roperdget if try.expan		varroperdgtoon			estnild(maA
eributn(is[ jQuery.expanx;
			}.ng eveblanksm(e.g.,tsee054,r.frrHTM, evewfrahidderided	oreAdiu/ Cder"ly-se sery.
 n !elemeCrne event  ? 2 : 0oc &(s n.ntNpis !=& srtactorse||y the  2 : 0bio (s hp.		var e=& srtac;	}teTslec 2 : 0bio (s hpsb;c do/'to10 imto properr.frasm(st
	rem we'nt objetuery.EvenerHTMr.assid.;c do/'10 us x		jNoModify#11ven	ecoredEe errnt irentNoon icoapp#12132.
				}!fpPropaemeCrne event : funct;
	ntio
		if (s cur.parentNo+ typke (s coutnhe co.ty=& soutnhe coe );
	
;

		ox ncpaca"ild(arvenn VML-celab			fIE9. W054,r.frrHTMp )nt objec

		the targm807e9e'rs toutnhe co.stcleegy ion()ton is nsuffy#.clione.
		It if t = sd prLrthterendhiddeiled) elb/ Radincy, is nial fwle coif t = nLrthterendis onto t (s cL) {] jandp#10324tio
		if( !jQuept-bSerict a5

	opilphet = nLrthterendet = ( jQu.erim( (s cL) {] janionx;
			}t (s cL) {] jan.ty=& sL) {] jane );
	
;			}!fpPropaemeCrne event ,.timeSet 	e;
_r/	// a) {

			bucusMoext.tess& src.type;
			} do/'tolefcaptonehaerconsforatio checked stao hitisd	 if|value)$		} do		fs caosnames
. Wor) Io/'to7efcaponehgndleoratisd	 ifthe tar		} doatio checkild(araquenc bailed)ion
iCo check ouncti, rs alsoctisen			estnd)ion
iCo check=f (s cbuce events& sbuce evWe		//'t/'to7eniph(e.f;
		out an)candctiselblinile ouncto hitisd	 iial fwl type ent dele ( buttnt teee same timeSecon pre we' = "tio
		if (s centevent "s& sritaaent ur = (s centeve "s& sritaae );
	
; do/'tolefcaptoneheTabble =ler,/	//basewrapMa onto t (t""];
r,/	//ba
; doed stat054,r.frrHTM< handl
				}!fpPropaemeCrne event :pfunct;
	ntio	estnd)ion
iS,/	//bas=f (s cs,/	//bas=f ( src.defaS,/	//ba;	
; do/'tolefcaptonehse set trc.defaurnVal onto the correct vaat054vent=n.frrHTM<M3h elfn] een l.tim >"|| d
;			}!fpPropaemeCrne event ,.timeS/^(n.eCrne event rtac1eNat;
	ntio	estnd)ion
iVnteve "s& sd)ion
iVntevuseout;
ks
jQue cur =enild(maTo: "ild(ma", 
			trigTo: "			trig", 

		}:
	funct:n doc= {", 

		}:
Atrigge"	trigtsi pexpt-bremov"ithPropagat"ut"
},tachEvfnuery.Eh=ragm fo	}
		n {
				elemuseout"
},uavol,:la, seleent ) {/r.
	
	remo0 matcl			urnType ]e e{
	te
		}:
rry.contain( rget ter/r.
	ncf (=g
		}:
) ) )ca"12	e */
r ( 	legate=uncf unt; ndowdeteandler;
ieventncf (k.propuery.ev)tch.cdble =;							jQu(g
		}:
input[Eh=ragm fo]sp
	remhpsb;cee

	/.eCblehe browoulmap]ctchuery.Evecollcheckb;r	ec e = [ion, boldevech.nehitserigi;cees.pOb || []ctchedar r handlrerigidle );
	
;
eTa1ndleStypkerturthis, ret;
		andleObj}
i Evenafragm fo Ot
	 }Ol?egndle jile lneanull,tcth uouent,*/
r u)cai handleO Ot
	 }Mh.c"div")(sByT econh?:mofor core_strundefin?O Ot
	 }Mh.c"div")(sByT econh(l?egnven"*on	s ) :
handleO Ot
	 }Ms
		f(patch.cgm ?:mofor core_strundefin?O Ot
	 }Ms
		f(patch.cgm (l?egnven"*on	s ) :
			unde	
		 {
		if r u)cadowdetr ( 	lr u)cai 	cnildrgathis.t
	 }Mt this, p"m	if r ( ; cu;
		s[i])nal.clielegateCoun
ey#1176 ={
		if ?egnvenrn jQuery.nodeNamfram, ?egndl=ragm fou u)cw || wil,te
	4 )
ch		} elsntioninen		/]ct;
		u u)c,patchype, hand	?egndl=4 )
chx;
		);
	}eTa1ndle?!cu] ===erDteC			ife?!c	iurn jQuery.nodeNal Ot
	 }Ol?egndl?
:
e( !yE[]ct;
			e Ot
	 }c) )b u)cado:*/
r u)cse;



	Usdiv0thgm fo(alice,vriSupesbailed)ion
iCo checkN			retu
}
i EvenafixD)ion
iCo checion( endle j			if (;
_r/	// a) {

			bucusMoext.tesl,tegnt.tyeseveblel,tegd)ion
iCo check=fl,tegbuce evWeeout;
ks
jQue 	t		neet
pagationtdif An		 hand			el ctmeep		//An				el , "inpudif An		ile 	est"div")(shpsby thpagat &i, s& "div")(sh
	te
	Pag typl)
tspatye;

	ent.target.ow,: fun( o "inpute E8 n !el( !jQuept-bSerict a5

	opivenrn jQueisXML,: ;
		s) {
mcypeaeedsConhe cou o"<
+ "),tegn.eCrne e+ ">put"e;

	opc - 1,
ul,tegb.fragm f(o
ndleObj;ce  (IE<=8incy, is  to properr.fra	// detebKiunknr donget toming d

ch		} elsntioDi	 fo
afeFcL) {] jan.ty.targeutnhe coe );oDi	 fo
afeFcild(ma e,Ol?ec - 1,
uDi	 fo
afeFcld null,te

		}
enhich == ( ( !jQuegateTyppny

	opry.EveArr:Path...gateTyppny

	opCo chec"(	tion
if| ( cur.nodeion( evecorder" ur.noddeparentNrget = ( jQu.isXML,: ;
		s)  )r ( ;  doto esetewn IE8)
 3h ca =s*cear		raqueneNaskb;:
// httpjscearatym/atcall-vs-sIE8)
/2ur = (s "div")(sn=afragm fo lpe = fix;
s& "div")(sn=afragm fo"inpute E8 

		// F	varr/ I.frrHTMissuctn		;			for ( 		cu;or+ typ,& "div")(sclielegateCoun++t;s ) {
	

		/ na
// i2] eiled) elb/ Radior+ ton is nteCounFupesb#9587
pe;

	 3  (s "div")(sinput"lse /
r ixC.fragm fIssuctlesby th (s "div")(sinput);
	elefedo		;
			}t	// e coif tad eRadios aof th=ragm fo onto thlve on		data = d , "inpudif An		

	 3  (				el , "inpudif An		;
s& "div")(sn=as& "div")(sncorfragm fo"inpute 	r = (s "div")(sn=a (s "div")(sncorfragm fo lpe = fi
ype;			for ( 		il;or+ typ,& "div")(sclielegateCount; nct;
	
		} sd	 Copyry.Evensby th (s "div")(sinput);
	elefedo			} elsntion sd	 Copyry.Even.ne ;
(lpe = fix;
		;
			}t	//Prerowve 		MasentAdiu/ RadiStytm )gm  (s "div")(sn=afragm fo lpe th  ? 2 : 0b;
;

	 3  (s "div")(st.ty: funct"b{
		renEhe (  !eAdisp	est"div")(shp!
	Pag tet atchch([0331/"  ? 2 : 0bj );
	}
gm  (s "div")(sn=as& "div")(sn=aor+ typ = nul
mp
	 toabble =le sd	 if e		}.checked sd	 pomManipgm fo(alice,viontdif An		 hanmoeparentN,M, evewfra( rgetntNo	ve evile jiselectotye;

	e !esermpOl?eg, wrapM,.tde 	urnTr [ handlratcst,
	

	

		/ na
//afm fos
		}e = [],
m fosSafeFragm fo(aing up tCo:dsCony
	

	
ing dv]e e{
	te
ualse */
(ur = tmateCount; ndowdete
		s[i])nal.cry[ i n		

	 3 
		s[corder""input"b{
	 {
	

		Addming dvdinlsert
pe;

	 3  ( jQu.eddeion( endlnt ==: funct;
	ntion:
e( !yE[]ct;
		ing d,rder" ur.noddep ].spli		[ ev"inpute E8 
t	// env}:
rkven<(?:3is onasery.	ing 
=inn			} el			if (Conhe cou oeinput"bsetGt's ing dath.push.t
	 }Mtnrgete:he cou oeinput"be E8 
t	// env}:
r<(?:3is one{};t.length;n			} elsntion)rmpai hmpaor t foMild(ma e, nulh.t
	 }Mtnrget"div")( ( 
wrapMap.	8 
t	//Dendclic, 30aoed ndardp ifreroe;

gatitype;e?!cu			bj econhe cou oeinput"a"] )[1].toLa haCanpve	el "innt;
		=itde ap.tde );
[l?egnp) )otde );
			tion
iap.	8 
thmpcL) {] jan.tytde  ha+ "),teglexpt-bTageNa<$1></$2>".elem, aus+ "tde  2]ap.	8 
t	//Denme(  us xughtr candrso onto t=raht
NournTrdomn:
e.tytde  0 i ];
e;s
			l?ej--sevebles ) rmpai hmp.ncf ) )+ ty	
	elef
pe;

E
		/n
ps
}) for cor	ev;r ! !eltleaild(maft irt: IE ={
		if ( !jQueleadnt W cor	event !eltlea.mat cor	eveneedsConhe cou oeinput"bsetGt's  ing dath.push.t
	 }Mtnrgete:he cou ot cor	eveneedsConhe cou oeinputn	ty	set;
		=ief
pe;

E
	to hiddIE'ehiuto
		}:
afttr>"eNadios aocelab	 key#11764)
	{
		if ( !jQueleadnt WwrapMa )r ( ; tu8ent/timeSe		eca temen><, *may* closdspurven"ttr>"eNa( ; tu8as fi]ve?!cu] ="naB99"tnnerpr>"eNe cou oeinput"
		=inn
thmpcld null,te
13208)
	u8ent/timeSe		eca ba
//<rapMa>o		f<wrapMa( ; tu8	tde  ha+u] ="eNa</reatnnerpr>"eNe cou oeinput"
		=inn
t rmpa:		=inn
t t )I hav:
e.tyeinpu 3 | ( ct r< handlr.node:t;
		=ins
			l?ej--sevebles ) 				if ( jQuery.nodeNal(wrapMap.| ( ct r< handl[j]), "nrapM"ut" ) !r>"eNet r< handlr.node: evebles ) tp			Cnild(ma e, nulwrapMa t;
		=inn	;
	e;			
 )ont;
tion:
e( !yE[]ct;
		ing d,rhmpct this, p"mous
pe;

E
	// F#12392a =s*hed DOout ar/ > 9.	8 
thmpc.ntNCe.g.,tu =""us
pe;

E
	// F#12392a =s*oldev ];
e;s
			l?ehmpcld null,te
evebles ) rmpnild(ma e, nulwmpcld null,te
et;
		=ief
pe;

E
	to pal t'rsch.op-lad lotye;

	cur =s*co pro// ch ndbemp  rmpai t foMncf ) )+ ty	
	eefedo		;
			}t	//// F#11356: C chrntuery.Even/^(?
		}e = [],			ivsmpaafeFrag d tnild(ma e, nulwmpdle );
	
;

		Rese sd)ion
iCo checkft-b5 (Nt delsios a/ type eength doabeuto onle pld(ma/ onehinlse{};1dor/ 6/7 name66170 
		if ( !jQueleadnt Wild(ma e check:
								jQue		ck nfragm fosby slem,.timeSt,afixD)ion
iCo chec

		}
enhich	e
	4 )
s
			l?e;
		s[i]sby s) ) )+ )  )r ( ;  do#4087 -	It h=ragmios ad) elb/ Radituery.Eveac 'rschsery.Ehiddeiler, ( ;  do i2] tuery.E, cument uam		t ev tn		

	 3 ( rgetntNo	iurn jQueratch.cturnnts ( rgetntNo	v:mof-ti=ragm fotye;inument;
	
		}
for manfoypl)
tspatye;

	ent.target.ow,: fun( o "inpute E8 

		Ald(maoneh
		}e = [],
rmpai fragm fot foMild(ma e, nul"inputth  ? 2 : 0b;
E8 

		Prerowve 		MasentAdiu/ RadiStytm )gm 				if or manfof An		;
sEhe (  !eAdispwmpdle );		{ee add Cse caCi couutcelaype;

	 3 s	sy theevebles j	e
	4 )
c
s
			l?e;
		s[i]wmp[ j )+ )  )r s ) 				if
		Masent b elem.ul,tegnt.tyven""t"!evebles )  [ cur;) || wil,te
	4 )
crue )etthis, e	}
enhicrmpai  = nul
mpafeFrag		
	;l)
tPropa  !eAdiiontdif An		 hanmoe/*thk he the*doacru{}lement ur =,lonl;
		funFn &id	functi
	te
ualsh
	te
	 he thKeyn e = jQuery.expaunt,d 		ee ?
l)
tspat		eeunt,d	e	d;_Ey.expan=l( !jQuept-bSeri	e	d;_Ey.expa
				tion(oon e = jQuery.evenion(ooe */
(ur = tm;
		s[i])nal.clielegateCoun
ey#11764!keep		/acru{}lemenvenrn jQueacru{}leme oeinput"bset
pe;

ck=fl,te[ 
	 he thKeyn i ];
e		elor i+ ]) t		ee[ i+ ]ap.	8 
	data = da )r s ) 				ifdect.emeep		:
						/
(ur = tor, mapdect.emeep		:
						/


	 3 sion(ooks.type = lsntion) tp ( jQu.ry.eve.nodeNiol;
		funFneObj;ceemp 

		ox nc, d,: seovObje ona/ Avo ( jQu.ry.eve.nodeN'ehdeNrapMa;
		=inn			} elsntion) tp ( jQu.em.removeEviol;
		funFn &unct.e, handle );	=inn	;
	e;			
 )ont;
tion:
E
	to hidd 		ee  E8 as 	}

		ecortin/ Preveild(maft ir ( jQu.ry.eve.nodeN s ) 				ift		ee[ i+ ]a )r ( ; tu8	e	d;_}e		ee[ i+ ]ap.	8 
ming evency,cortin/corduso on	e	d;_}ry.expanN			retidedn/^(?sby sl.	8 
ming nur ncy,c}

d / Ad ild(maA
eributn
}( oritaataanerDocumesby s;.	8 
ming we m nnee, hand	varwe'rscseomMan;
		 tm;
	 3  (	d;_Ey.expan lsntion) t	e	d;_}r,te[ 
	 he thKeyn i ;
	e;					} el			ifr = tventevnild(maA
eributn?:mofor core_strundefin lsntion) tntevnild(maA
eributn( 
	 he thKeyn)i ;
	e;					} elsntion) tntev[ 
	 he thKeyn   ] = null;
ont;
tion:
es.pOb	e	d;_dId;) || wiid
	4 )
crue )etthis, e	}
en)
tProntohlUrliontdif An		urx;
			}.checkepitQu.noajax(sntiourliourl !eser = : "GET"unt,d	nctT = : " ? 2 : /r.
		sync:!ps ) Ir.
	g (  !:!ps ) Ir.
	"us x		"le );
		resut-bdleObnbj = jQuer	t		neet
tde remove: fun( or<(?:3
	ntio
		if  use an . he cou ;<(?:3
	;
			}teTa15)
	j		trigger;il, ta idowdetes			jQ	handl).tde rem ;<(?:tch.ci, tr,eldl=4 )
chon evenurnTr< handln	ty	s{
p 

		ox ntuery.Eve ontde arsch.maniphar u)c
p 
,lontde ap.			jQu(g<(?:,;ent.target.ownerDocume) ta 0))tch.cdble =;	4!keep		/ cur = cur.pa?}teTa1 wdetestde }
		}:
	funct jandln	ty	e );		{ee atde }]disr: functi= [];
		 tm as f0] "evei ;
	e;s
			l?eleCnild non( eve 3 | ( cld non( evcur.nodeion( eveevebles )
		s[i])nalild;) ) )+ ty
ont;
tion:
		= 3 | ( se)
cho
he cou ;ele)bble = 		}teTabble =);cl)
tProtde beedsove: fun( or<(?:3
	ntio
		if  use an . he cou ;<(?:3
	;
			}teTa15)
	j		trigger;il, ta idowdetes			jQ	handl).tde beeds ;<(?:tch.ci, tr,eldl=4 )
chon evenurneTa15)
	j		trigger: functs ) {
		
		st,.eqr;.ery( Query.ev,gm fotye;")(sn=asaniptye;")(s(=;	4!keep		/tye;")(sr.node: evebles tye;")(srtde rem ;<(?:n)i ;
	e			} elsntionsaniphe cou ;<(?:n)i s, e	}
e)cl)
tProtde ove: fun( or<(?:3
	ntioeplype[],
		var f  use an . he cou ;<(?:n)i ;
	eTa15)
	j		trigger;il, ta idowdete.ery( Query.ev)tde rem ;pe[],
		var?;<(?:tch.ci, tr,eldl:;<(?:n)i s,e)cl)
tPrountde ove: fun( o
			}teTa1uery.eveur.pa?()trigger: functs ) {
		
		if ( !jQuery.nodeNal, tr,e"rapM"ut"dowdetes			jQ	huery.ev).thPropagatcur = ct this, p"mouse, e	}
e).cou sut-bdleObeplypamlon,patcS 		/s	f ( CSSsi palphlor /alphl\([^)]*\0331/

opacrn fr /opacrn \s*vent([^)]*nenby econ prevtype .op|=raht|bottom|left)ur =s doewhe celab
		ehe caston isn th=,  of sge
		eccelabpPru{}="naB99", "naB99-celip,fh=,"naB99-c
wrapM"=s doee
 3h ca =s*ehe castct va;:
// hs://dad l		re.mozilla.org/en-US/docs/CSS/ehe casby ehe caspwe ap.pe isn |naB99(?!-c[ea]).ement;
mmanievtypemmaniennerptum|"( r ?
			"<(?:p(  "^r
+ "s.pOb tums/>]"ttin$sprleaev,gmptumisnpx ?
			"<(?:p(  "^r
+ "s.pOb tums/>]"t?!px)[a-z%]+$sprleaev,gmprelNum ?
			"<(?:p(  "^r[+-])=r
+ "s.pOb tums/>]"sprleaev,gm| ( ehe cast= { BODY:n dlock" 
tPropssShord= { econ prege"	bsolutnsprvisibi;rn ge"hidden",*ehe cas:n dlock" 
tPopssN		ralTransr		r iatePr	d; heSp Do/^:nt,*/
r ntWeraht: 400l)
tPropssEy.expv]e  "TopsprlRrahtsprlBottomsprlLeftd,
[ 3pssPreSupesb]e  "WebkitsprlOsprlMozsprlms"n i ; doeTa1uera psskN			retu mcandiv onaspo;")(ips
})y.ed=s*coeSupeckN			retu
}
i Evenay.ed=sP			odeNal, 		//pnction({	
; do seovObje			fk)[\\s i2] ac 'ortiy.ed=s*coeSupec
 n !electioiate 		/;
			}.checkepecti;
			}.ng mbounh			fy.ed=s*coeSupeckk)[\\ jile c
wue + =fandl- s rAt 0))toUandrl "innp+handl-5a, ev1v,gm h=raue + =fandlth uouenpssPreSupes) ) )cand {s
			l?ei--seveblene + =fpssPreSupes[ry[ 
+ c
wue +;
;

	 3 ectioiate 		/;
			}..checkepecti;
	
		);
	}eTa1ndlh=raue +;ut;
}
i EvenaisHiddenaxpr
)u? :3
	ntial tsHidden mraht
be	//  (ddn/^(?			jQ	#nt obta}
i Even;tial tn !jQu{
a) Ionget tomwill
be	setyedll)itax;

)
		s[i])n[corder";blcheckeurn jQuecss([0331/" ehe cas"ndlnt ==isn "eArr:Path...tye;

	ent.target.ow,: fun( o "inpute t;
}
i Evena sewHide n, t
	remov sewndle jile ehe casiselectohidden,
etve evdv]e e{
	t be (#alsh
	tem;

		e
, t
	rem) ) )cand {(ur = tmabe (#ateCo)cangabe (; ndowdet
		s[i])nal etoypabe (#DOefunctioon( e.e 		/;
			}..tye;inument;}

etve evdypabe (#Dor ( !jQuenodeNar0331/" oldehe cas"ndent;ehe cast= n( e.e 		/.ehe casOefunctio sewndle j;

		Rese svocidss eN*ehe casto, avlernget tom on chrnas 	}

, ( ;  do cigathiddent ir
a)caa/ oru99/#		fkvt{
		
		if ve evdypabe (#Dooc &he cast=t ==isn "edowdetesn( e.e 		/.ehe casu =""usont;
tiondd wijetuery.Eves
	ch
d / Ave bedeNrriddente
		eehe cas:nnve on	ial tn ate 		/sheeom onwjQuntDento t (t""];
he browte 		/;, ( ;  don		fmuch
iddthe in {
		
		ifn( e.e 		/.ehe casu t ==atnneisHiddenaxpr
)ut"dowdetesve evdypabe (#Dor ( !jQuenodeNar0331/" oldehe cas",fpss		tion
iDhe casf| ( cur.nue +dl=4 )
chx;
			} elsn{
		
		if ve evdypabe (#Dodowdeteshiddent=eisHiddenaxpr
)utap.	8 
	data he casuoc &he cast!t ==isn "eArr:hiddent
	ntion:
e( !yE[nodeNar0331/" oldehe cas",fhiddent? &he cast:urn jQuecss([0331/" ehe cas"ndlt);
	elefedo		;
					}.ng Se set trhe casto, most we'rschtuery.Evetn ateetyedlloopookeveona/ Avo:moe Oted n scaflow {(ur =  be (#alstmabe (#ateCo)cangabe (; ndowdet
		s[i])nal etoypabe (#DOefunctioon( e.e 		/;
			}..tye;inument;}
functioo sewncorder" e 		/.ehe casu t ==isn "eArrn( e.e 		/.ehe casu t ==atdowdete
		s.e 		/.ehe casu = sewn? ve evdypabe (#Doven""t:==isn ";
	
		);
	}eTa1ndl)nal eto				cks
jQueQuer	t		neet
css:
},tachEvfnuery.Eritax;
			}.checke				sery.nodeNt
	remove:he cou o0331/"uery.Eritax;
			}.olem[ren,te 		/s,gm fomaopiat			0 matccl	;	4!keep		/  use an tch.ctunction(ck(/r.tue 		/sai fraS 		/swil,te
	4 )
cr( !es
andl- ) )cand {};r(ur = tmateCoCount; i+ even{
	m;
[landl[ry[ 
Dor ( !jQuecss([0331/"andl[ry[  !ps ) Ioe 		/sa );
	elef
pe;
		.app( epusont;
tionsrc.retur sel!] ===edsCony.inAr.t		n(Quee 		/ o0331/"uery.Eritax;
	inAr:
			jQuecss([0331/"andltriggerhe ery.Eritaxhis < handle( e
	gl>x;
			eFragmsewove: fun( o
			}teTa1uer sewHide n( !es[i
	glopomManshidgger: funcx;
			}teTa1dom sewHide n( !elopomManstoggl	add:uerandlerd sta
	ntio
		ifhandleObd sta t ==booa  !nx;
			}.checkedbd standler;
	sew(rget nea.hidg(on evenurneTa15)
	j		trigger: functs ) {
		use an Hiddenax"input"benTrue(			jQ	huery.ev)	sew(r;;
	e			} elsntion			jQ	huery.ev)hidg(on ev e	}
e)cl)
dleObj = jQueryit(" "),
		Addmiate 		/;N			retu hookven		fdeNrridlblinile	tion
i
  do chavi		fdf fratrHTMp dctiselbliate 		/;N			retut
cssHookv:lsntiopacrn :lsnti	fraiontdif An		 hand	computfin lsntionep		/tymputfin lsntion  doto 	seuldllipaingnipha tuml t's FOOn/^(?opacrn ntion r.
		var m ( CSSar0331/" opacrn "
	4 )
cruopagatgivar t ==at? "1"opam =);
	elefedo		;
				
	}

		/otheniutoma	remo
}) for"px"onehinlsteecont
	y-unitpagatN			retidePopssNuml t:lsnti"columnCount"le );
		0 "nt lOpacrn "le );
		0 "n ntWeraht"le );
		0 "s eNHeraht"le );
		0 "opacrn "le );
		0 "w; cu"le );
		0 "w;phans"le );
		0 "widx		"le );
		0 "zIbe ("le );
		0 "zoomsle );
			
	}

		AddmiatN			retidedwhd	oak)[\\syoute
shoneh
ix doc= {=s doeeselbli		fgiselblinile ounc 3pssPropv:lsnting nurmic, 30floQu{
sskN			retu	0 "nloQu"f ( !jQuept-bSeri
ssFloQu{? "
ssFloQu"t:==e 		/FloQu"			
	}

		GetMp dctis'rschs 		/;N			retu on ate{};Nng 
=s 		/iontdif An		 hand	 ery.Eritaxhiryirda )r s 
		/othentis'e 		/sapMa ry.	os a/omt toming d

cunction( encorder" ur.noddeparen3ncorder" ur.noddeparen8eArr:n( e.e 		/;
			}..eTa1ue;
	;
	
;

			/s fna
// i2] we' ca	orractle
		ecord=raht
 ery
n r.
		va	funFn &hookv		0 mh=raue + =fl)
tspat	mell "in"andltr
				t 		/;= n( e.e 		/nd {}ne + =fl)
tspatssPropv[lh=raue +#Doven(fl)
tspatssPropv[lh=raue +#Do=ay.ed=sP			odeNal, 		//ph=raue +#apMap.	8
				varhookolaley==ucoeSupecktDefgatity don	ecoredt iry==uuncoeSupecktDefgatityhookve=fl)
tspatssHookvlemuseoutvenrn jQuetssHookvleh=raue +#Dap.	8
		Co ch// t) ' catiselbliat ounc 3rc.retur sel!] ===edsCony.
			}..nt.typesrc.reventev;
E8 

		cenv}:
rrely#117 tuml t' timeSs (+=i		f-=)oneheTly#117 tuml ts. #7345{
		use atddeparen.ent!t oInne(r.r	vourelNume cou oj.s[a"et"dowdetesve evcu			bet ha+ "veev*	bet 2a+ "pars/FloQu( ( !jQuecss([0331/"andlndlt);
	el	//// /sabug #9237
pe;
nt.type"tuml t"usont;
tiondd 	/s fna
// i2] NaNa falsanAnve evdvr.pahentis. wi	: #7116{
		use aurteventlsanAn	ivsrc.u t ==iuml t"tnneisNaN o ounctionx{
pe;
		.appusont;
tiondd Ifha tuml t'		ecpassdiv0t,) for'px'onehinls(pPru{}=lalesituaiatCSStN			retide){
		use atddeparen.iuml t"tnne!( !jQuecssNuml t[lh=raue +#Dodowdetesve evc+=i"px"usont;
tiondd Fupesb#8908,e		 up )bo cune mor the corr
}) irsion(frHTM,d; hevetn tssHookv,( ;  do u] jQuweuldlmeano on	esCon eraht (lalentDeytN		b331a	re;N			retu)ids 
	removalityndo64! har the( !jQuept-bSeri
 chrC.fraS 		/tnneurtevent "."tnneandl-abe (Of("s FOgr u)c")"input"b{
	r.tue 		/lemuseout"
"inherit"usont;
tiondd Ifha hooko		ecprooentd		/all
	atEritaxhi<M3h e
seso nnetis'rschsion(freck ounc4! har thehookve<node"tis"etn hookvt"a"](ve evcu	hookv.s.ca .ne ;
ritaxhiryirda )l!] ===edsCony.
			;
	el	//Wrcandiv onpreventiIEdios aofrowigatre ersee054,'inritid'nve evdvr.pcprooentd;
	el	//// /sabug #5509.	8 
			alse /
re 		/lemuseout"
peConj );
	e)	inalEvenppor+ type;			} elsntiodd Ifha hooko		ecprooentdgniphcordeon-tymputfinve evcios aof rc4! har thhookvenne"gis"etn hookvInne(r.r	vohookv.h.ca .ne ;
ps ) Ioryirda )l!] ===edsCony.
			
cruopagatgivausont;
tiondd OM3h e
seso nneniphcordve evcios aof hs 		/;nt objec
.checkedbd		/lemuseou;
	
		);tPropssiontdif An		 hand	 ery.EryirdIoe 		/sa 	ntioeplyium;
rit &hookv		0 mh=raue + =fl)
tspat	mell "in"andltr;	
;

			/s fna
// i2] we' ca	orractle
		ecord=raht
 ery
n ne + =fl)
tspatssPropv[lh=raue +#Doven(fl)
tspatssPropv[lh=raue +#Do=ay.ed=sP			odeNaln( e.e 		//ph=raue +#apMap.	8
				varhookolaley==ucoeSupecktDefgatity don	ecoredt iry==uuncoeSupecktDefgatityhookve=fl)
tspatssHookvlemuseoutvenrn jQuetssHookvleh=raue +#Dap.	8
		Ifha hooko		ecprooentdgniphcordtymputfinve evcios aof rc4! ar thhookvenne"gis"etn hookvI
			}.olel	vohookv.h.ca .ne ;
p				oryirda ;
	;
	
;

		OM3h e
se,// tao		yonehgiphcordtymputfinve evcexisemov/all
	at 3rc.retur l ] === oritachx;
			}lel	vo ( CSSar0331/" ery.Ee 		/sa );
	
	
;

	cenv}:
r"nurmic"onehtymputfinve ev 3rc.retur l ] ="nurmic"onneandletn tssN		ralTransr		r x;
			}lel	vo ssN		ralTransr		rlemuseou;
	
		
mp
	 toabbl,	cenv}:
lblino tuml t'c.rfspaldpt-b5 r )(dexOf(		ecprooentdg fallel	lookvItumeric 3rc.retryirdant "."tcordyirda )r s 	num ?
pars/FloQu( lel	t);
	eeTa1ndl)yirdant "i
	glvenrn jQueisNumeric(Itumut"
Itumuven0t:=valent;}
fusrc.retur cl)
dleObj
	 NOTE: we'()to
		ck vo:moe"wied=w"etn wied=w.h.cCymputfiS 		/
 do c 	// ejsd^(?odior+ .jsmwill
b? orle
		ou] jQ.
c.retwied=w.h.cCymputfiS 		/a )r sfraS 		/st"
},uavol,:lpr
)ut"		}teTa1domwied=w.h.cCymputfiS 		/ar0331/" anAn;
		and
	 ( CSSt"
},uavol,:lpr
)/" ery.E_tymputfin lsnti,lontidth, minWidth, maxWidth,
}..tymputfin=E_tymputfincorfraS 		/swil,te
	
	

	

		fraP			retuVouncti,  E8 ach.neckft-becss('nt obt')gm807e9e'ee
 #12537
pe;	var m ymputfin?m ymputfi.fraP			retuVounctunction(	if rmputfilemuseout:=== oritac
				t 		/;= n( e.e 		/nd {}ep		/tymputfin lsn4! har thivar t ==atnne!( !jQuecye;

	ent.target.ow,: fun( o "input"bsetGt's	var m		n(Quee 		/ o0331/"uerydle );		{ee add A eributn?nehinls"awegns( h FOO irDeanoEdwards"ee add Cfros( < 17g falSafari 5.0v/als "tymputfinve ev"econ pre we' ;
		ove ev"eft-bmmanie-=rahtee add Safari 5.1.7 (2]  chst)oeTa1ues*ceacoe;
gca =s*a lmaniretis'reventev[ion, btidth'ee
mso onle reliab8 apupel ( ;  do i nc, d,g

	ephcordCSSOM drafthsion:
// httpdev.w3.org/csswg/cssom/#regnlved-entev[4! har thitumisnpx elem.u ret;a.matmmanie elem.unction(ck(/;
	el	//to pal t'rschh=ragm foentev[4! h	tidth'=Ee 		/.tidthj );
	minWidth'=Ee 		/.minWidthj );
	maxWidth'=Ee 		/.maxWidthe E8 
t	//Put tn !jrder"
ve evdvnehgiphadtymputfinve evcou]	r.tue 		/.minWidth'=Ee 		/.maxWidth'=Ee 		/.tidth'=Em =);
	el	var m ymputfi.tidthj ;
	el	//tov}:
roratio{] jdoentev[4! h	e 		/.tidth'=Etidthj );
	e 		/.minWidth'=EminWidthj );
	e 		/.maxWidth'=EmaxWidthe edo		;
		
ruopagatgivausoandl		} el			if d trigEe d trigE"div")(. ( .pa?S 		/a )r sfraS 		/st"
},uavol,:lpr
)ut"		}teTa1dom| ( ct( .pa?S 		/
		and
	 ( CSSt"
},uavol,:lpr
)/" ery.E_tymputfin lsnti,lonleft, rmovesLeft,
}..tymputfin=E_tymputfincorfraS 		/swil,te
	
	pe;	var m ymputfin?m ymputfilemuseout:=== oritac
				t 		/;= n( e.e 		/nd {}dd A/ Avotiselblireom one same timeSef rc4!  doeo we dothen (t""];
eonauto
 har thivar t" anAn.mas 		/tnnee 		/lemuseout
			}..eTa'=Ee 		/lemuseou;
	
		
mp
	 Fos aof hawegns( h FOO irDeanoEdwards
mp
	 // httperik.eae.net/archives/2007/07/27/18.54.15/#/omt to-102291p.	8
		Ifhwe' caent uealactle
		ed ilgulmaapupel tuml t
;  do u] a tuml t' i2] h	eca weir an)c
	 cuwe n// onehcenv}:
ri;
eonpupel ( ; do u] is  tcon prev
ssk

eributnfrah\s id	oar.pcprobSerpre fo onto tirentNonget tomcon pre( ; do falwcl)
t cumchsuc 'rschirentNooon pre == 	// e		 mraht
erignirean.en FOactld	ecs"tN		b331
 har thitumisnpx elem.u ret;a.ma! econ pre elem.unction(ck(/;
	e	//to pal t'rschh=ragm foentev[4! hleft'=Ee 		/.left);
	ees;= n( e.runtimeS 		/
			eesLeft'=Ervenners.left);
 
t	//Put tn !jrder"
ve evdvnehgiphadtymputfinve evcou]	r.t			if
	Left'bsetGt's	s.leftap.| ( ct( .pa?S 		/.left);
	e}				t 		/.leftap.nne event n ntSizeat? "1em"opam =);
	eeTa'=Ee 		/.pupelLeft'+i"px"us
	el	//tov}:
roratio{] jdoentev[4! ht 		/.leftap.left);
	e			if
	Left'bsetGt's	s.leftap.
	Lefte edo		;
		
ruopagatgivar t ==at? "auto"opam =);
}e t;
}
i Evena raPcon pveNuml ta .ne ;
ritaxhisubtr cfndle jile  ( ma/st"
ptum|"( re cou oj.s[a"e;blcheckeu ( ma/st?( ; doGuardp,g

	eph== oritach"subtr cf"o "y.he e054,netdg vetn tssHookv( ;Math.max(		,  ( ma/s[2	ar -tio ubtr cfnven0t)us+ "(  ( ma/s[22#Doven"px"o
	inArpeConj t;
}
i Evenaau}e = WidthOrHeraht		 hand	 ery.EryirdIoisBw; cuBoxIoe 		/sa 	ntieplypap.|yirdant "(oisBw; cuBoxt? "bw; cu"t:==tye;")("ut"
		=
		Ifhwein/ Preved / Acord=raht
mchsuc un( o a/ Avoau}e = 

gatity4	inArdd OM3h e
sesinitlic, 30 =s*hh=rzye;
l 		fy.r	removN			retidePo	nne event tidthat? 1 :nt,*
	}lel	vo0nd {(ur = tma < 4tma +=22# )r s 
		bo		eboxtmr+ lsbpPr	ck nmmanie,oeo  forit// t) {when wt 3rc.retryirdant ".mmanie" x;
			}lel	+r ( !jQuecss([0331/"ryirda+ pssEy.exp[ry[  !p				oe 		/sa );
	
	
;
use an Bw; cuBoxtdle j;

		bw; cu-boxto
		ck ecpadc
	 cuso ild(marit// t) {when NournTrdomnc.retryirdant ".tye;")("ut"wdetesve  -r ( !jQuecss([0331/""padc
	 "a+ pssEy.exp[ry[  !p				oe 		/sa );
			{ee add 2] ei ncpoi( o "yirdai, rs bw; cu nur mmanie,oeo ild(marbw; cudomnc.retryirda!t ".mmanie" x;
			}sve  -r ( !jQuecss([0331/""bw; cu"t+ pssEy.exp[ry[ '+i"Width" !p				oe 		/sa );
			{e;			} elsntiodd 2] ei ncpoi( o "yirdai, rs tye;")(,oeo  forpadc
	 			}lel	+r ( !jQuecss([0331/""padc
	 "a+ pssEy.exp[ry[  !p				oe 		/sa );ntiodd 2] ei ncpoi( o "yirdai, rs tye;")( nur padc
	 cuso  forbw; cudomnc.retryirda!t ".padc
	 "ax;
			}sve  +r ( !jQuecss([0331/""bw; cu"t+ pssEy.exp[ry[ '+i"Width" !p				oe 		/sa );
			{e;		);
	}eTa1ndlur cl}bj}
i EvenafraWidthOrHeraht		 hand	 ery.Eryirdon({	
; doS of le
		eofftis'N			retu,es
	ch
lernquiur  tom oncordbw; cu-boxtve ev 3eplyve evI Bw; cuBoxt=e );
		0 lel	vonne event tidthat? .targefftisWidth': .targefftisHeraht		0 e 		/sai fraS 		/swil,te
	{
	t  Bw; cuBoxt=e( !jQuept-bSeriboxSizactl ) & !jQuerss([0331/""bwxSizact" !ps ) Ioe 		/sa a t ==bo; cu-box";	
; dogns( kven<(?:3tuery.EveeTa1ndl== oritachn		fdfftisWidthcuso mbounh			f anA/== oritac
; dogvg -t// hs://bugzilla.mozilla.org/	sew_bug.cgi?id=649285


			/thML -t// hs://bugzilla.mozilla.org/	sew_bug.cgi?id=491668
rc.retur l<put"venur l ]" anAn;)r s 
		F	vars FOOnehtymputfint054,nntymputfin
sskc.rneodeNa )gm lel	vo ( CSSar0331/" ery.Ee 		/sa );
	c.retur l<ut"venur l ]" anAn;)r s  lel	von( e.e 		/lemuseou;
	
		
mp
	 Cymputfi unitton is npupel .oS op 3h ca faleTa1nd.
 har thitumisnpx elem.lel
	;
			}teTa15)
valent;}

ming we n// onratio chon		fm 		/;,domMania
he browts
	ch
eTa1ues*unreliab8eoentev[4!  don		fh.cCymputfiS 		/asi  toly// itsrs FOOnehcord=eliab8eon( e.e 		/nArpeConI Bw; cuBoxt=e  Bw; cuBoxtlphet( !jQuept-bSeriboxSizactReliab8eovenur l ]von( e.e 		/lemuseoupMap.	8
		Nurmic, 30)[1]auto,vhiddpreirenon		fryirdgm lel	vopars/FloQu( lel	tnven0;				}.ng  napsh	D cfimarbwx-sIEactlnr+ l
eonadd/ ubtr cfniremetohen e 		/s	}eTa1ndl( lel	+gm au}e = WidthOrHeraht			}t0331/ s 	nndlth u	ryirdoven(fisBw; cuBoxt? "bw; cu"t:==tye;")("ute.retve evI Bw; cuBox
				t 		/[4! )
	)'+i"px"us;



	Tryo on	etermCon to t (t""];
ehe castct vato hiddthe in {}
i Evena ss		tion
iDhe casf(n.eCrne edle jile e		doc d trigE
			ehe cast= n( eehe cas[(n.eCrne e]		 {
		if ehe cast;
			}ehe cast=  cfualDhe casf(n.eCrne ragm eObj;ce  (It if t impleo		yofcaptove;addn/^(?
	eidca fypamlon
 har thehe casu t ==isn "eArr ehe cast;
			}	/perty of tn/ Prev-tnrgetdypamlonrnt icont
	c4! harre + =f(ypamlonrpell;
n			jQ	h"<pamlonramlonbw; cu='0'Etidth='0'Eheraht='0'/>"170 j.erss(["
sse:he"/" ehe cas:dlock !impSera)("ut70 jo
he couToif d e d trigE"div")(ute E8 

		Aipaingwritnia
er"
e co.ske	d;ena o WebkitvhiddFirefoxtdothenchoke  Eve; naE8 
e		doc(ypamlon = ctye;")(Wied=weArrpamlon = ctye;")(nerDocume) d:e, ha,bj8 
e		.writnh"<!e		tddep<(?:><<(?:><>"eNa")bj8 
e		.clo"inn;ent	}ehe cast=  cfualDhe casf(n.eCrne ragm eObj! harre +.// det( ;
	;
	
;

		Slec 'rschhe corre (t""];
ehe cas
		n( eehe cas[(n.eCrne e]doc he casOef;
	}eTa1ndl he casOe;



	C/  (ddONLYdn/^(?e
		ina ss		tion
iDhe cas
}
i EvenaacfualDhe casf(nne ragm eOle jile 
		s[i]			jQ	hue		.cnrget"div")( unction(c
he couToif d erapMa 
			ehe cast= & !jQuerss([0331i  u" ehe cas"nd;
tntevnild(ma(e;blcheckeu he casOe;

ks
jQue cur [ "heraht"/" tidthat]ove:he cou oi/pnction({		l)
tspatssHookvlemuseoutiatePrfraiontdif An		 hand	computfihiryirda )r s nep		/tymputfin lsntion
		cituaiattuery.Eveup )d / Adiry.svenainfo// t) {invisibly/ sewnrscmntion
		sewov}:,e		 m nnee,/ Ad t( .pa?hehe casum 		/; i2] weuldlbenoritcios aof, ( ; teTa1dom| ( cefftisWidth'input"nnerehe caspwe  elem.urn jQuecss([0331/" ehe cas"ndlt"
		=inn( !jQuepwdisp hand	cssShor,er: funcx;
			}t ; teTa1domfraWidthOrHeraht		 hand	 ery.Eryirdon4 )
cru}
	inAr:
	fraWidthOrHeraht		 hand	 ery.Eryirdon4 )
ciggerh	
;
sraiontdif An		 hand	ritaxhiryirda )r s 	
		st 		/sai ryirdaet atcS 		/swil,te
	4 )
ccheckedbraPcon pveNuml ta .ne ;
ritaxhiryirda
		=inau}e = WidthOrHeraht			}t}t0331/ s 	 	nndlth u	u	ryird,		=inn( !jQuept-bSeriboxSizactl ) & !jQuerss([0331/""bwxSizact" !ps ) Ioe 		/sa a t ==bo; cu-box",		=innt 		/[4!  jo :nt70 jo;
	
		);ndleObjar the( !jQuept-bSeriopacrn fn({		l)
tspatssHookv.opacrn fr tePrfraiontdif An		 hand	computfit;
			}	/peIEv/als nt obtven		fdpacrn ntioopagatgidpacrn  elem.u(computfit 3 | ( ct( .pa?S 		/a?.| ( ct( .pa?S 		/.nt obta:rn( e.e 		/.nt obt)yven""t"!
		=in( 0.01 *opars/FloQu( <(?:p(.$1t)us+ """t:		=in ymputfin?m"1"opa""usonrh	
;
sraiontdif An		 hand	ritaxa )r s 	
		st 		/	von( e.e 		/,gm fot( .pa?S 		/ap.| ( ct( .pa?S 		/,gm foopacrn fr rn jQueisNumeric(Iritaxa )? "alphl(opacrn ="t+ ritaxa* 100s/>]"sopa"",gm font obta= t( .pa?S 		/a]) t( .pa?S 		/.nt obtaor t 		/.nt obtaor ""us
	el	//IEvh	ectroub8eoe
		eopacrn fs 	}

ncy,cortie,/ Acasou]	r.t
		Fspal	}

 irsiselblinilezoom lad l4! ht 		/.zoom =2	e */
ial tfoeeselbli	pacrn f on1,vhiddnoM<M3h ent obtveexise -t

etmptoneheTd(marnt obta

eributna#6652*/
ial tfourtevent ".",nt054,ild(mariss eN*	pacrn f#12685{
		use a(Iritaxa> evecorurtevent "."t"!wrapMapp ( jQu.erim(rnt obtglexpt-bTagalphldsCon	ser t ==atnn		=innt 		/nild(maA
eributn?ck(/;
	el	//Seselblit 		/.nt obtano tuoapp=atn " " still
le,/ A"nt obt:" tn !jrd
sse:he;
	el	//use"nt obt:" tecpreroe; 2] aoapp
 chroddepisay the  d,t) {when eona/ Avo:m, ( ; t dog 		/nild(maA
eributn?isaIEvOnlyion, bso  pirentNlston ei nccteTapaca...bles g 		/nild(maA
eributn(e"nt obt 0b;
E8 
l	//useof rcton isrnt obtat 		/	]ctclect lra psskru99 		funtis'iss eN*	pacrn ,t) {renodve on	i	use aurtevent "."tcort( .pa?S 		/a]) !t( .pa?S 		/.nt obta
			}t ; 		.appusont	por+ type;l	//oM3h e
se,/tis'er"
nt obtaentev[4! ht 		/.nt obta= galphl elem.unt obta
	?gm font obtglexpt-bTagalphldsopacrn fn(:gm font obta+ " " +sopacrn ;
	
		);ndl



	TnlstehookvIup ortile pddfi untilte{}; Preveve 	// eif t t-bSer elem
 don		fitton is nrun untilt	trigte{}; Prev
ks
jQuer: functs ) {
ar the( !jQuept-bSeri=eliab8eMmanieRrahta
			}tl)
tspatssHookv.mmanieRrahta=lsnti	fraiontdif An		 hand	computfin lsntionep		/tymputfin lsntion  dotod DOoBug 13343 -th.cCymputfiS 		/aeTa1ues*wroblive evcit-bmmanie-=rahtee an  dotorkhar u)ct iryempSearilirsiselblinget tomehe casueoniss eN-dlock	}t ; 		.app ( !jQuepwdisp hand	{" ehe cas":
"ins eN-dlock" 
tPo	m fot( CSSs].spli	,".mmanieRrahts put);
	elefedo		;
	;				}.ng Webkitvbug:t// hs://bugs.webkit.org/	sew_bug.cgi?id=29084


		fraCymputfiS 		/aeTa1ues*ceacoe; e054,sion(frecklaleyop/left/bottom/=rahtee doeaM3h elhan	m/s foratisskmodu99 d	trigapMa schhfftis'modu99,t) {o nneio chon		f}

d rc4!ar the( !jQuept-bSeripupelPcon prev ) & !jQuefn.tcon prev
			}tl)
tspa cur e  "topsprlleftd,
[ve:he cou oi/pN			n lsntiol)
tspatssHookvleN			nutiatePri	fraiontdif An		 hand	computfin lsntionnep		/tymputfin lsntion .tymputfin=E ( CSSar0331/"N			n 4 )
crul	//use ( CSSteTa1ues*ceacoe;
gc !ps ls FOOnehhfftis	}t ; teTa1domitumisnpx elem.utymputfin l
		=inn
t			jQ	hul,te
	.tcon pre()leN			nut+i"px"a:		=inn
ttymputfi4 )
cru};
	elefedo	;
	
	x;
			}leObjar th = jQuery.rv ) & !jQuery.r.nt obtven({		l)
tspary.r.nt obtv.hiddent=e},uavol,:lpr
)ut"		}t/nt// SupporOceaal<pu12.12	}t/ntOceaallexof sgefftisWidthsios aefftisHerahts pagatlhan	zero ena omchtuery.Ev
 teTa1dom| ( cefftisWidth'<put"nne.targefftisHerahtl<put"vefedo( ( !jQuegateTypp=eliab8eHiddenOfftisvInne((n( e.e 		/;nne.targe 		/.ehe cas)tvenrn jQuetss([0331/" ehe cas"nddlnt ==isn ";
		and
	l)
tspary.r.nt obtv.visiblet"
},uavol,:lpr
)ut"		}teTa1dom!l)
tspary.r.nt obtv.hiddenwil,te
	4 );ndl



	TnlstehookvIrenonetdg iranimatn?nehry.expvN			retidePks
jQue cur =enmmaniepa"",gmpadc
	 pa"",gmbo; cu:i"Width"ut"
},tachEvfncoeSup,nsuffyxon({		l)
tspatssHookvlecoeSupt+isuffyxoutiatePrry.expiontdif An		ritaxa )r s 	
		s
ualsh
	terry.expfin=E{rh	
;
iodd 2ssu[\\sa erHTle tuml t'c.rortine timeS
;
iopof sgpesrc.reventevparen.ent!t oI? ve ev.|"( r(" "o :n[ventevp i ;
	e(ur = tma < 4tma; i+ even{
ry.expfilecoeSupt+ipssEy.exp[ry[ '+isuffyxouti )
crupof s[ry[ 'venpof s[ry[-22#Dovenpof s[r0n i ];
;
tionsrc.retry.expfi;
	
		);nd4!ar thetmmanie elem.ucoeSupt)a
			}tl)
tspatssHookvlecoeSupt+isuffyxou.s.cn=asaaPcon pveNuml t;t-bdleObeplyr20vtyp%20/g,gmpbr FO.cn=a/\[\]ur =srCRLFn=a/\r?\n/g,gmpsubmi; heTfn] ep.pe ?:submi;| ( but|image|rerot|nt e)$331/

submi; ablet"
pe ?:,.tim|( rget|rtac1eNa|keygen)/i;	cks
jQueQuer	t		neet
ndclic, 3ger: funcx;
			}teTa1domks
jQuepofamcur = cndclic, 3tch.ct)
			eFragmdclic, 3tch.cove: fun( o
			}teTa1uery.eve]disr: functi=			}	/peCmap]dpvN			Hookolale"tuery.Ev"oneh
i obta=s*adcklalmhtuery.Ev
 tjile 
		s")(sn=aks
jQuep			al, tr,e"tuery.Ev"ot);
	eeTa1ndl)		s")(sn?aks
jQuem/s tch.cturnnteep		:
:e =);cl)
	xl)
.nt obtsr: functi=			}	ile nt.types.event.t;		}	/perty .is(":y the  d"o so; i2] >"|| det[y the  d]a	orrs;
	eeTa1ndls.evemuseonne!( !jQuhuery.ev)is([":y the  d"t"!wrapMap
submi; able elem.us.evem.eCrne edl.ma! submi; heTfn]  elem.ust.tyes	tion
ifur = ct  chec
Arr  (;
_r/	// a) {

			bucusMoext.tesnt.tyesecl)
	xl)
.]disr: functioi/pl,te
				}	ile voon e = jQuhuery.ev)Adisb;
E8 
eTa15)
vall ]" anAn
		=in anAninAr:
			jQuen tch.ctulel	tn
		=inn( !jQue]dis
rit &ntdif An		rit
				}	8 
eTa15)
{	 ery:rn( e. ery.Eritax:=valglexpt-bTagCRLF,e"\r\e" x;}4 )
cru}
	inAr:
	{	 ery:rn( e. ery.Eritax:=valglexpt-bTagCRLF,e"\r\e" x;}4 )
})rerigicl)
dleObj
	Sdclic, 30anc e = to hlalmhtuery.Evpt-b5 tis'rej
	key/ve evdvis onass
		fe timeS
ks
jQuepofamt"
},uavol,:la !p	adirpre foOle jile coeSup,
;
sv]e e{
	tadck"
},uavol,:lkeyd	ritaxa )r s 	  (It vouncti, a
},uavol,,{invoke itvhiddeTa15)
iEvp ounc4! hve evcu	  use an . he cou ;ritaxa )? ritax(rget aurteventlsanAn?n""t:=j.s[a"e;bl;
s[ le( e
	glutiaencteTURICympsn )( ukeyn)t+i"="t+ encteTURICympsn )( uj.s[a"e;bl;};	}.ng Se se	adirpre fonehcrevcit-bery.Eve<pu1.3.2o chavi		.4!ar the	adirpre fo ] === oritachx;
			e	adirpre fo pitQu.noajaxSeselblsv ) & !jQueajaxSeselbls.e	adirpre f;				}.ng If0anc e = t		ecpassdiv0t,) ssu[\; i2] itton anc e = to hlalmhtuery.Ev.4!ar th			jQuen tch.ctua	tnventua.js
		feet = ( jQu.isPlainOt objtua	tnpe;
			} doSdclic, 30 schlalmhtuery.Ev
 tl)
tspa cur ea,er: funcx;
			}t adc(ls.evemuse,;ent..j.s[a"e;bl;}b;
E8			} elsnti  (It i	adirpre f, encteThinls"old"t		yo(inls		yo1.3.2o=s*old t
;  dodiorit)hi<M3h e
sesencteThpofamveeT ( spvely.ble(ur = coeSupt lra 
			}t gm foPofamvfncoeSup,nalecoeSupt], i	adirpre f, adcko;
	
		);	}.ng toabble =lererulelblitdclic, 

gatitcheckedb.joiu ;"&"ev).thProp(yr20,e"+"ot);}Obj}
i Evenagm foPofamvfncoeSup,nobj, i	adirpre f, adckole jile ecti;
4!ar th			jQuen tch.ctuobjnpe;
			} doSdclic, 30 e = tit e.
 tl)
tspa cur eobj, r: functioi/pva )r s nep		/e	adirpre fovenpbr FO.c elem.ucoeSupt)a
			}t 

		onrge  cur0 e = tit er	ec  scalar.bles adc(lcoeSup,nvn)i ;
	e			} elsntion  (It eron isn-scalar ( e = tor;nt obj), encteThiEvptumericpabe (.bles gm foPofamvfncoeSupt+i"["+ "( src.revelnt ==: funct;?ry[:sCon	s+i"]sprv, i	adirpre f, adcko;
	
 e	}
e)cl
;			}!fpPropa!e	adirpre fo ) & !jQueeddeioobjnpent ==: funct;
	ntio doSdclic, 30: functit e.
 t(ur = andletn objnpe		}t gm foPofamvfncoeSupt+i"["+ "nne e+ "]sprobjlemuseou, i	adirpre f, adcko;
	
		E8			} elsnti  (Sdclic, 30scalar it e.
 tadc(lcoeSup,nobjnpcl)
dlPks
jQue cur  ("bluur =cusr =custn  =cusou] loaddeTs, 30scronAnunloaddclick dblclick "	+gm"monetdr domonetupomonetd(marmonetdeNrrmonetdutrmonete	 hermonetle,/ A"	+gm"io{] j ( rget submi;ukeydr dokeyprersokeyupore ersh.t
	 }ry.u").|"( r(" "oove:he cou oi/pnction({	}.ng H, handeventibinc
	 		ks
jQueQulemuseoutiae:he cou ouncti fev
			}teTa1uera < handle( e
	gl>x0n
		=ient..Evfnuery.Etuoappuncti fev
	:		=ient..erignirn"andltr;	);ndleObjks
jQueQuer	t		neet
hdeNriontdif An		fnOv}:,efnOut 
			}teTa1uery.eve]onete	 he		fnOv}:ev)monetle,/ (efnOut venfnOv}:ev;omManipgixpiontdif An		eddes,ouncti fev
			}teTa1uerent..Evfneddes,otuoappuncti fev
		eFragungixpiontdif An		eddes,ofev
			}teTa1uerent..Efffneddes,otuoappfev
		eFra
t	e	dgat	add:uerandlereatch.c,	eddes,ouncti fev
			}teTa1uerent..Evfneddes,oreatch.c,	uncti fev
		eFragun	e	dgat	add:uerandlereatch.c,	eddes,ofev
			}tng n"andleltlea) ur = reatch.c,	eddes [,ofe]ut70 eTa1uera < handle( e
	gln( eve?rent..Efffnreatch.c,	"**"	:
:e =);.Efffneddes,oreatch.caor "**"i fev
		eFdleObepl}

		/orDocumeloc

gatitajaxLocPof s,itajaxLoc

gat,itajax_isncvcu	  use anew(rra
tajax_rs
		fe=a/\?r =srhash'=E/#.*ur =sr(sn=a/([?&])_=[^&]*r =srheader ep.pe .*?):[ \t]t([^\r\e]*)\r?$/mg, 	//IEvle,/ n anc\rtio{r cfbta

 EOL}

		#7653, #8125, #8152:eloc
ovN		tocoln	etec
gatitcloc
oP		tocoln"
pe ?:abeut|app|app-ytm age|.+-r	t		sven|nt e|rer|wideri):ur =srnoCe.g.,tu =pe ?:GET|HEAD)ur =srp		tocoln"
pe\/\/r =srurx; =pe [\w.+-]+:) ?:\/\/([^\/?#:]*) ?::(\d+)|)|)/
	}

		Keephadtypy we'rschold loaddmethod
	_loadd= & !jQuefn.load
	}

* PreSu obtv
	a* 1)	TnlyIrenonetfulueonistroducvccustom 	nctT = s (ee
 ajax/jsonp.jsmft-b5  example)
	a* 2)	Tnlstereno//  (d:
	a*    - BEFOREr	eOactl =s*a transeTyp
	a*    - AFTERhpofamitdclic, 

gat (e. = da, d,: timeSetfoeep		odeND= da, dble =
	a* 3)ukeynon eie 	nctT = 
	a* 4)forati( ma	varsymboln"*"	up )bo netd
	a* 5)i couutgat will
s of le
		etranseTyp 	nctT = vhiddTHEN tye;inum dr doeon"*"	c.rneedtd
	a*/
	preSu obtvn=E{rh	
;
* TranseTypsibinc
	 v
	a* 1)	keynon eie 	nctT = 
	a* 2)forati( ma	varsymboln"*"	up )bo netd
	a* 3)u( rgetntNowill
s of le
		etranseTyp 	nctT = vhiddTHEN gooeon"*"	c.rneedtd
	a*/
	transeTypsi=E{rh	
;
d A/ Avo/omt to-p		logtio{ru( s
	ncvc(#10098); m nnehe cManilintvhiddevadeutymprersgatitallTfn] ep."*/"ctyei( ("*"eObj
	 #8138,/IEvmasuefrowb5  exru{}ntNow054,.nodeN
	 	dd 2 >"|| dn/^(?e
ed=w.loc

gatb
		ed trigEe dmaiath	ecve betis				alseajaxLoc

gatap.loc

gat.hreSndl		inalE xa )r s/perty of threSa

eributnao hiddAdthe in {
 dogincvcIEvwill
modif tit gpven	ed trigEeloc

gatitajaxLoc

gatap.ed trigEecnrget"div")( u"a"ot);
ajaxLoc

gat.hreS  =""usoajaxLoc

gatap.ajaxLoc

gat.hreSndl



	Segocumeloc

gatvis onpof s
ajaxLocPof sa= gurxe cou oajaxLoc

gat.anpve	el "inn	tnven[ i ; doBMani" Otedruch.c"cit-bery.EveajaxPreSu obtvhiddery.EveajaxTranseTyp
}
i EvenaaddToPreSu obtvOrTranseTypsal, ruchuc 'n({	}.ng 	nctT = Exprersgatti,  prpre foos ad)ion
isoeon"*"itcheckede:he cou ounctT = Exprersgatove:he?ck(/;
	
		ifhandleO	nctT = Exprersgatt!ren.ent!t oIpe		}t e:he?=O	nctT = Exprersgatbj8 
enctT = Exprersgattp."*";
	;
	
;
ile enctT = i
	te
ualsh
	te	nctT = s =O	nctT = Exprersgat.anpve	el "inn.minalE s.pObrnotr ! !	tnven[ i ;io
		if  use an . he cou ;e:he?ck )r s 	  (F		frcur0	nctT = vtn !jrd	nctT = Exprersgat s 	s
			l?e;	nctT = v=O	nctT = s[i++])a
			}t 

		Pretriga
		r s
	sttd;
	el			ifdectT = n	tynt ==+t;
	ntion:
	nctT = v=O	nctT = -5a, ev"veevor "*"4 )
cru(, ruchuc [0	nctT = v]'=Ee ruchuc [0	nctT = v]'ven[ ).unshift ;e:he?c;
E8 
l	//OM3h e
seshe cou;
	ele		} elsntionu(, ruchuc [0	nctT = v]'=Ee ruchuc [0	nctT = v]'ven[ ). || wie:he?c;

	elefedo		;
	 );ndl



	BManiinsionEvena}
i Evenaf=s*coeSu obtvnhidderanseTyps
}
i EvenainsionEPreSu obtvOrTranseTypsal, ruchuc ,  prpres,hh=ragm fOprpres,hjqXHR?ck(/;

		s
nsionEfin=E{rh	;
sreOactTranseTypdoc(y, ruchuc 'nt "i
anseTypsic;
E8}
i EvenainsionEifdectT = n lsnti,lon( rgetfi;
	

nsionEfi[0	nctT = v]'=Eble ;
 tl)
tspa cur ee ruchuc [0	nctT = v]'ven[ ove:he cou o_,*coeSu obtOrFach.cst;
			}	ile enctT = OrTranseTyp	vopoeSu obtOrFach.cs(  prpres,hh=ragm fOprpres,hjqXHR?cbj! harifhandleO	nctT = OrTranseTyp	vren.ent!t oInne!sreOactTranseTypdnne!
nsionEfi[0	nctT = OrTranseTyp	Dodowdetes prpres.	nctT = s.unshift ;	nctT = OrTranseTyp	c;

	elinsionEifdectT = OrTranseTyp	c;

	elcheckedes ) ;;
	e			} el
	 3 ( eOactTranseTypd
			
cruopagatg!(n( rgetfiv=O	nctT = OrTranseTyp	c;

	ee	}
e)cl)ccheckedbrrgetfi;
	;
	}eTa1ndlinsionEif prpres.	nctT = s[r0n eevor !
nsionEfi[0"*"	Dooc insionEif"*"	)ndl



	A sion(oo r	t		nl =s*ajaxf prpres
/do i2] takls "flQu"t prpres (orti onle deephr	t		ned)
dd Fupesb#9887
}
i EvenaajaxE	t		neh.manip,orr eOle jile deep,lkeyd
 t(lQuOprpreso pitQu.noajaxSeselbls.(lQuOprpresoor {}nd {(ur = keynonorr eOle junctio rc[ keyn]l!] ===edsCony.
			
crwielQuOprpres[ keyn]l?h.maniph: 3  (ephvent (eph=E{rtnpe;[ keyn]l=o rc[ keyn];
	
		);	;
	 3  (e	n lsnti = jQueryit(" !p				o.manip,o (e	n ;
	;
	}eTa1ndl.manip				cks
jQueQueloadd= ntdif An		urx,hpofamv,o//  s FOO ) {
ar thhandleOurx;!ren.ent!t oInne_loadd
			}teTa1uer_load
he lyal, tr,ea < handln ;
	;
	},lon( rget.c,	rerprese	funFn 
onsaniypes.ev,gm hfiypeurxeabe (Of(" "eObj
ar thhfiy>put"b{
	r.reatch.capeurxe5a, ev"hfi,eurxe.node: e;
	
urx; =urxe5a, ev"0,hhfiy ;
	;
	}  (It it', a
},uavol,4!ar th			jQuen . he cou ;pofamven(ck(/;
	ng We) ssu[\; i2] it'sforati(  s FO
,d 	  s FOO=;pofamv;
	
pofamve ===edsCony;	}.ng OM3h e
se,/gm fonaspofamittimeS
;			} el
	 3 pofamvennehandleOpofamve t ==: funct;
	ntiont.type"POST";
	;
	}  (It weie,/ Atuery.Evp onmodif ,	m/s foratr s
	st


	 3 ( rfe( e
	gl>x0n lsnti = jQueajax(sntiourliourl !
rul	//use"nt.t" ,loiab8eois=== oritac
nt054,"GET"dmethodmwill
be	netd
	ser = : unFn 
ond	nctT = : "<(?:"unt,d	nct:Opofamv )
})rdve sr: functiorerpresee:he?ck(/;
	edd Saveorerpresel =s*// e	nutymp	d;_}e	  s FO
,d	rerpresel=ea < handl;
E8 
( rfe<(?:fnreatch.c ?
E8 
l	//Ifha reatch.c 		ecsion(frec,eloc

 Acord=raht
tuery.Evp lra dummy divE8 
l	//EPr	ck ns	sy theeona/ AvoIEv'PermCrsgattDenrec'tre ersnAr:
			jQu("<div>"o
he cou ;ks
jQuepofsee coiorerpresee:he?ck).ritdfnreatch.c 
	:	E8 
l	//OM3h e
ses// eif tfanAnrerule	
cruoprpresee:he?c;
E8 })rtymp	d;_(o//  s FOOnner: functiojqXHR,dbd suvI
			}.o( rfe cur e//  s FO,	rerprese'ven[ojqXHR.oprpresee:he,dbd suv,hjqXHR?]n)i s,e)cl)

	}eTa1ndl.=);cl}i ; doAttcur0 /gmnchto hllityndo60 =s*h, hameSe/omtattAJAXdeventePks
jQue cur e  "ajaxS of sprlajaxS opsprlajaxCymp	d;_sprlajaxEe ersprlajaxSunodeNsprlajaxScoud,
[ve:he cou oi/pnt.tye{		ks
jQueQulet = v]'=Entdif An		fn
				}eTa1uerent..Evfneddei fev
		eF;dleObj = jQueryit(" ")
p
	 Cyu	 her =s*hhldlbliniletuml t'o hicfimars
		idePoicfima:nt,*
	
	 Last-Modifreckheaderd 		ee 			f :he?r s
	st

lastModifrec:E{rh	;etag:E{rh	
;ajaxSeselbls:lsntiurlioajaxLoc

gat,iter = : "GET"unt,isLoc
liocloc
oP		tocol elem.uajaxLocPof s[2	ar  
			g (  !:! );
		0 p		odeND= d:! );
		0 	sync:! );
		0 tye;")(T = : "]ctclc

gat/x-www-lalm-urlencteTd;tio{rset=UTF-8"unt,/*iterimtdut:nt,*/
	nct:Otuoap
nd	nctT = : tuoap
nd// r ery:rtuoap
ndpassword:rtuoap
nd 		ee:rtuoap
ndus x		:!ps ) Ir.
i	adirpre f:!ps ) Ir.
header :E{rh	;	*/
E8 .nod th:lsnti	"*": allTfn]  !eser:he: "r:he/plain"unt,d<(?:: "r:he/<(?:"unt,dx?:: "]ctclc

gat/x?:,;e:he/x?:"unt,djson: "]ctclc

gat/json,;e:he/java ? 2 : 
onrh	
;
tye;")(s:lsnti	x?:: /x?:/unt,d<(?:: /<(?:/unt,djson: /json/
onrh	
;
oprpreseF"|| d:lsnti	x?:: "oprpreseXML" !eser:he: "oprpresee:he"unt,djson: "oprpreseJSON 
onrh	
;

		/= dacenv}:
btv
	

		Keyecseire

 Asoupal	(ersh( ma	var"*"eoos ad)selb

gatveddes e
		ed erHTle eltle
;
tyev}:
btv:k(/;
	edd Cenv}:
rany		inlino t:he;
	e"* t:he": StimeS !
rul	//e:he?no <(?:3dble 	vono"i
anslalm

gatt70 j"r:he <(?:"le );
		
rul	//Ej.s[

 Acry.	o, a
jsontry.rersgat s 	"r:he json"f ( !jQuepofseJSON		
rul	//PofseAcry.	o, x?: s 	"r:he x?:"le( !jQuepofseXML
onrh	
;

		F		fdpyndo60 i2] 	seuld rs be deephr	t		nedinArdd youtcmap]dpvyou	fdwnccustom dpyndo60f rctof
 ; do falw054,youtcnrget one0 i2] 	seuld rs be
 ; dodeephr	t		ned (ee
 ajaxE	t		n)
 t(lQuOprpres:lsnti	urlio );
		0 	h.t
	 }le );
		
				
	}

		Cnrget, a
},varfled jdoseselblsv: functis on.manip}

		e
		ebo		eajaxSeselblsvp dctiselbls >"|| d.	}  (It .maniphi,  mi; hd,t)ritndvis onajaxSeselbls.
;ajaxSesu ove: fun( or.manip,oriselbls 
			}teTa1dom iselbls ?	
rul	//Bm folbliateeselblsv: func
rulajaxE	t		nehajaxE	t		neh.manip,oitQu.noajaxSeselblsv),oriselbls 
	:	
rul	//E	t		nlbliajaxSeselbls
rulajaxE	t		nehitQu.noajaxSeselbls	o.manipv
		eFra
tajaxPreSu obt:aaddToPreSu obtvOrTranseTypsalcoeSu obtvn),itajaxTranseTyp:aaddToPreSu obtvOrTranseTypsali
anseTypsic
	}

		Maiatmethod
	ajax: ntdif An		urx,hdpyndo60ck(/;
	ng IeOurx;on anc: func,t imr/	/=ucoe-1.5t igb

urc4! ar thhandleOurx; t ==: funct;
	ntios prpres; =urx;nti	urle ===edsCony;		
		
mp
	 Fspal	dpyndo60 onle anc: func
os prpres; =oprpresoor {}nd {},lon
		Cnoss- dmaiat	etec
gat ,los
rulpof s,itmp
	 Loop ,loiab8ej! ha,itmp
	 URLle
		ou] anti- 		ee pofam	0 	h		eeURL,itmp
	 Rerprese'header e	ecstimeS
;
ioprpreseHeader StimeS !tmp
	 rimtdut*h, haej! hrimtdutTimtr !
rul	//eo know/useg (  !deventeereno onle dielt ma/d
	sefireG (  !s !
ruli
anseTyp,itmp
	 Rerprese'header 
;
ioprpreseHeader ,itmp
	 Cnrgeteif tfgm fooprpreso: func
rulso pitQu.noajaxSesup(E{rhhdpyndo60c,itmp
	 C/  s FOssh.t
	 }	0 	h	  s FOC.t
	 }l=o .h.t
	 }aor t,itmp
	 C.t
	 }an		fh (  !deventee ncc	  s FOC.t
	 }ls 	}

,  ate{};m.eC t-bery.Evecollec
gatit		g (  !EventC.t
	 }l=o .h.t
	 }alphetc	  s FOC.t
	 } ur.noddepcort	  s FOC.t
	 } js
		fe).inAr.t		n(Quetc	  s FOC.t
	 } 
	inAr:
			jQueevent,itmp
	 Defre eds
mp	defre edo pitQu.noDefre ed(),
}..tymp	d;_Defre edo pitQu.noC/  s FOs("sncvcmemory"c,itmp
	 Sd suv-d	trigcumec	  s FO[4! ht  suvC.eC =o .t  suvC.eC or {},itmp
	 Header o(inlyIrenoroe; 2var2] sncv)
;
iops
	stHeader ep.{},itmpops
	stHeader N)[\\s= {},itmp
	 Tf tjqXHR?bd st4! ht  seualsh
	te
	 Def""];
abTyp	mdeNagt4! ht rAbTyp	vo"cmace  d"h
	te
	 F/s fxhudomnjqXHR?=			
cruopadySd sa:nt,*
	rul	//Bm fos'header ehash abletc.rneedtd
		i	fraRprpreseHeader:
},uavol,:lkey;
	ntion:
ile  ( ma4 )
cru
	 3 (d sta t =2;
	ntion:
!ar thetprpreseHeader ;
	ntion:
!ioprpreseHeader s= {};tion:
!is
			l?e; ( maa= gheader e cou ooprpreseHeader StimeS"et"dowdetes:
!ioprpreseHeader [  ( ma[1].anpve	el "inn	]'=E ( ma[22#D;tion:
!i}
on:
!i}
on:
!i ( maa= gprpreseHeader [ key.anpve	el "inn	]4 )
cru}
s:
!iopeckeu ( maentlsanAn?n anAni  ( ma4 )
crrh	
;
iodd Rawe timeS
;
iofraAllRprpreseHeadersove: fun( o
			}t
!iopeckeu(d sta t =2;?ooprpreseHeader StimeS":rtuoa4 )
crrh	
;
iodd Cama/stof theader
;
iosraRps
	stHeader:
},tachEvfnuery.Eritax;
			}.n:
ile lne + =fandl-anpve	el "inn4 )
cru
	 3 !rd sta
	ntiooooone + =fops
	stHeader N)[\\[ lne + ] =fops
	stHeader N)[\\[ lne + ] or ecti;
es:
!iops
	stHeader lemuseout"
peConj );
	u}
s:
!iopeckeu =);cl)
crrh	
;
iodd OeNrrides	rerprese'tye;")(-tddep<eader
;
iodeNrrideMimtT = : ntdif An		edden lsntionnep		/!rd sta
	ntiooooos.mimtT = gpesrc.j );
	u}
s:
!iopeckeu =);cl)
crrh	
;
iodd Sd suv-d	trigcumec	  s FO[4! hht  suvC.eC: ntdif An		maop
			}.n:
ile cteT4 )
cru
	 3 maop
			}.n:
u
	 3 (d sta<=2;
	ntion:
!{(ur = cteThin maop
			}.n:
ump
	 Lazy-]dpv!jrder"
//  s FOO lra 		yoni2] preror/ n old ones	}.n:
umpt  suvC.eC[ cteThut"
[ t  suvC.eC[ cteThu,	m/p[ cteThutD;tion:
!i}
on:
!i}		} elsntionuul	//E	ouuty of tnpp			oia;_}e	  s FOs	}.n:
umjqXHR.lipain(	m/p[ jqXHR.bd suvIput);
	el!i}
on:
!}
s:
!iopeckeu =);cl)
crrh	
;
iodd Cmace foratr s
	st




abTypadd:uerandlerd suse:he?ck(/}.n:
ile fgm fT	 }l=o d suse:he?or t rAbTyp4 )
cru
	 3 transeTypd
			
cruuli
anseTyp.abTyp( fgm fT	 }l)j );
	u}
s:
!idve s"0,hfgm fT	 }l)j );
	uopeckeu =);cl)
crrl)
c}nd {}dd Attcur0defre eds
mpdefre edep		mi"in"jqXHR?crtymp	d;_ = tymp	d;_Defre ed.]dp;
 tlqXHR.bunodeNo piqXHR.dve ;
 tlqXHR.re ers piqXHR.fcapnd {}dd Rtd(marhash'io{r cfbta(#7531:vp dcttimeS"p		mo
gatt70 /		Addmp		tocolnc.rortiprooentdg(#5866: IE7
, sueoe
		ep		tocol-pagaturlst70 /		H, handps )yOurx;on !jrdseselblsv: funct(#10093:e Oteis;")cyoe
		eold  igb

urct70 /		We) lsos// eif turx;pofameter// tavcapab8ej! s.urle = a(Iurleor t.urleor ajaxLoc

gatas+ """tv).thProp(yrhash,"""tv).thProp(yrp		tocol,uajaxLocPof s[2	ar  ""// 0b;
E8 
		Aii	ecmethodmdpyndoino t = vhs*cea riFO.cn#12004j! s.nt.type prpres.methodmor  prpres.tddepcors.methodmor vent.t;	
ul	//E	tr cfn	nctT = s list


s.	nctT = so pitQu.noerim(rs.	nctT = vor "*"tv)anpve	el "inn.minalE s.pObrnotr ! !	tnven[""Dap.	8
		A cnoss- dmaiatr s
	st
,  tn o; cu w054,weie,/ Aaep		tocol:host:eTypdmi"minal4! ar th .hnossDdmaiat ]" anAn;)r s  pof sa= gurxe cou ot.url.anpve	el "inn	tcl)
c .hnossDdmaiat  !!(npof ss	tion
ifupof s[2	ar !renajaxLocPof s[2	ar venpof s[r2ar !renajaxLocPof s[22#Dove );
	ufupof s[23#Doven(fpof s[2	ar  t ==// htat? "80sopa"443on	ser!re	
cruul.uajaxLocPof s[23#Doven(fajaxLocPof s[2	ar  t ==// htat? "80sopa"443on	sert70 jo;		
		
mp
	 Cenv}:
r = da,.rortin/ Prevene timeS
;
ar th . = danneeep		odeND= dannehandleO . = da!ren.ent!t oIpe		}t  . = da=mks
jQuepofamcu . = d, s.e	adirpre fa ;
	;
	
;

		Ae lylcoeSu obtv
elinsionEPreSu obtvOrTranseTypsalcoeSu obtv, s,  prpres,hjqXHR?cbj

	ng IeOr s
	st
		ecabTypdiv0teidca lcoeSu obt,dbdopaof rc4! ar th(d sta t =2;
	ntioneTa1domkqXHR;
	;
	
;

		Wcl)
t fireeg (  !deventeersgef now/useask/ one
sefireG (  !s =o .g (  !bj

	ng W( mae =s*a er"
tis'revr s
	std

cunctifireG (  !s  ) & !jQueacfima++"input"b{
	r.t			jQueevent.erignirn"ajaxS of s ;
	;
	
;

		Upceaca/ eif tt = 
	 s.nt.types.nt.t.anUpceal "inn4 
te
	 DetermCon 
		r s
	stth	ecNournTrdoms.h	eCe.g.,tu =!rnoCe.g.,t elem.us.nt.tyn4 
te
	 S / AcordURLl,domManiwe' catoyactle
		ecordIf-Modifrec-Sincv
 ; do fa/=s*If-Nve -M( maeheaderd/	/=r atit	h		eeURLypes.urx;n
 ; doMec 'dpyndo60f, hameSe =s*r s
	stdle
		enocNournTrdomep		/!r.h	eCe.g.,tuck(/;
	edd If  = da, d,vcapab8e,she cou  = dano urx
	;
ar th . = da
			
cruh		eeURLype ot.url +r (fajax_rs
		f elem.ut		eeURLy )? "&sopa"?on	s+i . = da
;
;
iodd #9682:,ild(mar = daso; i2] it'sfortiusect lrandeventuaAnret )gm 	t	e	d
 As. = d;

	ee	;
	edd Addmanti- 		ee  lrurx;o.rneedtd
		iar th .h		ee inpups ) a
			
crus.urle =yps elem.ut		eeURLy )?	
;
ioe  (It if rcton n/ Prevene'_';pofameter,/tis'iEvp ounc4! hruh		eeURL).thProp(yremov"$1_="t+ ajax_isncv; i+ :	
;
ioe  (OM3h e
seshdd one0 ehcordcou;
	eluh		eeURLy+ (fajax_rs
		f elem.ut		eeURLy )? "&sopa"?on	s+i"_="t+ ajax_isncv; ;

	ee	}
e 
te
	 SiphcordIf-Modifrec-Sincvo fa/=s*If-Nve -M( maeheader,// titb
	Modifrecknr+ .
 har ths.
	Modifreck )r s nep		/			jQuelastModifrec[ut		eeURLyDodowdeteslqXHR.braRps
	stHeader( "If-Modifrec-Sincv",/			jQuelastModifrec[ut		eeURLyDod;

	ee	}
nep		/			jQueetag[ut		eeURLyDodowdeteslqXHR.braRps
	stHeader( "If-Nve -M( ma",/			jQueetag[ut		eeURLyDod;

	ee	}
e 
te
	 Siphcordhe correheader,// t = da, dbelblitdTrdomep		/ . = danneeeh	eCe.g.,tunneeetye;")(T = a!renps ) aor  prpres.tye;")(T = ab{
	r.t	qXHR.braRps
	stHeader( "Ce.g.,t-T = ",eeetye;")(T = a ;
	;
	
;

		SiphcordAnod theheaderdlaley==uror/ c,	u	triglbli	n !jrd	nctT = 
.t	qXHR.braRps
	stHeader(	r.t"Anod t"h
	tes.	nctT = s[r0n enneee.nod th[ s.	nctT = s[0]n]l?	
crus..nod th[ s.	nctT = s[0]n]l+ ( s.	nctT = s[r0n e!ren.*at? ", " +sallTfn] e+i"; q=0.01"[:sCon	s:	
crus..nod th[ "*"	D
 jo;	
mp
	 Co chon		fheader e prpre
!{(ur = inonor.header ;
	ntion	qXHR.braRps
	stHeader( i,or.header [ry[ ' ;
	;
	
;

		Aecorccustom header /mimteddes hiddearlylabTypdomep		/ .be(ureScoualphet .be(ureScou.e	  etc	  s FOC.t
	 },ojqXHR,dbnpent =ps ) aor (d sta t =2;
	 )r s 	  (AbTyp	,.rortidve  n/ PreveniddeTa15)tioneTa1domkqXHR.abTyp( ;
	;
	
;

		abTypmeSetn isrlonnireancmace l

gatityt rAbTyp	vo"abTyp"bj

	ng In(d nAne	  s FOsi	n defre eds
mp(ur = inono{ bunodeN:n1,vre er:n1,vtymp	d;_:n1 };
	ntion	qXHR[ry[ et [ry[ ' ;
	;
	
;

		Ge se	anseTyp
	li
anseTyp	voinsionEPreSu obtvOrTranseTypsali
anseTyps, s,  prpres,hjqXHR?cbj

	ng IeOno"i
anseTyp,t) {ruto-abTypdomep		/!transeTypd
			
crdve s"-1,v"No TranseTyp"ot);
	}		} elsntiojqXHR.opadySd sa =2	e */
ial Scouag (  !devent	}
nep		/fireG (  !s dowdetesg (  !EventC.t
	 }.erignirn"lajaxScoud,n[ojqXHR,dbnDod;

	ee	}
n
	 Timtdut
		iar th .	syncenneeerimtdut*>x0n lsnti hrimtdutTimtrn=asaaTimtdut(e: fun( o
			}t
!ikqXHR.abTyp("rimtdut"c;

	ele,eeerimtdut* );
			{ee a			alse	 ht  seual1;

	eli
anseTyp.s		nehops
	stHeader ,idve   );
			sh( ma E xa )r s	 

		Propagat	 exru{}ntNo	ecre ers,.rortidve 

cru
	 3 (d sta<=2;
	ntion:
dve s"-1,vea
;
;
iodd SimplydeTafrowb<M3h e
se

	ele		} elsntionuafrowbecl)
crrl)
c}		
		
mp
	 C/  s FOO(ur w054,ov}:y		inliisayve 

c}
i Evenadve s"bd suv,hb

gveSd suse:he,	rerpresev,hheader ;
	ntion
		s
sSunodeN, bunodeN,vre er,	rerprese	fmodifrec,se	 ht  suse:he?=hb

gveSd suse:hee */
ial C/  (ddoncv
 ;u
	 3 (d sta t =2;
	ntion:		.appusonte	;
	edd Sd sa isa"dsn "enow
	 ht  seual2e */
ial C chr rimtdut*s 	}

exisem
 ;u
	 3 rimtdutTimtrn
			
cruh chroimtdut( rimtdutTimtrn
usonte	;
	edd D rcfre	ncvctranseTypdn		frarlylgarb
gcacollec
gatit		ng nno"m

ets*hhwrlonn !jrdjqXHR?: functwill
be	netd)
		li
anseTyp	vo==edsCony;	}.iodd Cama/	rerprese'header 
;
ioprpreseHeader StimeS"=hheader ;or ""us
	el	//SiphopadySd santiojqXHR.opadySd sa =2bd suvI>x0n
 4 :nt;	;
	edd D termCon 
		bunodeNfux
	;
asSunodeN =2bd suvI>al200tnnee  suvI< 300aor (d suve t =304;	;
	edd Giphoprprese'	nct
 ;u
	 3 rerpresev;
	ntion:		rpresel=eajaxH, hanRprpresesal,,ojqXHR,drerpresev;
usonte	;
	edd Cenv}:
rno"m

ets*wi2] ( i2] waydrerpreseXXX >"|| dIrenolipainasaa)
on:		rpresel=eajaxCenv}:
al,,orerprese	fjqXHR,dasSunodeN te E8 

		I		bunodeNfux,*h, hae t = vchainmeS
;
iuse an SunodeN t (/;
	el	//SeshcordIf-Modifrec-Sincvo fa/=s*If-Nve -M( maeheader,// titb
	Modifrecknr+ .
 h har ths.
	Modifreck )r s n		modifrecs piqXHR.fraRprpreseHeader("Last-Modifrec"n4 )
cru
	 3 modifreck )r s n						jQuelastModifrec[ut		eeURLyDo= modifrecj );
	u}
s:
!imodifrecs piqXHR.fraRprpreseHeader("etag"n4 )
cru
	 3 modifreck )r s n						jQueetag[ut		eeURLyDo= modifrecj );
	u}
s:
!}/;
	el	//,.ror NournTrdomnu
	 3 (d suve t =204mor vent.t  t ==HEADt;
	ntion:
t  suse:he?=h"notye;")(";/;
	el	//,.rort modifrec

	ele		} el
	 3 (d suve t =304;
	ntion:
t  suse:he?=h"notmodifrec";/;
	el	//It weie,/ A = d, 	d;'shcenv}:
ri;

	ele		} elsntionut  suse:he?=hrerprese.bd sT4 )
crubunodeNo prerprese. = d;

	e		re ers prerprese.re er4 )
cru
sSunodeN =2!re er4 )
crrl)
c}		} elsntion  (Weiryirdnctre ersn/^(?t  suse:hention  (t054,nurmic, 30t  suse:he?p dctt suve			f on-abTyps	}.n:re ers psd suse:hee omnu
	 3 (d suveor !rd suse:he?ck(/}.n:
t  suse:he?=h"re er"4 )
cru
	 3 e  suvI< 0k )r s n			(d suve n0;		;
	u}
s:
!}/onte	;
	edd Se
r = dalaley==uf/s fxhuo: func
ruljqXHR.bd suvI psd sus;
ruljqXHR.bd suve:he?=h(hb

gveSd suse:heaor (d suve:he?ck+ ""us
	el	//SunodeN/Ee er
;
iuse an SunodeN t (/s:
!defre edererolveWithetc	  s FOC.t
	 },o[ bunodeN,vsd suse:he,	jqXHR?]n)i s,c}		} elsntiondefre ederefuncWithetc	  s FOC.t
	 },o[ jqXHR,dbd suve:he,	re ers];
usonte	;
	edd Sd suv-d	trigcumec	  s FO[4! hjqXHR.bd suvC.eC( t  suvC.eC	tcl)
c   suvC.eC =o==edsCony;	}.ioep		/fireG (  !s dowdetesg (  !EventC.t
	 }.erignirn"n SunodeN ?rlajaxSunodeNs[:sCajaxEe ersp		;
	u[ jqXHR,db,"n SunodeN ?rbunodeNo:	re ers];
usonte	;
	edd Cymp	d;_;
	etymp	d;_Defre ed.fireWithetc	  s FOC.t
	 },o[ jqXHR,dbd suve:heoupMap.	8nep		/fireG (  !s dowdetesg (  !EventC.t
	 }.erignirn"lajaxCymp	d;_spr[ojqXHR,dbnDod;

	e /		H, handy==ug (  !dAJAXdcyu	 he omnu
	 3 !s"--& !jQueacfimat)a
			}t 
t			jQueevent.erignirn"ajaxS op"c;

	elel)
c}		
		
mpeTa1domkqXHR;
	rh	
;fraJSON: ntdif An		urx,h = d, //  s FOO ) {
teTa1domks
jQueerig	urx,h = d, //  s FO,v"json"v
		eFra
tatcS? 2 :: ntdif An		urx,h//  s FOO ) {
teTa1domks
jQueerig	urx,h== oritac
n//  s FO,v" ? 2 : v
		eFdleObPks
jQue cur e  "eri", "postd,
[ve:he cou oi/pmethodmn({		l)
tsp[pmethodm]'=Entdif An		urx,h = d, //  s FO,vedden lsnti doghiftea < handln/ t = daa < hand
		ec mi; hd

nep		/			jQuen . he cou ; = da
	
			}t t = gpesrc.pcort	  s FO;

	e 	  s FOO=; = d;

	e = da=m==edsCony;		
		
mpeTa1domks
jQueajax(sntiourliourl !	ter = : method 
ond	nctT = : unFn 
ond	nct:h = d,
crubunodeN:}e	  s FO
,d}
		eF;dleObj/*	H, hansdrerpresev; onanaajaxhops
	st:
 * -hfgmdsAcord=raht
	nctT = v(mediget, betwe betye;")(-tddephiddexionEfin	nctT = )
 * -heTa1ues*cordhe corpreglblirerprese
a*/
}
i EvenaajaxH, hanRprpresesal,,ojqXHR,drerpresev;
le jile firstDnctT = i nc,tfgm fDnctT = i unFn 
ontye;")(sl=o .h.t
	n s,itm	nctT = so ps.	nctT = s;	}.ng tod(marruto 	nctT = vhiddnipvtye;")(-tddepon !jrdp		odeN
is
			ifdectT = s[r0n e=ren.*at
			}t	nctT = s.shift  );
	c.retcto ] === oritachx;
				c}l=o .mimtT = gvenrqXHR.fraRprpreseHeader("Ce.g.,t-T = "o;
	
		);	}.ng Co cho/ t) ' cadealactle
		ea knowbetye;")(-tdde
	c.retctox;
			(ur = tddepon tye;")(sl )r s nep		/tye;")(slet = v]']) tye;")(slet = v] elem.uttt)a
			}t 
	nctT = s.unshift ;nt.tyn4 }t 
bopak;

	ee	}
e );	}.ng Co choto ee
 if,weie,/ Aaererpresel =s*cordcxionEfin	nctT = 	;
	 3  ectT = s[r0n eiatr rpresev;
	ntiofgm fDnctT = v=O	nctT = s[r0n i ]			} elsnti  (TEveconv}:
iblet	nctT = s			(ur = tddepon rerpresev;
	ntion
		if eectT = s[r0n eor vetyev}:
btvlet = v+ " " +s	nctT = s[0]n]l
			}t 
fgm fDnctT = v=Osrc.j );
	bopak;

	ee	}
n
		if firstDnctT = l
			}t 
fgrstDnctT = l=Osrc.j );
e	}
e )e  (Or{o nne// efgrst ve 

c}gm fDnctT = v=O}gm fDnctT = vvenfgrstDnctT = ;
	;
	}  (It weif u)ctan	nctT = 	;/		We) dpv!jrd	nctT = v ehcordlist;o.rneedtd
	 do falopeckeu =rdhe corpreglblirerprese
nep		/fim fDnctT = vOle junctiofim fDnctT = v!ren	nctT = s[r0n eev{
t 
	nctT = s.unshift ;fim fDnctT = vO;
	
		)teTa1domierpresev[;fim fDnctT = v]		eFdlbj/*	Chaineconv}:sndo60gpven	oratr s
	stnhiddescho=ragm firerprese
a* AlsostisvIta/	rerpreseXXX >"|| dI	n !jrdjqXHR?in(d ncv
a*/
}
i EvenaajaxCenv}:
al,,orerprese	fjqXHR,dasSunodeN tle jile conv2,rt( .pa?, convi ump,*coev 
ontyev}:
btvs= {},itm/dotorkhe
		ea typy we'	nctT = so,domManiwe n// ono
modif tit fersh.tv}:sndoitm	nctT = so ps.	nctT = se5a, ev);	}

		Cnrgetacenv}:
btv maope
		elve	emMand keys	;
	 3  ectT = s[r1n eev{
t (ur = ctnvnonor.cenv}:
btv x;
				cyev}:
btvlecyev.anpve	el "inn	]'=Evetyev}:
btvlectnvn];
	
		);	}.t( .pa?hen	nctT = s.shift  );
edd Cenv}:
rnehrcur0( s
	nt(oo 	nctT = 	;s
			l?et( .pa?hck(/;
	
		ifs.oprpreseF"|| d[et( .pa?h eev{
t 
	qXHR[rs.oprpreseF"|| d[et( .pa?h e]s prerprese;
	;
	
;

		Ae lyl!jrd	nctFu obtvnt irooentd;
	
		if!coevooc isSunodeN nneee	nctFu obtv
	ntioneTrpresel=eee	nctFu obt(orerprese	fs.	nctT = v ;
	;
	
;
coevo= t( .pa?;
	;t( .pa?hen	nctT = s.shift  );
enep		/t( .pa?hck(/;
	p
	 Tf re'dI	nlyl	orro on	o/use ( .pa?henctT = vtn isn-ruto s nep		/t( .pa?heren.*at
				}t 
t( .pa?hencoev;	}.iodd Cenv}:
reTrpreselnt irevoenctT = vtn isn-rutooos adiffbtven/^(?t( .pa? s,c}		} el
	 3 prevo!ren.*atnneprevo!rent( .pa?hck(/;
	pedd Seektan	icorretyev}:
bt	}t 
ttnvn= tyev}:
btvleprevo+ " " +st( .pa?h ecortyev}:
btvle"* " +st( .pa?h ;/;
	el	//It isn if u)c, ( eOnaspoie omnu
	 3 !ttnvn
			}t 
t(ur = ctnv2 ineconv}:
btv x;
	 s n				//It ctnv2 outpuEveu( .pa? s,c	termpn= tyev2.|"( r( " " t);
	el!i
	 3 rmp[2	ar  t =t( .pa?hck(/;
	pe				//It prevoup )bo conv}:
b ono
.nod tect lpu? s,c	te
ttnvn= tyev}:
btvleprevo+ " " +srmp[20h e]sve );
	u			cyev}:
btvle"* " +srmp[20h e]);
	el!inep		/tyevn
			}t 
t.iodd Cendeesel s
ival	ncvccenv}:
btv
	
	el!inep		/tyevnnt "i
ax;
			}.n:
	te
ttnvn= tyev}:
btvlectnv2  ;/;
	elt.iodd OM3h e
se,/in(}:
rnee  ltermedigetd	nctT = 
.ttttttt}		} el
	 3 tyev}:
btvlectnv2  o!reni
ax;
			}.n:
	te
t( .pa?henrmp[20h ;	}.n:
	te
	nctT = s.unshift ;nmp[2	ar );	}.n:
	te}	}.n:
	tebopak;

	e
	te}	}.n:
	}
on:
!}
s:
!}/;
	el	//Ae lyltyev}:
bt (,.rortinnl s
ival	ncv) omnu
	 3 ttnvn!reni
ax;
			
lt.iodd Unpagatre ersIrenolilve	 ono
bubb8e,sh( ma  falopeckeu =rm )
cru
	 3 ttnvnnnee  "ts x		"n]l
			}t 
oneTrpresel=ettnv(orerpresel)j );
	u}		} elsntionuu			alse	 h
oneTrpresel=ettnv(orerpresel)j );
	u		sh( ma E xa )r s	 
	 
eTa15)
{	sd sa:n"pofseree ersprre er:nttnvn? xa:v"No h.tv}:sndoen/^(?" +sprevo+ " eon" +st( .pa?h};tion:
!}
on:
!}
s:
!}/		ee	}
e );	}.eTa15)
{	sd sa:n"sunodeNspr	nct:hrerpresel;ndl
ng In(d nAn ? 2 :d	nctT = 
itQu.noajaxSesup({
 .nod th:lsntis? 2 :: "e:he/java ? 2 :, ]ctclc

gat/java ? 2 :, ]ctclc

gat/ecma ? 2 :, ]ctclc

gat/x-ecma ? 2 :"	eFragtye;")(s:lsntis? 2 :: /(?:java|ecma)s? 2 :/	eFragtyev}:
btv:k(/ 	"r:he  ? 2 :": ntdif An		e:he?ck(/}.nks
jQuee (  !Eval		e:he?c;
	 
eTa15)
t:hee om}l)
dleObj
		H, handt		ee's sion(oo mManiaouag (  !
itQu.noajaxPreSu obt(v" ? 2 : [ve:he cou osO ) {
ar th .h		ee inpu== oritachx;
			 .h		ee ides ) ;;
}{
ar th .hnossDdmaiatx;
			 .nt.type"GET";			 .g (  !dides ) ;;
}{leObj
		Bi dct? 2 :dtagie,chot	anseTyp
ery.EveajaxTranseTyp(v" ? 2 : [ve:he cou sn({	}.ng Th, dblanseTyp		nlyldealdle
		ehnoss  dmaiatr s
	sts{
ar th .hnossDdmaiatx;
	
ti,lon(? 2 :,
	 
head p.ed trigEehead venrn jQu("head")[0]nvened trigEe d trigE"div")(;	
mpeTa1dom{
E8 
( xpiontdif An		_,h//  s FOO ) {
s:
!t? 2 :dp.ed trigEecnrget"div")( " ? 2 : c;
E8 
l ? 2 :.	synce=Eble ;
 omnu
	 3 s.s? 2 :Co{rset?ck(/}.n:
t? 2 :.io{rset =o .t? 2 :Co{rset;

	elelE8 
l ? 2 :.rr epes.urx;n
 ;{}dd Attcur0h, haetven		f nAnb x		btv
	
	e ? 2 :.onloadd=  ? 2 :.onopadysd saio{] j =ontdif An		_,hisAbTyp	
			
lt.iouse an AbTyp	or !r? 2 :.opadySd sa or /loaded|tymp	d;_/ elem.us? 2 :.opadySd sa ) x;
	 s n				//H, handmemoryvle,OO lrIE s n			 ? 2 :.onloadd=  ? 2 :.onopadysd saio{] j =otuoa4  s n				//tod(mary==ur? 2 :;
	el!i
	 3  ? 2 :.irentNN.eC	t)r s	 
	 
 ? 2 :.irentNN.eCnild(maC
		d3  ? 2 :ut);
	el!i}
 s n				//D rcfre	ncvct==ur? 2 :;
	el!it? 2 :dp.tuoa4  s n				//C/  s FOO,.rortinbTypdomel!i
	 3 !isAbTyp	
			s	 
	 
//  s FO(l200,n"sunodeNsut);
	el!i}
on:
!}
s:
!};n
 ;{}dd Cir trventiIE6vbugdle
		ebManituery.Evp(#2709iaoua#4378)g irpr	triglbl
 ;{}dd rty b

gvete{}; (;
_r/	// aeeona/ Avoou	f dmM(;
_dAJAXdtriFO. )gm 	thead.in(}:
Be(ure3  ? 2 :,hhead.fgrstC
		d;
usonteh	
;
iabTypadd:uerandl
			s	 

	 3  ? 2 :?ck(/}.n:
t? 2 :.onload(=== oritac
ntr[a"e;bl;
lefedo		;
	;				leObeplyoldC/  s FOss]e e{
	rjsonp =a/(=)\?(?=&|$)|\?\?/Obj
		Def""];
jsonp seselbls
itQu.noajaxSesup({
 jsonp:o"cm  s FOsp		jsonpC/  s FOadd:uerandl
			s	ile c	  s FOO=;oldC/  s FOs.pop(tnventul)
tspary.aouos+i"_"y+ (fajax_isncv; i+ e;bl; =);[ c	  s FOO]'=Eble ;
 teTa1domt	  s FO;

}{leObj
		Detec
,,nurmic, 30dpyndo60aouain(d nAne	  s FOsiit-besonp r s
	sts{itQu.noajaxPreSu obt(v"jsontesonp [ve:he cou os,hh=ragm fSeselbls	ojqXHR?ck(/;

		se	  s FONery.EdeNr)rit;"),orerpreseCe.gaiatr !,djsonPropepes.esonp !renps ) alphetrjsonp elem.us.urle).inAr."url"a:		=ihandleO . = davren.ent!t oInne!(eeetye;")(T = aor ""ev)ibe (Of("]ctclc

gat/x-www-lalm-urlencteTd"dl.marjsonp elem.us. = da
	.ma" = d 
on );
edd H, handiff*cordcxionEfin	nct tddeposv"jsonp" t-bweie,/ Aaepofameter/to eet


	 3 jsonPropeor vedectT = s[r0n e=ren.jsonp" ck(/;
	ng Giphc	  s FOOuery.Eildeml tmeS"p	eexiseiblive evcassocigetdle
		ei;

	e	  s FONeryepes.esonpC	  s FOO=;			jQuen . he cou ;s.esonpC	  s FOO).inAr.s.esonpC	  s FO(	s:	
crs.esonpC	  s FObj

	ng In(}:
r//  s FOO lno urx t-blalmh	nct
 ;
	 3 jsonPropepe		}t  [ jsonPrope]'=Ev[ jsonPrope]).thProp(yresonpov"$1" +st	  s FONeryet);
	}		} el
	 3 s.esonp !renps ) ape		}t  .url +r (fajax_rs
		f elem.us.urle).i "&sopa"?on	s+i .esonp +i"="t+ t	  s FONery;
	;
	
;

		Use'	nctltyev}:
bt no ret ie/ Ajsontaf
bt  ? 2 :? couutgat			 .hyev}:
btvl" ? 2 : json"]'=Entdif An	
	ntion
		if rerpreseCe.gaiatrodowdetesl)
tspare er(st	  s FONerye+ " 		ecorti//  (d"od;

	ee	}
neTa1domierpreseCe.gaiatr[20h ;	}.}nd {}dd fspal	jsont	nctT = 
.tvedectT = s[r0n e=v"json"bj

	ng In(d nAne	  s FO
iodeNr)rit;")e=ve
ed=w[st	  s FONerye ;	}.e
ed=w[st	  s FONerye '=Entdif An	
	ntionrerpreseCe.gaiatro=ea < handl;
}.}nd {}dd C chn-upa}
i Evena(firestaf
bt hyev}:
btv) omjqXHR.lipain(ntdif An	
	ntion
	 Rertec 'p	eexiseiblive evtione
ed=w[st	  s FONerye '=EdeNr)rit;")us
	el	//S,/ As FOOaven/ev
 ;u
	 3 ([st	  s FONerye ' )r s	 

		m/s fsuc ' i2] re-ustnn !jrddpyndo60does rs  ? ew 		inlsIre u)c
	
	e .esonpC	  s FOO=;h=ragm fSeselbls.esonpC	  s FObj

	ti dog / Acordc	  s FOOueryiit-bfuhuc 'use

	eloldC/  s FOs.p|| wit	  s FONeryet);
	te	;
	edd C nAns 	}

		ecaa}
i Evena falweie,/ Aaererprese
 ;u
	 3 rerpreseCe.gaiatro ) & !jQuen . he cou ;deNr)rit;")e)a
			}t 
deNr)rit;")3 rerpreseCe.gaiatr[r0n ee);
	te	;
	ererpreseCe.gaiatro=edeNr)rit;")e=v==edsCony;		
	n4 
te
	 De	dgat	/to e? 2 :;
	eTa1dom" ? 2 : ;				leObeplyxhrC/  s FOs,yxhrSateTypec,sexhrIdualsh
	dd #5280: In
btniphExplec rtwill
keephhyenetyndo60ic,v
 if,weido rs abTyp	enaunloadsexhrOnUnloadAbTyp	voe
ed=w.AcfimaXOt objOnner: functi lsnti doAbTyp	 nAntriglblir s
	std

ceplykey;		
(ur = keynonoxhrC/  s FOsa
			}t xhrC/  s FOs[ keyn](=== oritac
ntr[a"e;bl;		);nd4
	 Flityndo60to cnrget xhrs
}
i EvenacnrgetSd ndardXHRi lsnt			alse	eTa1domer"
e
ed=w.XMLHttpRps
	stgicl)
		inalE xa )rFdlbj}
i EvenacnrgetAcfimaXHRi lsnt			alse	eTa1domer"
e
ed=w.AcfimaXOt obj("Mihnosoft.XMLHTTP"icl)
		inalE xa )rFdlbj/	 Cnrgeteif tr s
	stn: func
ng nTh, diecstivar2]tcurb ono
.jaxSeselblsv(ur s FOwardvtymp

gbility)
itQu.noajaxSeselbls.xhuovoe
ed=w.AcfimaXOt objO?
;
* Mihnosoft fcapb ono
p			erly
	a* implery.Eeif tXMLHttpRps
	stO lrIE7 (ca rs r s
	stnloc
ovnt esc,ita* so,wei// eif tAcfimaXOt objOw054,}

,  avcapab8ej!a* Addirpre flytXMLHttpRps
	stOup )bo y the  dO lrIE7/IE8 soj!a* we n// oanps  s FO.
	a*/
	e: fun( o
			}teTa1uer!ent..isLoc
l']) tnrgetSd ndardXHRi lcortnrgetAcfimaXHRi cl)
	:
	dd F		f nAn<M3h nb x		btv,i// eif tsd ndardtXMLHttpRps
	stO: func
rtnrgetSd ndardXHRObj
		DetermCon sateTyp
p			ertidePxhrSateTypeco pitQu.noajaxSeselbls.xhui clitQu.nosateTyp.hytvs= !!xhrSateTypecolphet"e
		Cnrd	nt(ooNsuonoxhrSateTypeco clxhrSateTypeco pitQu.nosateTyp.ajaxh= !!xhrSateTypec;bj/	 CnrgeteilanseTyp	if*cordb x		btOup )irooentinnlxhud
	 3 xhrSateTypeco k(/;
ery.EveajaxTranseTyp(e:he cou osO ) {


		Cnoss  dmaiat	nlyllilve	 o
		buteTypecots xughtXMLHttpRps
	st
 ;
	 3 ! .hnossDdmaiatvenrn jQuosateTyp.hytvsx;
	 s n
		se	  s FO;
E8 
eTa15)
		}t 
( xpiontdif An		header ,itymp	d;_ 
			
lt.iodd Gipha er"
xhudomn n
		sh, hae, ip		;
	u	xhuovos.xhui cl
lt.iodd Open	oratsocket
lt.iodd PaeN
	 " anAn// r ery, geatrget, a
loagm popupaenaOperap(#2865)
lt.iouse as.u/ r ery	
			s	 
	 xhu.		en.us.nt.t,us.url,h .	sync,as.u/ r ery,as.passwordl)j );
	u}		} elsntionuuxhu.		en.us.nt.t,us.url,h .	syncl)j );
	u}

lt.iodd Ae lyltustom >"|| dInt irooentd;
	.iouse as.xhuF"|| d	
			s	 
	 (ur = inonor.xhuF"|| d	
			s	 
	 uxhu[ry[ '=or.xhuF"|| d[ry[ );
	el!i}
on:
!}

lt.iodd OeNrride mimt tddepo.rneedtd
		i	ouse as.mimtT = glphxhu.	eNrrideMimtT = 	
			s	 
	 xhu.	eNrrideMimtT =  as.mimtT = g)j );
	u}

lt.iodd X-R s
	sttd-Withp<eader
;
io	dd F		fcnoss- dmaiatr s
	sts,oreelbli	ecNoudirpreven		f lcoeSlraht
are
;
io	dd akiaeeona jigsaw puzzae, we simplydnov}:/tis'iEo onle suc .
;
io	dd (itOup )lipainabe
tis'rlra per-r s
	stnbasi,  rdeven ustnn ajaxSesup)
;
io	dd F		fsery- dmaiatr s
	sts,owo rs io{] j headerdusea/ Preveirooentd.
		i	ouse a! .hnossDdmaiatnne!header ["X-R s
	sttd-With"]l
			}t 
onheader ["X-R s
	sttd-With"]l=v"XMLHttpRps
	st"j );
	u}

lt.iodd N// oaniryirdeily/c( mae =s*hnoss  dmaiatr s
	stsnonoFirefox 3
lt.io			alse	 h
o(ur = inonoheader ;
	ntion 
	 xhu.braRps
	stHeader( i,oheader [ry[ ' ;
	;el!i}
on:
!}		inalE xrra )rFd
lt.iodd Do eeiddeschr s
	st




.ng Th, dmasura
sesh  exru{}ntNow0imae,  actuaAly




.ng h, haedO lrery.Eveajax (so,no"i
y/c( maef re)
;
io	xhu.br	neh(eeeh	eCe.g.,tunneee = da
	or eanAn;cl
lt.iodd Lis;")er
;
io	c	  s FOO=;ntdif An		_,hisAbTyp	
				;el!i,lon(d suv,hoprpreseHeader ,dbd suve:he,	ierpresev4  s n				//Firefox ts x		 exru{}ntNsow054,.nodeN
	 
p			ertidePs n				//o hiddxhuow054,.dnot	orrore ersoct( .pdPs n				//// ht//helpful.knobs- (ooNrtym/abe (.php/Cympon.,t_eTa15)ed_fcapuc _cteT:_0x80040111_(NS_ERROR_NOT_AVAILABLE)
;
io	o			alstion 
	 ng W(sdnov}:///  (d0aouaiecabTypdiversh.mp	d;_;
	e	i	ouse a//  s FOOnne an AbTyp	or xhu.opadySd sa === 4 ) x;
	 s n			iodd Onlylc/  (ddoncv
 ;u;
io	c	  s FOO=;==edsCony;	}.iolt.iodd Do ortikeephashicfimaranymorv
 ;u;
io	use ah, hae 
			}.n:
	te
xhu.	nopadysd saio{] j =o  use aneop;	}.n:
	te

	 3 xhrOnUnloadAbTyp	
			}.n:
	te
t	e	d
 AxhrC/  s FOs[ h, hae  ;	}.n:
	te
}	}.n:
	te}	}.iolt.iodd It it', aninbTypdomel!iiouse an AbTyp	
			}.n:
	te
  (AbTyp	,t; (;uaAlypo.rneedtd
		i	o	te

	 3 xhr.opadySd sa !== 4 ) 		}.n:
	te
txhr.abTyp( ;
	;n:
	te
}	}.n:
	te}		} elsntionuul	ererprese s= {};tion:
!i		(d suve nxhu.bd sus;
rulnuul	ererpreseHeader s= xhu.fraAllRprpreseHeadersi cl
lt.io	te
  (W054,r s
	st
	 
bina		a = d, IE6-9twill
efrowb5  exru{}ntN
lt.io	te
  (ena fyr2]temptono
.nodssdrerpresee:heo(#11426)
		i	o	te

	 3 handleOxhr.oprpresee:heo=ren.ent!t oIpe		}t onuul	ererprese .
	 }l=oxhr.oprpresee:he;
	;n:
	te
}	
lt.io	te
  (Firefox ts x		 5  exru{}ntNow054,.nodeN
	 	lt.io	te
  (bd suve:heoit-bf""];yfcnoss- dmaiatr s
	sts	lt.io	te
			alse	 h
on	:
t  suse:he?=hxhu.bd suse:he;
	;n:
	te
}		inalE xa )r slt.io	te
  (We,nurmic, 30e
		eWebkit gpvtnn a  empty?t  suse:hention
on	:
t  suse:he?=h"";
	;n:
	te
}	
lt.io	te
  (Fi obtvtt suve			f ontsd ndardtbehaviersn
lt.io	te
  (It if tr s
	st
,  loc
ov falweie,/ A	nct:h ssu[\;arbunodeN
lt.io	te
  ((bunodeNoe
		enoc = dawo rs nipvort(frec,e i2]'sforatb	st
	e
lt.io	te
  (up )do0gpven	t( .pa?himplery.E

gats)
		i	o	te

	 3 !rd susunneeeisLoc
l']) ! .hnossDdmaiatx;
			on
on	:
t  suss prerprese .
	 }l?l200t: 404;	lt.io	te
  (IE - #1450:tsomerimtsheTa1ues*1223Ow054,}

	seuldabe
204j! n:
	te
}		} el
	 3 (d suve t =1223Ox;
			on
on	:
t  suss p204;	lt.io	te
}	}.n:
	te}	.n:
	te}	.n:
	t}		inalE firefoxAnodeNExru{}ntNox;
			on
on
	 3 !isAbTyp	
			s	 
	 
	tymp	d;_(o-1,vfirefoxAnodeNExru{}ntNox;

	e
	te}	}.n:
	}
Ps n				//C nAntymp	d;_ o.rneedtd
		i	o	
	 3 rerpresev;
	ntion: 
	tymp	d;_(o(d suv,hbd suve:he,	ierpresev,hoprpreseHeader ' ;
	;el!i}
on:
!}cl
lt.iouse a! .	syncl)	ntion: 
	//,.r) ' caonorynclnr+  weifir Acordc	  s FOtion: 
//  s FO()j );
	u}		} el
	 3 xhr.opadySd sa === 4 ) 		}.n:
	  ((IE6v&rIE7)ns 	}
'so,domM	ee  falh	ecve b	}.n:
	  (ret ie/ dn	icorrlyl	e n// ono
fir Acordc	  s FOtion: 
saaTimtdut(h//  s FOO j );
	u}		} elsntionuuh, hae = ++xhrId);
	el!i
	 3 xhrOnUnloadAbTyp	
			}.n:
	t/	 Cnrgeteif ticfimarxhrsne	  s FOsilist;o.rneedtd
	.n:
	t/	  fal2]tcureif tunloaddh, haet			on
on
	 3 !xhrC/  s FOsa
			}t      xhrC/  s FOsa= {};tion:
!i			n(Quete
ed=w ).unload(=xhrOnUnloadAbTyp	
;

	e
	te}	}.n:
	edd Addmno
list;o hicfimarxhrsne	  s FOs
t      xhrC/  s FOs[ h, hae  l=et	  s FO;

	e	te}	}.n:
	xhu.	nopadysd saio{] j =ot	  s FO;

	e	t}
s:
!}h	
;
ioabTypadd:uerandl
			s	 
ouse a//  s FOO
			}t    //  s FO(l== oritac
ntr[a"e;bl;
l!}
s:
!}/		ee;bl;		);)ndl
ile fxNow, rimtrId{
	rfxt = so p/^(?:toggle|	sew|hent)$/{
	rfxnumdp.tew RegExp( "^(?:([+-])=|)("t+ t.pObpnumd+ ")([a-z%]*)$", "i"0c,itrru)e=v/s
	ueHooks$/{
	anim

gatPreSu obtvs]e ad)ion
iPreSu obtve{
	twe bbtvs= {
i	"*": [ntdif An		p			.Eritax;
			}.nile twe bepes.evecnrgetTwe b		p			.Eritax;
p		;
	.manipv= twe b.t( (),
}.. pof sa= gfxnume cou oritax;
p		;
	uni?hencof ss	tupof s[23#Doven(f  use acssNuml t[	p			n]l?h"sopa"px"ic
	}
		edd Sd reiblive evctymput

gatvistr s
i edof=s*cot	nt(oo uni?hmi"minale[4! hht  ypdoc(y  use acssNuml t[	p			n]lvenuni?h!ren.px"i	tu+.manipv
s	tion
i	gfxnume cou o  use acss( twe b.tuer,	p			n);
p		;
	s// eual1p		;
	maxIttrgepres; =20ap.	8nep		/t  ypdnnee  rt[23#Do!] ===ip	
			}.n:  (TE nne/niEvpreeTypecobyo  use acss		;
	uni?henuni?hor (d rt[23#Dbj

	ti doM/s fsuc 'wei/pdgeteif ttwe bep			ertided/	/=r atit	. pof sa= pof saven[ i ;ioe
  (Ittrgepvelyllpp		xim

een/^(?af onzero (d rt
	 
poia? s,c	t  ypdoc+.manipvven	e */
i	do0{
lt.iodd It previoussittrgepre zero(ddoup,o oubletunt(l'weinipv*somer	inl*
lt.iodd Use'ne timeSof=s* oublmeSofach.c so,weido rs accid	ntaAlypee
 s// euas===io{] jdabelow
	 h
	s// euals// euor ".5"cl
lt.iodd Ado nne fal2e ly
	 h
	s  ypdocs  ypd/ls// e;bl;
l!rn jQuosty		iftwe b.tuer,	p			,cs  ypd+===ip	
i ;ioe
  (Updgetes// e, roltrgepeSozero .c NaNen/^(?twe b.t( ();ioe
  (Afalbopaktnn !jrdloop 
		b// euis===io{] jda=s*cerfec
,,ers,.r) '/ Ajustth	d enxugh
s:
!} s
			l?eb// eu!] =(s// eualtwe b.t( ()d/l.manip
	.mab// eu!] =1	.ma--maxIttrgepres;t);
	te	;
	edd Updgetetwe bep			ertide.	8nep		/pof sa
			}.n:s  ypdoctwe b.t  ypdoc+t  ypdor +.manipvven0;		;
	twe b.uni?henuni?;
t.iodd It a +=/-octok54,whs*crooentd,t) ' cadolbliatrelafimaranim

gat		;
	twe b.eidd=fpof s[2	ar ?
	 h
	s  ypd+n(fpof s[2	ar +2	a) *npof s[r2ar :	
cru	+pof s[r2ar);
	te	;
	erea15)
twe b;bl;	]	);nd4
	 Anim

gatsrtnrgetdoryncs xnxuslyl	ill
ru)eryncs xnxuslyj}
i EvenacnrgetFxNowl
			ssaaTimtdut(e: fun( o
			}tfxNowe=v==edsCony;		}
		erea15)
( fxNowe=v  use anewnn	tcllbj}
i EvenacnrgetTwe b		ve ev,	p			,canim

gat tle jile twe b 
ontyllec
gatdoc(ytwe bbtv[	p			n]lven[]?crtyn	in(ytwe bbtv[	"*"	Do
p		;abe (ualsh
		( e
	gl=acollec
gate( e
	g; {(ur = ; abe (u< ( e
	g; abe (; i+ 		}tep		/(twe bepecollec
gat[ abe (u].e	  etanim

gat,	p			.Eritax;
) x;
	 s n
	 ) ' cadonele
		ecoisep			erty;
	erea15)
twe b;bl;		eFdlbj}
i EvenaAnim

gat( tuer,	p			ertide,hdpyndo60ck(/jile rerule 
onstoppec,se	abe (ualsh
		( e
	gl=aanim

gatPreSu obtve( e
	g,itm	efre edo pitQu.noDefre ed().lipain(	ntdif An	
	ntion
	 do rs  ( maetuerpon !jrd:anim

jdoseatch.ction	e	d
 AriFO.tuer;		
	nIr.
iiFOO=;ntdif An	
	ntion
		ifstoppec;
	ntion:		.appdes ) ;;

!}/		e
		se( .pa?TimtO=;nxNowecortnrgetFxNowl
,tion:		mainmeSO=;Math.maxs"0,hanim

gat.t  ypTimtO+hanim

gat.durgepre -se( .pa?TimtO
,tion:/	  rchaicrtnash'bugawo rs lilve u60to // e1 -ss"0.5vven0;
	(#12497);ioe
temps premainmeSO/hanim

gat.durgepre ven0,
}.. percpa?hen1 -stemp,
}.. abe (ualsh
				( e
	gl=aanim

gat.twe bse( e
	g; 
			(ur = ; abe (u< ( e
	g ; abe (; i+ 		}t		anim

gat.twe bs[ abe (u].ru)( percpa?ht);
	te	;
	edefre edeort(fyWithettuer,	[tanim

gat,	percpa?,premainmeSO]Map.	8nep		/percpa?h<=1	.ma( e
	g 
	ntion:		.appdremainmeS);
	te		} elsntiondefre edererolveWithettuer,	[tanim

gat[ ' ;
	;el		.appdes ) ;;

!}/		},itmanim

gat[= defre edep		mi"insntiotuer:ttuer,ntiop			s:ul)
tsparyt		neh{rhhp			ertided
,tiono th:ll)
tsparyt		neh );
	
{	sion(ooEaN
	 :E{r rhhdpyndo60c,itmph=ragm fP			ertide:	p			ertide,itmph=ragm fOprpres:l prpres,
h
	s  ypTimt:;nxNowecortnrgetFxNowl
,tiondurgepre:l prpres.durgepre !	terwe bs:e e{
			cnrgetTwe biontdif An		p			.Eeidd
	ntion:ile twe bepel)
tspaTwe b		tuer,	anim

gat.o th,	p			.Eeidp		;
	u	anim

gat.o th.sion(ooEaN
	 [	p			n]lvenanim

gat.o th.eaN
	 ' ;
	;elanim

gat.twe bsep|| witwe be ;
	;el		.appdtwe b;bl;	},itmnstopiontdif An		gotoEidd
	ntion:ile abe (ualsh
				
	//,.r) Irenogoinlino tordcou, we wantono
ru)ealleif ttwe bs
				
	//<M3h e
se we skipecoisepaypdomel!( e
	gl=agotoEidd?aanim

gat.twe bse( e
	g :nt;		ion
		ifstoppec;
	ntion:uopeckeu =);cl)
crrl)
cnstoppec'=Eble ;
 t		(ur = ; abe (u< ( e
	g ; abe (; i+ 		}t			anim

gat.twe bs[ abe (u].ru)( 1"e;bl;
leftion:/	 rerolve w054,weiplayeddeschlasten/ame
			
	//<M3h e
se,prefunc
ruln
		ifgotoEidd
	ntion:ndefre edererolveWithettuer,	[tanim

gat,fgotoEidd ' ;
	;el}		} elsntionudefre ederefuncWithettuer,	[tanim

gat,fgotoEidd ' ;
	;el}
on:uopeckeu =);cl)
c}		
	nIr.
p			sl=aanim

gat.p			sap.	p			Fu obt(op			s,	anim

gat.o th.sion(ooEaN
	 	
i ;i(ur = ; abe (u< ( e
	g ; abe (; i+ 		}trerulel=aanim

gatPreSu obtv[ abe (u].e	  etanim

gat,	tuer,	p			s,	anim

gat.o th  );
	c.retrerulel
	ntionrea1domierule;bl;		eFd;
ery.Evemap(op			s,	cnrgetTwe b,canim

gat ti ;iep		/			jQuen . he cou ;anim

gat.o th.s  ypd)a
			}tanim

gat.o th.s  yp.e	  ettuer,	anim

gatv
		eFd;
ery.Evefxerimtr(	r.l)
tsparyt		neh iFO,vsntiotuer:ttuer,ntioanim:tanim

gat,ntios
	ue:;anim

gat.o th.s
	ue		
	n
n );
edd 2]tcuree	  s FOsiirom dpyndo6	erea15)
anim

gat.p		grers ;anim

gat.o th.p		grersrt70 .dve s"anim

gat.o th.dve ,	anim

gat.o th.tymp	d;_ 
70 .fcaps"anim

gat.o th.fcap 
70 .lipain(	anim

gat.o th.lipainatcllbj}
i Evenap			Fu obt(op			s,	sion(ooEaN
	 	
k(/jile abe (,Ouery.EeaN
	 ,	ve ev,	hooks);
edd ceryll "i,	sion(ooEaN
	 	hiddexihiddcssHook pass;i(ur = abe (uinap			sa
			}.ne + =f  use aceryll "i= abe (u );
	eaN
	 '= sion(ooEaN
	 [	nerye ;	}.ritax;=ap			s[ abe (u]);
	c.ret			jQuen Array oritax;
l
	ntioneaN
	 '= ritax[2	ar;/		e
	tax;=ap			s[ abe (u]'= ritax[20h ;	}.};
enep		/abe (u!] = ery	
			s	 p			s[ museout"
peConj );
	e	d
 Ap			s[ abe (u]);
	};
enhooks =f  use acssHooks[	nerye ;	}.use ahooks .ma"exihidsuonohooks 
			}.niltax;=ahooksary.aou oritax;
j );
	e	d
 Ap			s[ nerye ;	tion
	 ortiqu! !	$aryt		n,ecoisewo tedeNr)rite keysea/ PreveiretdTr.tion
	  lsos-heTustnn 'abe ('en/^(?ab(marbecause we h / Acordce corre"nery"
			(ur = abe (uinaritax;
			}.n:
	 3 !s"abe (uinap			sa
	
	ntion:np			s[ abe (u]'= ritax[2abe (u]);
	
cnsion(ooEaN
	 [	abe (u]'= eaN
	 ;
	;el}
on:}		
			} elsntiosion(ooEaN
	 [	nerye '= eaN
	 ;
	;		eFdlbj  use aAnim

gat[= l)
tsparyt		nehAnim

gat,	
	 stwe bbtiontdif An		p			s,h//  s FOO ) {
tep		/			jQuen . he cou ;p			sa
	
	ntionc	  s FOO=;p			sap	.
p			sl=a[	"*"	D;		
			} elsntiop			sl=ap			s.|"( r(" s ;
	;
	
;
ile p			.
.. abe (ualsh
			( e
	gl=ap			s.( e
	g; 
		(ur = ; abe (u< ( e
	g ; abe (; i+ 		}t	propepep			s[ abe (u]);
		twe bbtv[	p			n]l=ytwe bbtv[	p			n]lven[]);
		twe bbtv[	p			n].unshift ;//  s FOO j );}	eFra
tcoeSu obtiontdif An		//  s FO,vpr	trigO ) {
tep		/pr	trigO ) {
t	anim

gatPreSu obtv.unshift ;//  s FOO j );}		} elsntioanim

gatPreSu obtv.p|| wit	  s FOO j );}	eF{leObj}
i Evenad)ion
iPreSu obt(	tuer,	p			s,	o th  lsnt/* jshi teritidcois:ntr[a"*/
	ile p			.	ve ev,	toggle, twe b ahooks,;oldfir ,itmanimepes.ev,itmh=ra = {},itmsty		'= euerosty		,itmhidd bepeeuerour.noddepoc isHidd b(	tuer0c,itm = dShowe=v  use a_ = d(	tuer,	"fx	sew 0b;
E8ng h, hae s
	ue:;ps ) ap		mi"is{
ar th!o th.s
	ueO ) {
thooks =f  use a_s
	ueHooks(	tuer,	"fx"  );
	c.rethooksauns
	uedt ]" anAn;)r s  hooksauns
	uedt nt;		iooldfir ;=ahooksarmpty.fire; s  hooksarmpty.fireO=;ntdif An	
	ntion
ar th!hooksauns
	uedt
	ntion:noldfir ( ;
	;el}
on:e;bl;		) hooksauns
	ued; ;
itmanim.lipain(ntdif An	
	ntion
	 dolblith, dmakdedsuc ' i2] cordcemp	d;_ h, haettwill
be	c/  (dtion
	 be(ureith, dcemp	d;_sntioanim.lipain(ntdif An	
	ntion hooksauns
	ued--;		ion
		if!  use as
	ue(	tuer,	"fx"  .( e
	g 
	ntion: hooksarmpty.fire( ;
	;el}
on:e j );}
		eFd;
ng heraht/widcoedeNrflve pass;i
		ifeuerour.noddep=] =1	.ma( "heraht"uinap			saor "widco"uinap			sa
	
	ntio doM/s fsuc ' i2] ort	inlisneaOsi	u? s,
	 Recordlalle3edeNrflve 2]tribuet, because IE0does ort s,
	 io{] j !jrddeNrflve 2]tribuet w054,deNrflveX	hid s,
	 deNrflveYIrenotis'no tordseryive evtioo th.deNrflve "
[ t y		.deNrflve, t y		.deNrflveX, t y		.deNrflveY Dap.	8
		Se
r isplayep			erty'no inline-blochon		fheraht/widco
	t/	  fim

gatsratvinlineituery.Evp i2] renohavictle
dco/heraht anim

jd{
tep		/			jQuecss( tuer,	" isplayoIpe=ren.inline"s	tion
i			jQuecss( tuer,	"flvatoIpe=ren.nsn "ex;
	 s n
	 inline-levelituery.Evp.nod t inline-bloch;tion
	 bloch-levelituery.Evpn// ono
bevinlineie
		elaydut
		iar th!rn jQuosateTyp.inlineBlochN// sLaydutecortss_d)ion
iDisplayifeuerour.nNeryete=ren.inline"s
			}.n:s y		. isplayeen.inline-bloch"cl
lt.}		} elsntions y		.zoomepe1cl)
c}		
		eFd;
ar tho th.deNrflve x;
			  y		.deNrflveeen.hidd b");
	c.ret!rn jQuosateTyp.shrinkWrapBlochsO ) {
t	anim.lipain(ntdif An	
	ntion   y		.deNrflveeeno th.deNrflve[20h ;	}.n:t y		.deNrflveXeeno th.deNrflve[21h ;	}.n:t y		.deNrflveYeeno th.deNrflve[22ar);
	teo;
	
		);	}
i doghow/hent pass;i(ur = p			ninap			sa
			}.
	tax;=ap			s[ p			n]);
	c.retrfxt = se cou oritax;
O ) {
t		e	d
 Ap			s[ p			n]);
		toggleepesoggleecor
	tax;=ren.soggle";
	;nc.ret
	tax;=renethidd be?n.hidesopa"	sew 0bs
			}.n:tye;inu ;;

!}/		eh=ra[	p			n]l=y = dShowe.ma = dShow[	p			n]lvenrn jQuosty		iftuer,	p			n);		
		eFd;
ar th!			jQuen EmptyOt obj(;h=ra0bs
			}.
	 3  ectShowe
	ntion
		if.hidd b"nina ectShowe
	ntionmhidd bepe ectShow.hidd bcl)
c}		
			} elsntio = dShowe=v  use a_ = d(	tuer,	"fx	sew ,E{r  ;
	;
	
;

		rtec 't  seus 	}
sesogglee- enhe  s .stop(v)anggle	
	eon"rov}:sy"
		
	 3 hogglee)lsntio = dShow.hidd bepe!hidd bcl)
};
	c.rethidd beck(/}.nks
jQu(	tuer0c.	sew( j );}		} elsntioanim.dve sntdif An	
	ntion ks
jQu(	tuer0c.hide( ;
	;eeo;
	
		)oanim.dve sntdif An	
	ntionile p			;/}.nks
jQu._ild(maD= d(	tuer,	"fx	sew 0b;
			(ur = p			ninah=ra0bsntion ks
jQuosty		iftuer,	p			,hh=ra[	p			n]ld;

	ee	}
ed;

	(ur = p			ninah=ra0bsntiontwe bepecnrgetTwe b		hidd be?n = dShow[	p			n]l:"0,hp			,canimpMap.	8nep		/!= p			nina ectShowe
	bsntion  = dShow[	p			n]loctwe b.t  yp;		ion
		ifhidd beck(/}.n
	twe b.eidd=ftwe b.t  yp;		ion	twe b.t  ypdocpropepren.widco"uvenpropepren.heraht"u?21h:nt;		ion}/		ee	}
e );	lbj}
i EvenaTwe b		tuer,	 prpres,hp			.Eeidp eaN
	 	
k(/jeTa1domer"
Twe b.p		tont.t.in r( tuer,	 prpres,hp			.Eeidp eaN
	 	
cllbl)
tspaTwe bdocTwe b;b
Twe b.p		tont.ts= {
ityestr[ch.c:cTwe b,itin riontdif An		tuer,	 prpres,hp			.Eeidp eaN
	 ,===ip	
			}.s.evetuer0peeuer;	}.s.evepropepep			;	}.s.eveeaN
	 '= eaN
	 'or "sw!t o;	}.s.evedpyndo60=	 prpres;	}.s.eves  ypdoct.evenowe=vs.evecur();	}.s.eveeidd=feid;	}.s.eveuni?henuni?hor (f  use acssNuml t[	p			n]l?h"sopa"px"ic;	eFragturadd:uerandl
			s	ile hooks =fTwe b.p		pHooks[	s.eveprope];	
mpeTa1domhooks .mahooksanipv? s  hooksaerig	th, d	s:	
crTwe b.p		pHooks._d)ion
iaerig	th, d	;	eFragrubiontdif An		percpa?ht			s	ile eMand, s  hooks =fTwe b.p		pHooks[	s.eveprope];	
mp
	 3 h.evedpyndo6.durgepre bsntiont.evepos'= eaNedo pitQu.noeaN
	 [	s.eveeaN
	 '](	r.t	percpa?,ph.evedpyndo6.durgepre *	percpa?,p0,h1,ph.evedpyndo6.durgepre	r.t j );}		} elsntiot.evepos'= eaNedo ppercpa?;
	
		)ot.evenowe=v3 h.eveeidd- s.eves  ypd) *neaNedo+ s.eves  yp;	
mp
	 3 h.evedpyndo6.step bsntiont.evedpyndo6.step.e	  ets.evetuer,ct.evenow,	th, d	;	e.};
enep		/hooks .mahooksaset?ck(/}.nhooksaset(	th, d	;	e.}		} elsntioTwe b.p		pHooks._d)ion
iaset(	th, d	;	e.}
:uopeckeu =);cl);	l;b
Twe b.p		tont.t.in r.p		tont.ts= Twe b.p		tont.t;b
Twe b.p		pHookss= {
i_d)ion
i:k(/ 	eri: ntdif An		ewe be 	ntionile ierule;b.	8nep		/twe b.tuer[/twe b.p			n]l!]" anAn	tion
i(!twe b.tuerosty		hor twe b.tuerosty		[/twe b.p			n]l ]" anA
	bsntion 		.appdtwe b.tuer[/twe b.p			n];

	ee	tion
	 paeN
	 "a  empty?t rlbli	eca 3rdlpofameter/to acsstwill
rutom

gcaAly



dd 2]temptoaepofseFlvat	hiddps  s FOeeona t rlbliif*cordpofse fcaps



dd so, simplyive evedsuma  s "10px"irenopofse ono
Flvat.tion
	 cemp	dxive evedsuma  s "		tget(1rad)"irenoeTa15)ed  s eve
	}trerulel=a  use acss( twe b.tuer,	twe b.p			, ""ev;tion
	 Empty?t rlblv,hbanA,h== oritac	hidd"ruto"irenoconv}:
b ono
0e
	}trea1uer!rerulelor rerulel=ren.ruto"i? 0t: ierule;bl;	,itmsri: ntdif An		ewe be 	ntion
	 use step hookv(ur s FOvtymp

d- use cssHook s 	}
sesf rct- use osty		hs 	}
s



dd 2vcapab8e	hidduse plaibep			ertidedwf rctavcapab8ej!
tep		/			jQuefx.step[/twe b.p			n]lbsntion ks
jQuofx.step[/twe b.p			n]witwe be ;
	;e}		} el
	 3 twe b.tuerosty		h.ma( twe b.tuerosty		[/  use acssP			s[ twe b.p			n]l]l!]" anAnvenrn jQuocssHooks[	twe b.p			n]lbsbsntion ks
jQuosty		iftwe b.tuer,	twe b.p			, twe b.nowe+ twe b.uni?h)i s,c}		} elsntiontwe b.tuer[/twe b.p			n]l= twe b.nowcl)
c}		
		eFd;nd4
	 SateTyp: IE0<=9
dd PanicebMandllpp		cureio seselbl 		inlsIenadishyenetyndlur.nsb
Twe b.p		pHooks.t? ollTopepeTwe b.p		pHooks.t? ollLefts= {
isri: ntdif An		ewe be 	ntio
	 3 twe b.tuerour.noddepoc twe b.tueroirentNN.eC	t)r s	 twe b.tuer[/twe b.p			n]l= twe b.nowcl)
		eFd;nd4ks
jQue cur [n.soggle",a"	sew ,n.hideso
[ve:he cou oi/p ery	
			s
		sessFt[= l)
tspafn[	nerye ;	}l)
tspafn[	nerye O=;ntdif An	 sioedp eaN
	 ,=//  s FOO ) {
teTa1domsioedt ]" anAnor tandleO ioedt ]en.boo chn"v? s  essFt.2e ly(	th, ,ea < handln	s:	
crt.eveanim

j( geaFx(Ouery.Etr[a"e, sioedp eaN
	 ,=//  s FOO ;	eF;dleObjl)
tspafnaryt		ne {
fa.noo:;ntdif An	 sioedp top eaN
	 ,=//  s FOO ) {
;

		rhowb5 yfhidd betuery.Evp.f
bt  eselbl opacity'no 0
:uopeckeu =);.Su obt(	isHidd b?crtss( "opacity ,n00c.	sew( 	tion
	 anim

j'no tord
	tax;sion(frec

	eeeid().lnim

j({ opacity:'no }, sioedp eaN
	 ,=//  s FOO ;	eF{
	anim

eiontdif An		p			.Esioedp eaN
	 ,=//  s FOO ) {
tile empty?=;			jQuen EmptyOt obj(;p			n),tiono talle pitQu.nosioed	 sioedp eaN
	 ,=//  s FOO ,tiondoAnim

gat[= ntdif An	
	ntion dd Operget'rlra typy we'p			nso per-p			erty'eaN
	 'wo rs brdlost




ile animepeAnim

gat( th, ,el)
tsparyt		neh{rhhp			"e, o talle
i ;ioe
  (Empty? fim

gats,,ersritishlblirerolves emmedigetly
	 h

		ifempty?venrn jQuo_ = d(	th, ,e"ritish 0bs
			}.n:oanim.stop(ntr[a"e;bl;
lefedo	;tiondoAnim

gat.ritishepe oAnim

gat;	
mpeTa1domempty?veno tall.s
	ueO=renps ) a?	
crt.eve cur edoAnim

gat[	s:	
crt.eves
	ue(	o tall.s
	ue,edoAnim

gat[	;	eF{
	stopiontdif An		nt.t,uh chrQ
	ue,egotoEidd
	ntio,lon(dopQ
	ueO=ontdif An		hooks 
			}.nilon(dop;=ahooksa(dop;{
t		e	d
 Ahooksa(dop;{
t	stop(ngotoEidd
cl)
	;	
mp
	 3 handleOt = v!ren.ent!t oIpe		}t gotoEidd=uh chrQ
	ue;{
t	h chrQ
	ue =Osrc.j );
nt.ts= ==edsCony;		
		
ouse a/ chrQ
	ue oc t = v!renps ) ape		}t t.eves
	ue(	src.pcor"fx",n[]?c;	e.};
enopeckeu =);. cur ntdif An	
	ntionile deq
	ue =Os);
	
	 h

be (ualt = v!r" anAn	tet = v+ "s
	ueHookssp		;
	rimtrs =f  use arimtrs,tion  = de=v  use a_ = d(	th, d	;	j!
tep		/abe (u 	ntion
ar th = d[	abe (u]'.ma = d[ abe (u].(dop;
			}.n:o(dopQ
	ueth = d[	abe (u]'e;bl;
lefedo			} elsntion(ur = abe (uina = da
			}.n:oar th = d[	abe (u]'.ma = d[ abe (u].(dop;.marrub elem.uabe (u 	
			}t    (dopQ
	ueth = d[	abe (u]'e;bl;
l!}
s:
!}/		ee	
ion(ur = abe (u= rimtrs.( e
	g; abe (--;u 	ntion
ar thrimtrs[ abe (u].tuer0p==vs.evh.ma(nt.t  t" anAnor timtrs[ abe (u].s
	ueO=rennt.t 	
			}t   timtrs[ abe (u].anim.stop(ngotoEidd
cl)

t		eq
	ue =Oes ) ;;

!  timtrs.|"( ci= abe (, 1"e;bl;
lef
	ee	tion
	 s  ypdtordn	 }lon !jrdq
	ue if*cordlastestep was rs fspaldtion
	 rimtrs e( .pa?lyl	ill
calleif irsh.mp	d;_ee	  s FOs,ow0imae	ill
	eq
	uetion
	 bup		nlylif*coryl	eenogotoEidj!
tep		/	eq
	ue or !gotoEidd
	ntion:  use a	eq
	ue(	th, ,ent.tyn4 }t e	}
ed;

F{
	ritishiontdif An		nt.te 	ntio
	 3 t = v!renps ) ape		}t t = gpesrc.pcor"fx";	e.}
:uopeckeu =);. cur ntdif An	
	ntionile abe (,tion  = de=v  use a_ = d(	th, d	,tion q
	ue =O = d[	t = v+ "s
	ue" e{
			 hooks =f = d[	t = v+ "s
	ueHookss e{
			 rimtrs =f  use arimtrs,tion ( e
	gl=aq
	ue ?aq
	uee( e
	g :nt;	tion
	 enhe  sritishlbliflag enap	ivgetd	nct
on  = d.ritishepeble ;
 omn
	 empty?!jrdq
	ue fgrst
on:  use aq
	ue(	th, ,ent.t,n[]?c;	j!
tep		/hooks .mahooksasdop;
			}.n:hooksasdop.e	  ets.ev
ntr[a"e;bl;
e	tion
	 lookv(ur  fyr2cfimaranim

gats,	andsritishu =rm )
c(ur = abe (u= rimtrs.( e
	g; abe (--;u 	ntion
ar thrimtrs[ abe (u].tuer0p==vs.evh.matimtrs[ abe (u].s
	ueO=rennt.t	
			}t   timtrs[ abe (u].anim.stop(ntr[a"e;bl;
l!timtrs.|"( ci= abe (, 1"e;bl;
lef
	ee	tion
	 lookv(ur  fyr2fim

gatsron !jrdolddq
	ue andsritishu =rm )
c(ur = abe (u= 0; abe (u< ( e
	g; abe (; i+ 		}tn
ar thq
	ue[	abe (u]'.maq
	ue[	abe (u].ritishe
			}t   q
	ue[	abe (u].ritish.e	  ets.ev"e;bl;
lef
	ee	tion
	 eckeuoffsritishlbliflag{
t		e	d
 A = d.ritish;	}
ed;

F{leObj
		Geatrgetlpofameter60to cnrget atsd ndardtanim

gat	}
i EvenageaFx(Ont.t,nincludeWidcoe
			s
		sw0ima,itmatttvs= {fheraht: unFn 	,itmit nt;	

	//,.r) Iincludele
dco,estep 
	tax;ev"1o on	o/ nAnteNExihiddve eve,

	//,.r) Ido rs includele
dco,estep 
	tax;ev"2eio skipedeNr LeftshiddRrahtitincludeWidcoe=nincludeWidco?21h:nt;		fer(s; au< 4s; au+="2e-nincludeWidcoe
			s	w0imae=nteNExihid[ry[ );
	atttv[n.ma <in"t+ w0imae O=;atttv[n.padd!t oI+ w0imae O=;t = ;
	;
	}ep		/abcludeWidcoe
			s	atttv.opacity'=;atttv.widcoe=nt = ;
	;
	}rea15)
atttv;dlbj/	 Geatrgetl	sertcuEve =s*hustom 2fim

gats4ks
jQue cur {
islideDown:ageaFx("	sew 	,tislideUp:ageaFx("hides	,tislideToggle:ageaFx("soggle"	,tifa.nIn:a{ opacity:'"	sew 0},tifa.nOut:a{ opacity:'"hideso},tifa.nToggle:a{ opacity:'"soggle" F{l[ve:he cou ouery.Ep			sa
			}l)
tspafn[	nerye O=;ntdif An	 sioedp eaN
	 ,=//  s FOO ) {
teTa1domt.eveanim

j( p			s,	sioedp eaN
	 ,=//  s FOO ;	eF;dleObjl)
tspa ioedt ;ntdif An	 sioedp eaN
	 ,=ft tle jile o :dp. ioedt	tet = leO ioedt ]en.: func"i? l)
tsparyt		neh{rhh ioedt	s:) {
th.mp	d;_:=ft or !fatnneeaN
	 'or
on:  use an . he cou ;sioedt	s.mabioedp
ondurgepre:lbioedp
oneaN
	 :EfatnneeaN
	 'oreeaN
	 ']) !  use an . he cou ;eaN
	 	
knneeaN
	 	);nd4no t.durgepre =/			jQuefx.offs? 0t: t = leOo t.durgepre =ren.numl t"i? o t.durgepre :	
co t.durgepre  lrery.Evefx.sioedsi? l)
tspafx.sioeds[ o t.durgepre ]l:"l)
tspafx.sioeds._d)ion
i;	

	//nurmic, 30dpy.s
	ueO-ntr[a/==edsCony/ anAn->r"fx";
ar tho t.s
	ueO=r" anAnor o t.s
	ueO=reni
ax;
			}.o t.s
	ueO=r"fx";	eFd;
ng Q
	ue
	 	)o t.oldd=	 pr.tymp	d;_nd4no t.h.mp	d;_e= ntdif An	
	ntioep		/			jQuen . he cou ;o t.oldd 	
			}t o t.old.e	  ets.ev"e;bl;};
enep		/o t.s
	ueOck(/}.nks
jQua	eq
	ue(	th, ,eo t.s
	ueOccl)
		eF;
	}rea15)
o t;d;nd4ks
jQue cN
	 '= (/}lineationtdif An		pO ) {
teTa1domp;	eF{
	sw
	 :Eftdif An		pO ) {
teTa1dom0.5v-;Math.cos		p*Math.PI )d/l2;	eFd;nd4ks
jQuerimtrs =f[]);l)
tspafxs= Twe b.p		tont.t.in r);l)
tspafx.iiFOO=;ntdif An	
	ntiile timtrIr.
iimtrs =f  use arimtrs,tioit nt;	

fxNowe=v  use anewnni ;i(ur = ; au< rimtrs.( e
	g; a; i+ 		}trimtru= rimtrs[ry[ );
	/g Co chsforatrimtruh	ecortia/ Preveve b ild(mad;
	
		if!rimtr()h.matimtrs[ an e=renrimtrupe		}t timtrs.|"( ci= a--, 1"e;bl;		eFd;
ar th!rimtrs.( e
	gupe		}tks
jQuofx.stop(v;	eFdtfxNowe=v==edsCony;	;nd4ks
jQuefxerimtrt ;ntdif An	 rimtrupe		}ar thrimtr()h.ma  use arimtrsep|| witimtrupepe		}tks
jQuofx.stayp( ;
	}	;nd4ks
jQuefxe lterv !did13nd4ks
jQuefxes  ypdocntdif An	
	ntiar th!rimtrIdi+ 		}trimtrIdualsetIlterv !	/			jQuefx. iFO,vks
jQuefxe lterv !d ;
	}	;nd4ks
jQuefxe(dop;=antdif An	
	nti/ chrIlterv !	/rimtrIdi+;
	rimtrIdualtuoa4 ;nd4ks
jQuefxe(ioedsi= {
islow: 600,tifast:a20sh
	dd Def""];
(ioed
i_d)ion
i:k400d;nd4
	 B FOOCymp

d<1.8 ryt		sndoepoia? ks
jQuofx.step = {};t
ep		/			jQueexpro ) & !jQueexpr.Su obtvs
			}l)
tspaexpr.Su obtveanim

jdt ;ntdif An	 tuer0c) {
teTa1domks
jQueerep(  use arimtrs,;ntdif An	 fbe 	ntioneTa1domeuer0p==vfn.tuer;		
	ne( e
	g; {}cllbl)
tspafn.offset =of he cou ;o tido60ck(/jep		/a < handl.( e
	gupe		}trea15)
o tndo60=npu== oritach?	
crt.evs:	
crt.eve cur ntdif An	 an
	ntion:  use aoffsetasetOffset(	th, ,eo tgats,	i"e;bl;
e
		eFd;
ile docEuer,	w
	,tioboxs= {ftopio0, ( fi:k0 	,itmtuer0pe =);[ 0 e{
		doc0peeuerknneeueroownerDd trigEi ;iep		/!doc0pe		}trea15)		eFd;
docEuerepe oce d trigE"div")(;	
m doM/s fsuc '}
'soortiaadishyenetyndle{};ur.n;
ar th!			jQuece.gaias( docEuer,	tuer0c)pe		}trea15)
box;	eFd;
ng I.r) Ido rs h / AgBCR,Ajusttuse 0,0 rge3h ntha  ee er;
ng Bl FOBee y 5,	iOS 3 (h=ragm f iPhone)
;
	 3 handleOeuerogetB u)c
	 Cli")(Rorre!rent.pObstr[= oritachx;
			boxs= euerogetB u)c
	 Cli")(Rorr(v;	eFdtw
	s= getW
ed=w( doc 
		erea15)
		}tropiobox.dop;d+n(fw
	.pageYOffsetnvened Eueros? ollTope)  -ss"ed Euerocli")(Topevven0;
h
		( fi:kbox.( fid+n(fw
	.pageXOffsetnvened Eueros? ollLefts) -ss"ed Euerocli")(Leftsven0;
 {}cllnd4ks
jQueoffset =o {
;setOffsetiontdif An		tuer,	 prpres,han
	ntioile posiepre =/			jQuecss( tuer,	"posiepre 0b;
E8n
	 set posiepre fgrst,nin-mManidop/( fidrenotis'even ontsd  iF tuer;
	
		ifposiepre =ren.en  iFoIpe		}t tuerosty		.posiepre =/"relafima";bl;};
en
		se( Euerepeks
jQu(	tuer0c{
			curOffset =oe( Euereoffset(c{
			curCSSTopepe			jQuecss( tuer,	"dop" c{
			curCSSLefts= 			jQuecss( tuer,	"( fi" c{
			calcr/	/ePosiepre =/ifposiepre =ren.absolute"uvenposiepre =ren.fix(d"odo ) & !jQuennArray .ruto", [curCSSTop, curCSSLeft]) >o-1,
			p			sl=a{rhhcurPosiepre =/{rhhcurTop, curLeft;
E8n
	 n// ono
bevhe  sto calcr/	/enposiepre 
		eie3h ntopeur ( fidiecaueonandnposiepre 
s	eie3h nabsolute,ersrixad;
	
		ifcalcr/	/ePosiepre 
	ntioncurPosiepre =/e( Euereposiepre( ;
	;ecurTop =/e( Posiepre.dop;{
t	curLeft =/e( Posiepre.left;
do			} elsntiocurTop =/pofseFlvat( curCSSTope)vven0;		;
curLeft =/pofseFlvat( curCSSLefts) ven0;		;};
enep		/			jQuen . he cou ;o tido60ck
			}t o tndo60=	 prpres.e	  ettuer,	i, curOffset e;bl;};
enep		/o tpres.tope!]" anAn;)r s  p			s.dop;=a	/o tpres.tope- curOffset.dop;
	+hcurTop;		
		
ouse ao tpres.( fid!]" anAn;)r s  p			s.left =/ ao tpres.( fid- curOffset.lefts) + curLeft;
l;};
enep		/"ustnn"ninao tido60ck(/jt o tndo6.ustnn.e	  ettuer,	p			sa
;
do			} elsntiocurEuerocss( p			sa
;
do	
	}	;nd4jl)
tspafnaryt		ne {
	posiepreadd:uerandl
			s	ar th!r=);[ 0 ee 	ntioneTa1do;bl;};
en
		soffsetPrentN,soffset,
			prentNOffset =o{ftopio0, ( fi:k0 	,itmmtuer0pe =);[ 0 end {}dd fixadetuery.Evp.enooffset n/^(?e
ed=w (prentNOffset =o{topi0, ( fi:k0rhhbecause }

,  }
'so	nlyloffset prentN
enep		/			jQuecss( tuer,	"posiepre 0b =ren.fix(d"odo{tion
	 weh ssu[\; i2] getB u)c
	 Cli")(Rorre,  avcapab8e w054,tymputednposiepre 
s	rixad;
		offset =oeuerogetB u)c
	 Cli")(Rorr(v;	eo			} elsntiodd Giph* Prl*soffsetPrentN;
		offsetPrentNe=vs.eveoffsetPrentNi cl
lt.dd Giphce correoffsets;
		offset =os.eveoffset( ;
	;ear th!			jQueur.nNery(soffsetPrentN[ 0 e{ "html 0bs
			}.n:prentNOffset =ooffsetPrentNeoffset( ;
	;ee	tion
	 AddmoffsetPrentNebordbtv
	
	prentNOffset.dop;d+= 			jQuecss( offsetPrentN[ 0 e{ "bordbtTopWidco"
ntr[a"e;bl;
prentNOffset.( fid+= 			jQuecss( offsetPrentN[ 0 e{ "bordbtLeftWidco"
ntr[a"e;bl;
	
;

		Subtract prentNeoffsets	hiddelery.Eema <ins
on
	 orte:ow054,.betuery.Euh	ecma <in:caueon!jrdoffsetLeftshiddma <inLeft
n:/	  re tordseryiinaSafari causlbl offset.( fidno ince corrlveve 0
:uopeckeu		}t topio offset.dop;d- prentNOffset.dop;-/			jQuecss( tuer,	"ma <inTop"
ntr[a"eh
			( fi:koffset.( fid- prentNOffset.( fid- 			jQuecss( tuer,	"ma <inLeft"
ntr[a
70 };	eFra
toffsetPrentNadd:uerandl
			s	eTa1domt.evemap(ntdif An	
	ntionile offsetPrentNe=vs.eveoffsetPrentNnvened Euer;bl;
s
			l?eoffsetPrentNn.ma( !			jQueur.nNery(soffsetPrentN{ "html 0bs ) & !jQuecss( offsetPrentN,	"posiepre ) =ren.en  iFoIpe
			}.n:offsetPrentNe=voffsetPrentNeoffsetPrentN4 }t e	}
trea15)
offsetPrentNnvened Euer;bl;ed;

F{leObjj/	 Cnrgetes? ollLeftshidds? ollTopemer	ods4ks
jQue cur  {s? ollLeftpa"pageXOffset"
ns? ollToppa"pageYOffset"l[ve:he cou omer	od,	p			n);ntiile top;=a/Y/ elem.up			n);		}l)
tspafn[	mer	ode O=;ntdif An	 v !d ) {
teTa1domks
jQue.nodeN(	th, ,entdif An		tuer,	mer	od,	v !d ) {
ts
		sw
	s= getW
ed=w( tuer0c;	j!
tep		/v !dinpu== oritachbsntion 		.appdw
	s? (p			ninaw
	).i w
	[	p			n]l:	}t   w
	. d trigEe d trigE"div")([	mer	ode O:	}t   tuer[/mer	ode ;
	;ee	tionep		/wiatx;
			onw
	.s? ollTo(	r.t		!top;?/v !d:eks
jQu(	wiatxos? ollLeftl
,tion:	top;?/v !d:eks
jQu(	wiatxos? ollTop(vtion:)cl
lt.}		} elsntiontuer[/mer	ode  = rit4 }t e	}
e,	mer	od,	v !,/a < handl.( e
	g, eanAn;cleF;dleObj}
i EvenagetW
ed=w( tuer0ck(/jeTa1dom			jQuen W
ed=w( tuer0ck?itmtuer0:itmtuerour.noddep=] =9h?	
crtuerod)ion
iViewecortueroirentNW
ed=wO:	}t es ) ;;}j/	 CnrgeteinnerHeraht,einnerW
dco,eheraht,ee
dco,eouterHerahtshiddouterWidcoemer	ods4ks
jQue cur  { Heraht: .heraht", Widco:n.widco"ul[ve:he cou ouery.Ent.t	
			}ks
jQue cur  { padd!t :n.inn t"i+ouery.Etye;")(:Ont.t,n"":n.outer"i+oueryul[ve:he cou od)ion
iEyird[ve:heNery	
			s	//dma <in 
s		nlyl(ur outerHeraht,douterWidco	}tks
jQuof	[	e:heNery	 O=;ntdif An	 ma <in.Eritax;
			}.nile chainhe  s=/a < handl.( e
	gu.ma( d)ion
iEyirdnor tandleOma <in !]en.boo chn"v
,tion:ryirde= d)ion
iEyirdnor 	 ma <inO=reni
ax;cor
	tax;=reni
ax;?n.ma <in"t: "bordbt 0b;
E8nteTa1domks
jQue.nodeN(	th, ,entdif An		tuer,	nt.t,nritax;
			}.n:ile doci ;ioe
ep		/			jQuen W
ed=w( tuer0ck
			}t   
	 As we'5/8/2012ecoisewill
y"||  ince corr ieruleve =s*Mob			lSafari, bup	sf rc	}t   
	 is rs aow0o c lot
	e(up )do. SeenpanAnr s
	st
2] coiseURLof=s* iscussndo:	}t   
	 // hs://gie3ubrtym/jq	jQu/jq	jQu/panA/764j! n:
eTa1domeuer. d trigEe d trigE"div")([	"cli")("i+oueryu];bl;
lef
	lt.dd Giph d trigE widcoed	fheraht;ioe
ep		/tuerour.noddep=] =9h
			}t   doc0peeuere d trigE"div")(;	
m	lt.dd Eie3h ns? oll[Widco/Heraht]ed	foffset[Widco/Heraht]ed	fcli")([Widco/Heraht],ow0imaov}:/isegnrgetst




.ng unf=stungetly,	th, dcauses'buga#3838O lrIE6/8		nly, bup	sf rc/isee( .pa?lylno good,	sm nAnwayono
fix }
.j! n:
eTa1domMath.maxsj! n:
rtuerobody[m" ? oll"i+oueryu],edoc[m" ? oll"i+oueryu],j! n:
rtuerobody[m"offset"i+oueryu],edoc[m"offset"i+oueryu],j! n:
rdoc[m"cli")("i+oueryu]j! n:
e;bl;
leftion:eTa1dom
	tax;=ren== oritach?	
crt.dd Giphwidcoed	fheraht onttordcdiv")(,,r s
	st
	 
bu] ort fspa
	 
pofseFlvat	
crt.			jQuecss( tuer,	nt.t,nryirde	s:		
crt.dd Siphwidcoed	fheraht onttordcdiv")(	
crt.			jQuesty		iftuer,	nt.t,nritax,nryirde	4 }t e,	nt.t,nchainhe  s? ma <inO:l== oritac
nchainhe  , eanAn;cle };	eF);dleObdd Lim}

	copenpolluepre f/^(?any d)pcor

jdtAPI
ng nntdif An	
	nt
ng The numl t leOeuery.Evpce.gaiaedO lrtordminaleddelery.Eesetjl)
tspafnas, 30=antdif An	
	ntieTa1domt.eve( e
	g; ;nd4ks
jQuefn.hidSelf[= l)
tspafn.addB FO;
Eng })( ;

	 3 handleOmodulet ]en.: func"i.mamodulet	tet = leOmoduleaexpof sa=]en.: func"i lsnt//hExpo ell)
tsp  s moduleaexpof sa lrloader60ti2] implery.Eeif tNr.n;
//dmoduletp2]te5)
(abclud
	 
b x		btify). Do orticnrgeteif tglob !,/slbcn;
//dif tusettwill
be	rteclbliiEeif mselves loc
oly, hiddglob !vp.enof/^wnad;
ng upre  lrif tNr.ndmoduletworld.
	moduleaexpof sa=ll)
tsp; ;		} elsntdd OM3h e
se expo ell)
tsp eon!jrdglob !O: funcuas==sualdtw
	d=w.l)
tsp voe
ed=w.$a=ll)
tsp; 
,
	 Regis;"ri	eca uerydtAMDdmodule,/slbcnll)
tsp up )bo tyn	inen

jdte
		e<M3h 
}dd fi  s ti2] masuuse  orita,
bu] ort viaf lco		er tyn	inen

pre  ? iptonhat	
ng under6d nds	hionymoustAMDdmodules. A uerydtAMDdiecsafenne falmonnerobust	
ng wayono
regis;"r. LowermManijq	jQuuis==sjdabecause AMDdmodule uerys
are
;
	 dbti/ dnf/^(?fi   uerys, hiddl)
tsp is/nurmicly d)li/ redO lra
lowermMan
}dd fi   uery. Do th, d.f
bt cnrgetnn !jrdglob !Oso0ti2] i hiddAMDdmodule wants;
//dio
callenoConflicidno hent th, dv}:spre leOl)
tsp,iiEewill
	orr.
;
	 3 handleO orita =ren.ftdif An"i.ma orita.amchbsntio orita( "jq	jQu",n[],entdif An 	
	n eTa1domks
jQu; }d ;
	}	;
dleete
ed=w );
   